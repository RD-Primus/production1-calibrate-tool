#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"


#if 1
void alarm1(void){
	if(((Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM))||(!Flag.START_TIME)||(Flag.DP_CHANGED)) return;
	switch(Value.FunctionAlarm1){
		case NOT_USED:	/*Release functions*/
			AL1_OFF; LED_AL1_OFF;
			Flag.AL1SQ=0;
			break;
		case ABSOLUTE_HI_LO_LIMIT:	/*Absolute high/low limit*/
			if(Value.PV<=(Value.AlarmLimitLow1)||Value.PV>=(Value.AlarmLimitHigh1)){
				AL1_ON; LED_AL1_ON;
			}
			else{
				if(Value.PV>(Value.AlarmLimitLow1+Value.HysteresisAlarm1)&&Value.PV<(Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;
		case ABSOLUTE_HI_LIMIT:	/*Absolute high limit*/
			if(Value.PV>=(Value.AlarmLimitHigh1)){
				AL1_ON; LED_AL1_ON;
			}
			else{
				if(Value.PV<(Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;
		case ABSOLUTE_LO_LIMIT:	/*Absolute low limit*/
			if(Value.PV<=(Value.AlarmLimitLow1)){
				AL1_ON; LED_AL1_ON;;
			}
			else{
				if(Value.PV>(Value.AlarmLimitLow1+Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;
		case ABSOLUTE_RANGE_HI_LO_LIMIT:	/*Absolute range for high and low limit*/
			if(Value.PV>=(Value.AlarmLimitLow1)&&Value.PV<=(Value.AlarmLimitHigh1)){
				AL1_ON; LED_AL1_ON;
			}
			else{
				if(Value.PV<(Value.AlarmLimitLow1-Value.HysteresisAlarm1)||Value.PV>(Value.AlarmLimitHigh1+Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;			
		case DEVIATION_HI_LO_LIMIT:	/*Deviation high/low limit*/
			if(Value.PV<=(Value.SV-Value.AlarmLimitLow1)||Value.PV>=(Value.SV+Value.AlarmLimitHigh1)){
				AL1_ON; LED_AL1_ON;
			}
			else{
				if(Value.PV>(Value.SV-Value.AlarmLimitLow1+Value.HysteresisAlarm1)&&Value.PV<(Value.SV+Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;
		case DEVIATION_HI_LIMIT:	/*Deviation high limit*/
			if(Value.PV>=(Value.SV+Value.AlarmLimitHigh1)){
				AL1_ON; LED_AL1_ON;
			}
			else{
				if(Value.PV<(Value.SV+Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;
		case DEVIATION_LO_LIMIT:	/*Deviation low limit*/
			if(Value.PV<=(Value.SV-Value.AlarmLimitLow1)){
				AL1_ON; LED_AL1_ON;;
			}
			else{
				if(Value.PV>(Value.SV-Value.AlarmLimitLow1+Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;
		case DEVIATION_RANGE_HI_LO_LIMIT:	/*Deviation range for high and low limit*/
			if(Value.PV>=(Value.SV-Value.AlarmLimitLow1)&&Value.PV<=(Value.SV+Value.AlarmLimitHigh1)){
				AL1_ON; LED_AL1_ON;
			}
			else{
				if(Value.PV<(Value.SV-Value.AlarmLimitLow1-Value.HysteresisAlarm1)||Value.PV>(Value.SV+Value.AlarmLimitHigh1+Value.HysteresisAlarm1)){
					AL1_OFF; LED_AL1_OFF;
				}
			}
			break;			
		case SEQUENCE_ABSOLUTE_HI_LO_LIMIT:	/*Absolute value high/low limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV>(Value.AlarmLimitLow1+Value.HysteresisAlarm1)&&Value.PV<(Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV<=Value.AlarmLimitLow1||Value.PV>=Value.AlarmLimitHigh1){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV>(Value.AlarmLimitLow1+Value.HysteresisAlarm1)&&Value.PV<(Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;
		case SEQUENCE_ABSOLUTE_HI_LIMIT:	/*Absolute value high limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV<(Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV>=Value.AlarmLimitHigh1){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV<(Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;
		case SEQUENCE_ABSOLUTE_LO_LIMIT:	/*Absolute value low limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV>(Value.AlarmLimitLow1+Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV<=Value.AlarmLimitLow1){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV>(Value.AlarmLimitLow1+Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;
		case SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT:	/*Range of absolute value high and low limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV<(Value.AlarmLimitLow1-Value.HysteresisAlarm1)||Value.PV>(Value.AlarmLimitHigh1+Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV>=Value.AlarmLimitLow1&&Value.PV<=Value.AlarmLimitHigh1){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV<(Value.AlarmLimitLow1-Value.HysteresisAlarm1)||Value.PV>(Value.AlarmLimitHigh1+Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;		
		case SEQUENCE_DEVIATION_HI_LO_LIMIT:	/*Absolute value high/low limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV>(Value.SV-Value.AlarmLimitLow1+Value.HysteresisAlarm1)&&Value.PV<(Value.SV+Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV<=(Value.SV-Value.AlarmLimitLow1)||Value.PV>=(Value.SV+Value.AlarmLimitHigh1)){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV>(Value.SV-Value.AlarmLimitLow1+Value.HysteresisAlarm1)&&Value.PV<(Value.SV+Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;
		case SEQUENCE_DEVIATION_HI_LIMIT:	/*Absolute value high limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV<(Value.SV+Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV>=(Value.SV+Value.AlarmLimitHigh1)){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV<(Value.SV+Value.AlarmLimitHigh1-Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;
		case SEQUENCE_DEVIATION_LO_LIMIT:	/*Absolute value low limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV>(Value.SV-Value.AlarmLimitLow1+Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV<=(Value.SV-Value.AlarmLimitLow1)){
					AL1_ON; LED_AL1_ON;;
				}
				else{
					if(Value.PV>(Value.SV-Value.AlarmLimitLow1+Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;
		case SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT:	/*Range of absolute value high and low limit Stand-by sequence*/
			if(!Flag.AL1SQ){
				AL1_OFF; LED_AL1_OFF;
				if(Value.PV<(Value.SV-Value.AlarmLimitLow1-Value.HysteresisAlarm1)||Value.PV>(Value.SV+Value.AlarmLimitHigh1+Value.HysteresisAlarm1)){
					Flag.AL1SQ=1;	
				}
			}
			else{
				if(Value.PV>=(Value.SV-Value.AlarmLimitLow1)&&Value.PV<=(Value.SV+Value.AlarmLimitHigh1)){
					AL1_ON; LED_AL1_ON;
				}
				else{
					if(Value.PV<(Value.SV-Value.AlarmLimitLow1-Value.HysteresisAlarm1)||Value.PV>(Value.SV+Value.AlarmLimitHigh1+Value.HysteresisAlarm1)){
						AL1_OFF; LED_AL1_OFF;
					}
				}
			}
			break;	
	
	}
}
#endif	
void alarm2(void){
	if((Value.Option==OPTION_A)||(!Flag.START_TIME)||(Flag.DP_CHANGED)) return;

	if((Value.FunctionRelay==OUT1_ALARM_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)){
		AL2_OFF;LED_AL2_OFF;
	}
	else{
		switch(Value.FunctionAlarm2){
			case NOT_USED:	/*Release functions*/
				AL2_OFF; LED_AL2_OFF;
				Flag.AL2SQ=0;
				break;
			case ABSOLUTE_HI_LO_LIMIT:	/*Absolute high/low limit*/
				if(Value.PV<=(Value.AlarmLimitLow2)||Value.PV>=(Value.AlarmLimitHigh2)){
					AL2_ON; LED_AL2_ON;
				}
				else{
					if(Value.PV>(Value.AlarmLimitLow2+Value.HysteresisAlarm2)&&Value.PV<(Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case ABSOLUTE_HI_LIMIT:	/*Absolute high limit*/
				if(Value.PV>=(Value.AlarmLimitHigh2)){
					AL2_ON; LED_AL2_ON;
				}
				else{
					if(Value.PV<(Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case ABSOLUTE_LO_LIMIT:	/*Absolute low limit*/
				if(Value.PV<=(Value.AlarmLimitLow2)){
					AL2_ON; LED_AL2_ON;;
				}
				else{
					if(Value.PV>(Value.AlarmLimitLow2+Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case ABSOLUTE_RANGE_HI_LO_LIMIT:	/*Absolute range for high and low limit*/
				if(Value.PV>=(Value.AlarmLimitLow2)&&Value.PV<=(Value.AlarmLimitHigh2)){
					AL2_ON; LED_AL2_ON;
				}
				else{
					if(Value.PV<(Value.AlarmLimitLow2-Value.HysteresisAlarm2)||Value.PV>(Value.AlarmLimitHigh2+Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;		
			case DEVIATION_HI_LO_LIMIT:	/*Deviation high/low limit*/
				if(Value.PV<=(Value.SV-Value.AlarmLimitLow2)||Value.PV>=(Value.SV+Value.AlarmLimitHigh2)){
					AL2_ON; LED_AL2_ON;
				}
				else{
					if(Value.PV>(Value.SV-Value.AlarmLimitLow2+Value.HysteresisAlarm2)&&Value.PV<(Value.SV+Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case DEVIATION_HI_LIMIT:	/*Deviation high limit*/
				if(Value.PV>=(Value.SV+Value.AlarmLimitHigh2)){
					AL2_ON; LED_AL2_ON;
				}
				else{
					if(Value.PV<(Value.SV+Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case DEVIATION_LO_LIMIT:	/*Deviation low limit*/
				if(Value.PV<=(Value.SV-Value.AlarmLimitLow2)){
					AL2_ON; LED_AL2_ON;;
				}
				else{
					if(Value.PV>(Value.SV-Value.AlarmLimitLow2+Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case DEVIATION_RANGE_HI_LO_LIMIT:	/*Deviation range for high and low limit*/
				if(Value.PV>=(Value.SV-Value.AlarmLimitLow2)&&Value.PV<=(Value.SV+Value.AlarmLimitHigh2)){
					AL2_ON; LED_AL2_ON;
				}
				else{
					if(Value.PV<(Value.SV-Value.AlarmLimitLow2-Value.HysteresisAlarm2)||Value.PV>(Value.SV+Value.AlarmLimitHigh2+Value.HysteresisAlarm2)){
						AL2_OFF; LED_AL2_OFF;
					}
				}
				break;
			case SEQUENCE_ABSOLUTE_HI_LO_LIMIT:	/*Absolute value high/low limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV>(Value.AlarmLimitLow2+Value.HysteresisAlarm2)&&Value.PV<(Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV<=Value.AlarmLimitLow2||Value.PV>=Value.AlarmLimitHigh2){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV>(Value.AlarmLimitLow2+Value.HysteresisAlarm2)&&Value.PV<(Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
			case SEQUENCE_ABSOLUTE_HI_LIMIT:	/*Absolute value high limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV<(Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV>=Value.AlarmLimitHigh2){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV<(Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
			case SEQUENCE_ABSOLUTE_LO_LIMIT:	/*Absolute value low limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV>(Value.AlarmLimitLow2+Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV<=Value.AlarmLimitLow2){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV>(Value.AlarmLimitLow2+Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
			case SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT:	/*Range of absolute value high and low limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV<(Value.AlarmLimitLow2-Value.HysteresisAlarm2)||Value.PV>(Value.AlarmLimitHigh2+Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV>=Value.AlarmLimitLow2&&Value.PV<=Value.AlarmLimitHigh2){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV<(Value.AlarmLimitLow2-Value.HysteresisAlarm2)||Value.PV>(Value.AlarmLimitHigh2+Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;		
			case SEQUENCE_DEVIATION_HI_LO_LIMIT:	/*Absolute value high/low limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV>(Value.SV-Value.AlarmLimitLow2+Value.HysteresisAlarm2)&&Value.PV<(Value.SV+Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV<=(Value.SV-Value.AlarmLimitLow2)||Value.PV>=(Value.SV+Value.AlarmLimitHigh2)){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV>(Value.SV-Value.AlarmLimitLow2+Value.HysteresisAlarm2)&&Value.PV<(Value.SV+Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
			case SEQUENCE_DEVIATION_HI_LIMIT:	/*Absolute value high limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV<(Value.SV+Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV>=(Value.SV+Value.AlarmLimitHigh2)){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV<(Value.SV+Value.AlarmLimitHigh2-Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
			case SEQUENCE_DEVIATION_LO_LIMIT:	/*Absolute value low limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV>(Value.SV-Value.AlarmLimitLow2+Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV<=(Value.SV-Value.AlarmLimitLow2)){
						AL2_ON; LED_AL2_ON;;
					}
					else{
						if(Value.PV>(Value.SV-Value.AlarmLimitLow2+Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
			case SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT:	/*Range of absolute value high and low limit Stand-by sequence*/
				if(!Flag.AL2SQ){
					AL2_OFF; LED_AL2_OFF;
					if(Value.PV<(Value.SV-Value.AlarmLimitLow2-Value.HysteresisAlarm2)||Value.PV>(Value.SV+Value.AlarmLimitHigh2+Value.HysteresisAlarm2)){
						Flag.AL2SQ=1;	
					}
				}
				else{
					if(Value.PV>=(Value.SV-Value.AlarmLimitLow2)&&Value.PV<=(Value.SV+Value.AlarmLimitHigh2)){
						AL2_ON; LED_AL2_ON;
					}
					else{
						if(Value.PV<(Value.SV-Value.AlarmLimitLow2-Value.HysteresisAlarm2)||Value.PV>(Value.SV+Value.AlarmLimitHigh2+Value.HysteresisAlarm2)){
							AL2_OFF; LED_AL2_OFF;
						}
					}
				}
				break;
		}
	}
}
void limit_s32(s32 *output, s32 min, s32 max){
	s32 value;

	value=*output;
	if(value>max)
		*output=max;
	if(value<min)
		*output=min;
}
s8 check_on(s8 ctrl, s16 pv, s16 sv, s16 pos_on, s16 pos_off, s16 t_on_delay, s16 t_off_delay){
	s8 rl_on;
	
	rl_on=0;
	switch(ctrl){
		case COOLING_HYSTERESIS:
			rl_on=(pv>=(sv+pos_on+pos_off)) ? 1 : 0;
			break;
		case COOLING_TIME:
			if(pv>sv){
				if(++BaseTimeCount.mSecx2>=TIME1SEC){
					BaseTimeCount.mSecx2=0;
					if(++BaseTimeCount.Sec>=Value.OutputDelayOn){
						BaseTimeCount.Sec=0;
						rl_on=1;
					}
				}
			}
			break;
		case HEATING_HYSTERESIS:
			rl_on=(pv<=(sv-pos_on+pos_off)) ? 1 : 0;
			break;
		case HEATING_TIME:
			if(pv<sv){
				if(++BaseTimeCount.mSecx2>=TIME1SEC){
					BaseTimeCount.mSecx2=0;
					if(++BaseTimeCount.Sec>=Value.OutputDelayOn){
						BaseTimeCount.Sec=0;
						rl_on=1;
					}
				}
			}
			break;
	}
	return rl_on;
}
s8 check_off(s8 ctrl, s16 pv, s16 sv, s16 pos_off, s16 t_on_delay, s16 t_off_delay){
	s8 rl_off;

	rl_off=0;
	switch(ctrl){
		case COOLING_HYSTERESIS:
			rl_off=(pv<(sv+pos_off)) ? 1 : 0;
			break;
		case COOLING_TIME:
			if(pv<sv){
				if(++BaseTimeCount.mSecx2>=TIME1SEC){
					BaseTimeCount.mSecx2=0;
					if(++BaseTimeCount.Sec>=Value.OutputDelayOff){
						BaseTimeCount.Sec=0;
						rl_off=1;
					}
				}
			}
			else{
				rl_off=0;
			}
			break;
		case HEATING_HYSTERESIS:
			rl_off=(pv>(sv+pos_off)) ? 1 : 0;
			break;
		case HEATING_TIME:
			if(pv>sv){
				if(++BaseTimeCount.mSecx2>=TIME1SEC){
					BaseTimeCount.mSecx2=0;
					if(++BaseTimeCount.Sec>=Value.OutputDelayOff){
						BaseTimeCount.Sec=0;
						rl_off=1;
					}
				}
			}
			else{
				rl_off=0;
			}
			break;
	}
	return rl_off;
}
void output1_event(void){	
	s16 SV; 
	s16 PositionOn1;	
	s16 PositionOff1;	 
	
	if((!Flag.START_TIME)||((Value.FunctionRelay==OUT1_ALARM_OUT2_NONE)||(Value.FunctionRelay==OUT1_ALARM_OUT2_ALARM))) return;
	
	SV=Value.SV;  
	PositionOn1=Value.PositionOn1; 
	PositionOff1=Value.PositionOff1; 
	
	if(Error.PVHIGHLIMIT||Error.PVLOWLIMIT||(Status.Main>=PASSWORD_MODE)){
		if(Status.Output1){
			Status.Output1=INITIAL_CONTROL;
		}
		OUT1_OFF;LED_OUT1_OFF;	
		Value.Manipulated1=0;
	}
	else{
		switch(Status.Output1){
			case INITIAL_CONTROL:
				if(check_on(Value.ModeControl, Value.PVReal, SV, PositionOn1, PositionOff1, Value.OutputDelayOn, Value.OutputDelayOff)){
					OUT1_ON;LED_OUT1_ON;
					Status.Output1=ON_CHECK_OFF;
				}
				else{
					if(check_off(Value.ModeControl, Value.PVReal, SV, PositionOff1, Value.OutputDelayOn, Value.OutputDelayOff)){
						OUT1_OFF;LED_OUT1_OFF;
						Status.Output1=OFF_CHECK_ON;
					}
				}
				break;
			case OFF_CHECK_ON:	/*ON-OFF check on */
				if(check_on(Value.ModeControl, Value.PVReal, SV, PositionOn1, PositionOff1, Value.OutputDelayOn, Value.OutputDelayOff)){
					OUT1_ON;LED_OUT1_ON;
					Status.Output1=ON_CHECK_OFF;
				}
				break;
			case ON_CHECK_OFF:	/*ON-OFF check off*/
				if(check_off(Value.ModeControl, Value.PVReal, SV, PositionOff1, Value.OutputDelayOn, Value.OutputDelayOff)){
					OUT1_OFF;LED_OUT1_OFF;
					Status.Output1=OFF_CHECK_ON;
				}
				break;
			default:						
				Status.Output1=INITIAL_CONTROL;
				break;
		}
	}
}

