# FIXED

modbus.obj: ../modbus.c
modbus.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h
modbus.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h
modbus.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h
modbus.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h
modbus.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h
modbus.obj: ../config.h
modbus.obj: ../global.h
modbus.obj: ../Typedef.h
modbus.obj: ../modbus.h

../modbus.c:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h:

../config.h:

../global.h:

../Typedef.h:

../modbus.h:

