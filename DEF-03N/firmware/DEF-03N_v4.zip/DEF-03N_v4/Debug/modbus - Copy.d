# FIXED

modbus\ -\ Copy.obj: ../modbus\ -\ Copy.c
modbus\ -\ Copy.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h
modbus\ -\ Copy.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h
modbus\ -\ Copy.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h
modbus\ -\ Copy.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h
modbus\ -\ Copy.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h
modbus\ -\ Copy.obj: ../config.h
modbus\ -\ Copy.obj: ../global.h
modbus\ -\ Copy.obj: ../Typedef.h
modbus\ -\ Copy.obj: ../modbus.h

../modbus\ -\ Copy.c:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h:

../config.h:

../global.h:

../Typedef.h:

../modbus.h:

