# FIXED

uart.obj: ../uart.c
uart.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h
uart.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h
uart.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h
uart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h
uart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h
uart.obj: ../uart.h
uart.obj: ../global.h
uart.obj: ../Typedef.h

../uart.c:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h:

../uart.h:

../global.h:

../Typedef.h:

