# FIXED

Display.obj: ../Display.c
Display.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h
Display.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h
Display.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/math.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_ti_config.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/linkage.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_defs.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/_types.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/cdefs.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_types.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_limits.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdio.h
Display.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdarg.h
Display.obj: ../config.h
Display.obj: ../global.h
Display.obj: ../Typedef.h
Display.obj: ../Segment.h

../Display.c:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f4783.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/math.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_ti_config.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/linkage.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_defs.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/_types.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/cdefs.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_types.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_limits.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdio.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdarg.h:

../config.h:

../global.h:

../Typedef.h:

../Segment.h:

