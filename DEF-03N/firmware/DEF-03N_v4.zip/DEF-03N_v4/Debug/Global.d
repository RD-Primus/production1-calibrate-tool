# FIXED

Global.obj: ../Global.c
Global.obj: ../Config.h
Global.obj: ../Typedef.h

../Global.c:

../Config.h:

../Typedef.h:

