################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../lnk_msp430f4783.cmd 

C_SRCS += \
../Display.c \
../Global.c \
../Key.c \
../NTC10K.c \
../NTC2K.c \
../Output.c \
../PTC10K.c \
../PTC2K.c \
../main.c \
../modbus.c \
../uart.c 

C_DEPS += \
./Display.d \
./Global.d \
./Key.d \
./NTC10K.d \
./NTC2K.d \
./Output.d \
./PTC10K.d \
./PTC2K.d \
./main.d \
./modbus.d \
./uart.d 

OBJS += \
./Display.obj \
./Global.obj \
./Key.obj \
./NTC10K.obj \
./NTC2K.obj \
./Output.obj \
./PTC10K.obj \
./PTC2K.obj \
./main.obj \
./modbus.obj \
./uart.obj 

OBJS__QUOTED += \
"Display.obj" \
"Global.obj" \
"Key.obj" \
"NTC10K.obj" \
"NTC2K.obj" \
"Output.obj" \
"PTC10K.obj" \
"PTC2K.obj" \
"main.obj" \
"modbus.obj" \
"uart.obj" 

C_DEPS__QUOTED += \
"Display.d" \
"Global.d" \
"Key.d" \
"NTC10K.d" \
"NTC2K.d" \
"Output.d" \
"PTC10K.d" \
"PTC2K.d" \
"main.d" \
"modbus.d" \
"uart.d" 

C_SRCS__QUOTED += \
"../Display.c" \
"../Global.c" \
"../Key.c" \
"../NTC10K.c" \
"../NTC2K.c" \
"../Output.c" \
"../PTC10K.c" \
"../PTC2K.c" \
"../main.c" \
"../modbus.c" \
"../uart.c" 


