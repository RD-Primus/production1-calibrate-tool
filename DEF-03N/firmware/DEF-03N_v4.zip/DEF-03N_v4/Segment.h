#ifndef SEGMENT	

#define FONT_BLANK	0xFF
#if 1
#define	SEGDP		0xFE
#define	SEGG		0xFD
#define	SEGF		0xFB
#define	SEGE		0xF7
#define	SEGD		0xEF
#define	SEGC		0xDF
#define	SEGB		0xBF
#define	SEGA		0x7F
#else
#define	SEGA		0xFE
#define	SEGB		0xFD
#define	SEGC		0xFB
#define	SEGD		0xF7
#define	SEGE		0xEF
#define	SEGF		0xDF
#define	SEGG		0xBF
#define	SEGDP		0x7F
#endif

#define FONT_A			SEGA&SEGB&SEGC&SEGE&SEGF&SEGG
#define FONT_B			SEGC&SEGD&SEGE&SEGF&SEGG
#define FONT_C			SEGA&SEGD&SEGE&SEGF
#define FONT_D			SEGB&SEGC&SEGD&SEGE&SEGG
#define FONT_E			SEGA&SEGD&SEGE&SEGF&SEGG
#define FONT_F			SEGA&SEGE&SEGF&SEGG
#define FONT_G			SEGA&SEGB&SEGC&SEGD&SEGF&SEGG
#define FONT_H			SEGB&SEGC&SEGE&SEGF&SEGG
#define FONT_I			SEGE&SEGF
#define FONT_J			SEGB&SEGC&SEGD&SEGE
#define FONT_L			SEGD&SEGE&SEGF
#define FONT_M			SEGA&SEGC&SEGE
#define FONT_N			SEGC&SEGE&SEGG
#define FONT_O			SEGC&SEGD&SEGE&SEGG
#define FONT_P			SEGA&SEGB&SEGE&SEGF&SEGG
#define FONT_Q			SEGA&SEGB&SEGC&SEGF&SEGG
#define FONT_R			SEGE&SEGG
#define FONT_S			SEGA&SEGC&SEGD&SEGF&SEGG
#define FONT_T			SEGD&SEGE&SEGF&SEGG
#define FONT_U			SEGB&SEGC&SEGD&SEGE&SEGF
#define FONT_V			SEGC&SEGD&SEGE
#define FONT_W			SEGB&SEGD&SEGF
#define FONT_Y			SEGB&SEGC&SEGD&SEGF&SEGG
#define FONT_0			SEGA&SEGB&SEGC&SEGD&SEGE&SEGF
#define FONT_1			SEGB&SEGC
#define FONT_2			SEGA&SEGB&SEGD&SEGE&SEGG
#define FONT_3			SEGA&SEGB&SEGC&SEGD&SEGG
#define FONT_4			SEGB&SEGC&SEGF&SEGG
#define FONT_5			SEGA&SEGC&SEGD&SEGF&SEGG
#define FONT_6			SEGA&SEGC&SEGD&SEGE&SEGF&SEGG
#define FONT_7			SEGA&SEGB&SEGC
#define FONT_8			SEGA&SEGB&SEGC&SEGD&SEGE&SEGF&SEGG
#define FONT_9			SEGA&SEGB&SEGC&SEGD&SEGF&SEGG	

#define FONT_SLASH		SEGB&SEGE&SEGG
#define FONT_UNIT		SEGA&SEGB&SEGF&SEGG
#define FONT_MINUS		SEGG
#define FONT_DP			SEGDP
#define FONT_AT			FONT_DP
#define FONT_OVER		SEGA
#define FONT_UNDER		SEGD
#define FONT_PERCENT	SEGF

#if 0
#define FONT_A		0x88
#define FONT_B		0x83
#define FONT_C		0xC6
#define FONT_D		0xA1
#define FONT_E		0x86
#define FONT_F		0x8E
#define FONT_G		0x90
#define FONT_H		0x89
#define FONT_I		0xCF
#define FONT_J		0xE1
#define FONT_L		0xC7
#define FONT_M		0xEA
#define FONT_N		0xAB
#define FONT_O		0xA3
#define FONT_P		0x8C
#define FONT_Q		0x98
#define FONT_R		0xAF
#define FONT_S		0x92
#define FONT_T		0x87
#define FONT_U		0xC1
#define FONT_V		0xE3
#define FONT_W		0xD5
#define FONT_Y		0x91
#define FONT_0		0xC0
#define FONT_1		0xF9
#define FONT_2		0xA4
#define FONT_3		0xB0
#define FONT_4		0x99
#define FONT_5		0x92
#define FONT_6		0x82
#define FONT_7		0xF8
#define FONT_8		0x80
#define FONT_9		0x90	

#define FONT_SLASH	0xAD
#define FONT_UNIT	0x9C
#define FONT_MINUS	0xBF
#define FONT_DP		0x7F
#define FONT_AT		0x7F
#define FONT_OVER	0xFE
#define FONT_UNDER	0xF7
#define FONT_BLANK	0xFF
#endif
#endif

