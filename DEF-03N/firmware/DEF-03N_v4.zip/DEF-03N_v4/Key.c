#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"

#if 1
void write_SegA(s8 *value){
	s8 *Flash_ptr;                          // Flash pointer
	u8 i;

	Flash_ptr=(s8 *)0x10C0;               // Initialize Flash pointer
	FCTL3=FWKEY;                            // Clear Lock bit
	FCTL1=FWKEY+ERASE;              // Set Erase bit, allow interrupts
	*Flash_ptr=0;                           // Dummy write to erase Flash seg
	value++;

	FCTL1=FWKEY+WRT;                      // Set WRT bit for write operation

	for(i=0;i<64;i++,Flash_ptr++,value--){
		*Flash_ptr=*value;                   // Write value to flash
	}

	FCTL1=FWKEY;                            // Clear WRT bit
	FCTL3=FWKEY+LOCK;                     // Set LOCK bit
}

void write_SegA_n(s8 *value, u8 n){
	s8 *Flash_ptr;
	u8 i;

	Flash_ptr=(s8 *)0x10C0;
	FCTL3=FWKEY;
	FCTL1=FWKEY+ERASE;
	*Flash_ptr=0;
	value+=(n-1);

	FCTL1=FWKEY+WRT;
	for(i=0;i<n;i++,Flash_ptr++,value--){
		*Flash_ptr=*value;
	}
	FCTL1=FWKEY;
	FCTL3=FWKEY+LOCK;
}

void read_SegA_n(s8 *value, u8 n){
	s8 *Flash_ptr;
	u8 i;

	Flash_ptr=(s8 *)0x10C0;
	value+=(n-1);
	for(i=0;i<n;i++,Flash_ptr++,value--){
		*value=*Flash_ptr;
	}
}

void write_SegB(s8 *value){
	s8 *Flash_ptr;                          // Flash pointer
	u8 i;

	Flash_ptr=(s8 *)0x1080;               // Initialize Flash pointer
	FCTL3=FWKEY;                            // Clear Lock bit
	FCTL1=FWKEY+ERASE;              // Set Erase bit, allow interrupts
	*Flash_ptr=0;                           // Dummy write to erase Flash seg
	value++;

	FCTL1=FWKEY+WRT;                      // Set WRT bit for write operation

	for(i=0;i<64;i++,Flash_ptr++,value--){
		*Flash_ptr=*value;                   // Write value to flash
	}

	FCTL1=FWKEY;                            // Clear WRT bit
	FCTL3=FWKEY+LOCK;                     // Set LOCK bit
}
#endif
void write_SegC(s8 *value){
	s8 *Flash_ptr;                          // Flash pointer
	u8 i;

	Flash_ptr=(s8 *)0x1040;               // Initialize Flash pointer
	FCTL3=FWKEY;                            // Clear Lock bit
	FCTL1=FWKEY+ERASE;              // Set Erase bit, allow interrupts
	*Flash_ptr=0;                           // Dummy write to erase Flash seg
	value++;

	FCTL1=FWKEY+WRT;                      // Set WRT bit for write operation

	for(i=0;i<64;i++,Flash_ptr++,value--){
		*Flash_ptr=*value;                   // Write value to flash
	}

	FCTL1=FWKEY;                            // Clear WRT bit
	FCTL3=FWKEY+LOCK;                     // Set LOCK bit
}
void write_SegD(s8 *value){
	s8 *Flash_ptr;                          // Flash pointer
	u8 i;

	Flash_ptr=(s8 *)0x1000;               // Initialize Flash pointer
	FCTL3=FWKEY;                            // Clear Lock bit
	FCTL1=FWKEY+ERASE;              // Set Erase bit, allow interrupts
	*Flash_ptr=0;                           // Dummy write to erase Flash seg
	value++;

	FCTL1=FWKEY+WRT;                      // Set WRT bit for write operation

	for(i=0;i<64;i++,Flash_ptr++,value--){
		*Flash_ptr=*value;                   // Write value to flash
	}

	FCTL1=FWKEY;                            // Clear WRT bit
	FCTL3=FWKEY+LOCK;                     // Set LOCK bit
}
#if 1
void read_SegA(s8 *value){	
	s8 *Flash_ptr;                       // Pointer points at gain correction factor.
	u8  i;
	
	Flash_ptr=(s8 *)0x10C0;           // Initialize Flash segment A pointer 1080	Flash_ptr+=eep_address;
	value++;
	for (i=0;i<64;i++,Flash_ptr++,value--){
		*value=*Flash_ptr;  // copy value segment A to segment B
	}
}
void read_SegB(s8 *value){	
	s8 *Flash_ptr;                       // Pointer points at gain correction factor.
	u8  i;
	
	Flash_ptr=(s8 *)0x1080;           // Initialize Flash segment A pointer 1080	Flash_ptr+=eep_address;
	value++;
	for (i=0;i<64;i++,Flash_ptr++,value--){
		*value=*Flash_ptr;  // copy value segment A to segment B
	}
}
#endif
void read_SegC(s8 *value){	
	s8 *Flash_ptr;                       // Pointer points at gain correction factor.
	u8  i;
	
	Flash_ptr=(s8 *)0x1040;           // Initialize Flash segment A pointer 1080	Flash_ptr+=eep_address;
	value++;
	for (i=0;i<64;i++,Flash_ptr++,value--){
		*value=*Flash_ptr;  // copy value segment A to segment B
	}
}
void read_SegD (s8 *value){	
	s8 *Flash_ptr;                       // Pointer points at gain correction factor.
	u8  i;
	
	Flash_ptr=(s8 *)0x1000;           // Initialize Flash segment A pointer 1080	Flash_ptr+=eep_address;
	value++;
	for (i=0;i<64;i++,Flash_ptr++,value--){
		*value=*Flash_ptr;  // copy value segment A to segment B
	}
}
void save_calibrate(void){
	if(Flag.SAVETOFLASH){	
		__disable_interrupt();
		write_SegC((s8 *)&Value.TablePTC2K[PTC2K_4K]);
		__delay_cycles(DELAY_20MS_CYCLES);
		__delay_cycles(DELAY_20MS_CYCLES);
		write_SegB((s8 *)&Value.TableNTC2K[NTC2K_50K-NTC2K_500R]);
		Flag.SAVETOFLASH=0;	  
		__enable_interrupt();
	}
}
void save_parameter(void){
	if(Flag.SAVETOFLASH){	
		__disable_interrupt();
		write_SegD((s8 *)&Value.SV);
		Flag.SAVETOFLASH=0;
		__enable_interrupt();
	}
}
void operation_mode(void){
	Status.Main=OPERATION_MODE;
	min_max_value();
	Flag.EDIT=0;
	Flag.SETTING=0;
	Flag.BLINK=0;
	Flag.ST_BLINK=0;
	Flag.SV_EDIT=0;
	Flag.SV_CHANGED=0;
}
void setting_parameter_mode(void){
	Status.Main=INPUT_MODE;
	
	min_max_value();
	Flag.SETTING=1;
	Flag.EDIT=0;
	Flag.SV_EDIT=0;
	Flag.SV_CHANGED=0;
}
void setting_parameter_next(void){
	check_save_parameter();
	switch(Status.Main){	
		case RELAYFUNC_MODE:
			switch(Value.FunctionRelay){
				case OUT1_ALARM_OUT2_NONE:
				case OUT1_ALARM_OUT2_ALARM:
					Status.Main=FUNCALARM1_MODE;
					break;
				case OUT1_CTRL_OUT2_NONE:
				case OUT1_CTRL_OUT2_ALARM:
					Status.Main=CONTROL_MODE;
					break;
			}
			break;
		case CONTROL_MODE:
			switch(Value.ModeControl){
				case COOLING_HYSTERESIS:
				case HEATING_HYSTERESIS:
					Status.Main=POSITION_ON_MODE;
					break;
				case COOLING_TIME:
				case HEATING_TIME:
					Status.Main=OUTPUT_DELAY_ON_MODE;
					break;
			}
			break;
		//case LOCKKEY_MODE:
		//	Status.Main=ROOM_TEMP_MODE;
		//	break;	
		case FUNCALARM1_MODE:
			switch(Value.FunctionAlarm1){
				case NOT_USED:
					Status.Main=(Value.FunctionRelay==OUT1_ALARM_OUT2_ALARM) ? FUNCALARM2_MODE : INPUT_MODE;
					break;
				case DEVIATION_LO_LIMIT:
				case ABSOLUTE_LO_LIMIT:
				case SEQUENCE_DEVIATION_LO_LIMIT:
				case SEQUENCE_ABSOLUTE_LO_LIMIT:
					Status.Main=ALARM1_LO_MODE;
					break;
				default:
					Status.Main=ALARM1_HI_MODE;
					break;
			}
			break;
		case ALARM1_HI_MODE:
			switch(Value.FunctionAlarm1){
				case DEVIATION_HI_LIMIT:
				case ABSOLUTE_HI_LIMIT:
				case SEQUENCE_DEVIATION_HI_LIMIT:
				case SEQUENCE_ABSOLUTE_HI_LIMIT:
					Status.Main=ALARM1_HYSTERESIS_MODE;
					break;
				default:
					Status.Main=ALARM1_LO_MODE;
					break;
			}
			break;
		case ALARM1_HYSTERESIS_MODE:
			Status.Main=(Value.FunctionRelay==OUT1_ALARM_OUT2_ALARM) ? FUNCALARM2_MODE : INPUT_MODE;
			break;
		case FUNCALARM2_MODE:
			switch(Value.FunctionAlarm2){
				case NOT_USED:
					Status.Main=INPUT_MODE;
					break;
				case DEVIATION_LO_LIMIT:
				case ABSOLUTE_LO_LIMIT:
				case SEQUENCE_DEVIATION_LO_LIMIT:
				case SEQUENCE_ABSOLUTE_LO_LIMIT:
					Status.Main=ALARM2_LO_MODE;
					break;
				default:
					Status.Main=ALARM2_HI_MODE;
					break;
			}
			break;
		case ALARM2_HI_MODE:
			switch(Value.FunctionAlarm2){
				case DEVIATION_HI_LIMIT:
				case ABSOLUTE_HI_LIMIT:
				case SEQUENCE_DEVIATION_HI_LIMIT:
				case SEQUENCE_ABSOLUTE_HI_LIMIT:
					Status.Main=ALARM2_HYSTERESIS_MODE;
					break;
				default:
					Status.Main=ALARM2_LO_MODE;
					break;
			}
			break;
		case ALARM2_HYSTERESIS_MODE:
			Status.Main=INPUT_MODE;
			break;
		case ROOM_TEMP_MODE:
			Status.Main=STARTTIME_MODE;
			break;
		case POSITION_OFF_MODE:
		case OUTPUT_DELAY_OFF_MODE:
			Status.Main=(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM) ? FUNCALARM2_MODE : INPUT_MODE;
			break;
		default:
			Status.Main++;
			break;
	}
	Flag.EDIT=0;
	min_max_value();
}
void edit_alarm(void){
	check_save_parameter();
	switch(Status.Main){
		case OPERATION_MODE:
			if((Value.FunctionRelay==OUT1_ALARM_OUT2_NONE)||(Value.FunctionRelay==OUT1_ALARM_OUT2_ALARM)){
				if(Value.FunctionAlarm1){
					Status.Main=((Value.FunctionAlarm1==DEVIATION_LO_LIMIT)||(Value.FunctionAlarm1==ABSOLUTE_LO_LIMIT)||(Value.FunctionAlarm1==SEQUENCE_DEVIATION_LO_LIMIT)||(Value.FunctionAlarm1==SEQUENCE_ABSOLUTE_LO_LIMIT)) ? ALARM1_LO_MODE : ALARM1_HI_MODE;
				}
				else{
					Status.Main=OPERATION_MODE;
				}
			}
			else if(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM){
				if(Value.FunctionAlarm2){
					Status.Main=((Value.FunctionAlarm2==DEVIATION_LO_LIMIT)||(Value.FunctionAlarm2==ABSOLUTE_LO_LIMIT)||(Value.FunctionAlarm2==SEQUENCE_DEVIATION_LO_LIMIT)||(Value.FunctionAlarm2==SEQUENCE_ABSOLUTE_LO_LIMIT)) ? ALARM2_LO_MODE : ALARM2_HI_MODE;
				}
				else{
					Status.Main=OPERATION_MODE;
				}
			}
			else{
				Status.Main=OPERATION_MODE;
			}
			break;
		case ALARM1_HI_MODE:
			Status.Main=((Value.FunctionAlarm1==DEVIATION_HI_LIMIT)||(Value.FunctionAlarm1==ABSOLUTE_HI_LIMIT)||(Value.FunctionAlarm1==SEQUENCE_DEVIATION_HI_LIMIT)||(Value.FunctionAlarm1==SEQUENCE_ABSOLUTE_HI_LIMIT)) ? ALARM1_HYSTERESIS_MODE : ALARM1_LO_MODE;
			break;
		case ALARM1_LO_MODE:
			Status.Main=ALARM1_HYSTERESIS_MODE;
			break;
		case ALARM1_HYSTERESIS_MODE:
			if((Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM)||(Value.FunctionRelay==OUT1_ALARM_OUT2_ALARM)){
				if(Value.FunctionAlarm2){
					Status.Main=((Value.FunctionAlarm2==DEVIATION_LO_LIMIT)||(Value.FunctionAlarm2==ABSOLUTE_LO_LIMIT)||(Value.FunctionAlarm2==SEQUENCE_DEVIATION_LO_LIMIT)||(Value.FunctionAlarm2==SEQUENCE_ABSOLUTE_LO_LIMIT)) ? ALARM2_LO_MODE : ALARM2_HI_MODE;
				}
				else{
					save_parameter();
					Status.Main=OPERATION_MODE;
				}
			}
			else{
				save_parameter();
				Status.Main=OPERATION_MODE;
			}
			break;
		case ALARM2_HI_MODE:
			Status.Main=((Value.FunctionAlarm2==DEVIATION_HI_LIMIT)||(Value.FunctionAlarm2==ABSOLUTE_HI_LIMIT)||(Value.FunctionAlarm2==SEQUENCE_DEVIATION_HI_LIMIT)||(Value.FunctionAlarm2==SEQUENCE_ABSOLUTE_HI_LIMIT)) ? ALARM2_HYSTERESIS_MODE : ALARM2_LO_MODE;
			break;
		case ALARM2_LO_MODE:
			Status.Main=ALARM2_HYSTERESIS_MODE;
			break;
		case ALARM2_HYSTERESIS_MODE:
			save_parameter();
			Status.Main=OPERATION_MODE;
			break;
	}
	Flag.EDIT=0;
	min_max_value();
}
void password_mode(void){
	Flag.CONFIG_MODEL=(Status.Main==INIT_0_MODE) ? 1 : 0;
	Status.Main=PASSWORD_MODE;
	Value.Password[0]=0;
	Value.Password[1]=0;
	Value.Password[2]=0;
	PWColumn=0;
	Flag.EDIT=0;
}
void config_relay_mode(void){
	Status.Main=CONFIG_RELAY_MODE;
	min_max_value();
	Flag.EDIT=0;
}
void cal_ohm_ptc2kohm_init(void){
	Value.Input=PTC_2K;
	ADC16A_init();
	Value.ValueCalibrate=10;
	Value.PointCalibrate=PTC2K_1K;
	Flag.SETTING=0;
	Flag.START_CAL=0;
}
void cal_ohm_ptc10kohm_init(void){
	Value.Input=PTC_10K;
	ADC16A_init();
	// Value.ValueCalibrate=10;
	Value.ValueCalibrate=1;
	Value.PointCalibrate=PTC10K_1K;
	Flag.SETTING=0;
	Flag.START_CAL=0;
}

void cal_ohm_ntc2kohm_init(void){
	Value.Input=NTC_2K;
	ADC16A_init();
	Value.ValueCalibrate=1;
	Value.PointCalibrate=NTC2K_500R;
	Flag.SETTING=0;
	Flag.START_CAL=0;
}
void cal_ohm_ntc10kohm_init(void){
	Value.Input=NTC_10K;
	ADC16A_init();
	Value.ValueCalibrate=1;
	Value.PointCalibrate=NTC10K_1K;
	Flag.SETTING=0;
	Flag.START_CAL=0;
}
void calibrate_mode(void){
	Status.Main=CALIBRATE_INPUT_MODE;
	cal_ohm_ptc2kohm_init();
	Flag.CALEN=0;	

}
void calibrate_routine(void){
    Flag.WAITING = 0; // เคลียร์เพื่อเตรียมรอรับจุดถัดไป

#if 1
	switch(Value.PointCalibrate){
		case PTC2K_1K:
		case PTC2K_1d5K:
		case PTC2K_2K:
		case PTC2K_2d5K:
		case PTC2K_3K:
		case PTC2K_3d5K:
		case PTC2K_4K:
			Value.TablePTC2K[Value.PointCalibrate]=Value.Fadc;
			Value.ValueCalibrate+=5;
			if(++Value.PointCalibrate>PTC2K_4K){
				cal_ohm_ntc2kohm_init();
			}
			break;
		case PTC10K_1K:
		case PTC10K_5K:
		case PTC10K_10K:
		case PTC10K_40K:
		case PTC10K_70K:
		case PTC10K_100K:
		case PTC10K_130K:
		case PTC10K_160K:
		case PTC10K_190K:
		case PTC10K_220K:
			Value.TablePTC10K[Value.PointCalibrate-PTC10K_1K]=Value.Fadc;
			// Value.ValueCalibrate+=20;
			if(Value.PointCalibrate==PTC10K_1K)
				Value.ValueCalibrate+=4;
			else if(Value.PointCalibrate==PTC10K_5K)
				Value.ValueCalibrate+=5;
			else
				Value.ValueCalibrate+=30;
			if(++Value.PointCalibrate>PTC10K_220K){
				cal_ohm_ntc2kohm_init();
			}
			break;
		case NTC2K_500R:
		case NTC2K_1K:
		case NTC2K_2K:
		case NTC2K_3K:
		case NTC2K_4K:
		case NTC2K_5K:
		case NTC2K_10K:
		case NTC2K_20K:
		case NTC2K_30K:
		case NTC2K_40K:
		case NTC2K_50K:
			Value.TableNTC2K[Value.PointCalibrate-NTC2K_500R]=Value.Fadc;
			if(Value.PointCalibrate<NTC2K_1K)
				Value.ValueCalibrate+=9;
			else if(Value.PointCalibrate<NTC2K_5K)
				Value.ValueCalibrate+=10;
			else if(Value.PointCalibrate==NTC2K_5K)
				Value.ValueCalibrate+=50;
			else
				Value.ValueCalibrate+=100;
			
			if(++Value.PointCalibrate>NTC2K_50K){
				cal_ohm_ntc10kohm_init();
			}
			break;
		case NTC10K_1K:
		case NTC10K_5K:
		case NTC10K_10K:
		case NTC10K_40K:
		case NTC10K_70K:
		case NTC10K_100K:
		case NTC10K_130K:
		case NTC10K_160K:
		case NTC10K_190K:
		case NTC10K_220K:
			Value.TableNTC10K[Value.PointCalibrate-NTC10K_1K]=Value.Fadc;
			if(Value.PointCalibrate==NTC10K_1K)
				Value.ValueCalibrate+=4;
			else if(Value.PointCalibrate==NTC10K_5K)
				Value.ValueCalibrate+=5;
			else
				Value.ValueCalibrate+=30;
			
			if(++Value.PointCalibrate>NTC10K_220K){
				Flag.SAVETOFLASH=1;
				save_calibrate();
				_reset_init();
			}
			break;
	}
#else
	switch(Value.PointCalibrate){
		case POINT_0:
			Value.TableADCMEM0[SD16GAIN8][POINT_0]=Value.Fadc;
			//Write_I2C(EEP_OFFSET8, (u8 *)&Value.TableADCMEM0[SD16GAIN8][POINT_0], 2);
			Value.PointCalibrate=POINT_1;
			Value.ValueCalibrate=64;
			break;
		case POINT_1:
			Value.TableADCMEM0[SD16GAIN8][POINT_1]=Value.Fadc;		
			Flag.SAVETOFLASH=1;
			save_parameter();
			_reset_init();
			//Write_I2C(EEP_GAIN8, (u8 *)&Value.TableADCMEM0[SD16GAIN8][POINT_1], 2);	
			//Value.PointCalibrate=EEP_MAXADC_RESET;
			break;
		case EEP_VREF:
			Value.VrefPT100=Value.Fadc;
			Value.VrefPT100=(Value.VrefPT100/65535)*0.3;
			Value.VrefPT100=(Value.VrefPT100*30500)/500;
			Flag.SAVETOFLASH=1;
			save_parameter();
			_reset_init();
			//Value.TableADCMEM0[SD16RTD][POINT_0]=Value.Fadc;
			//Write_I2C(EEP_VREF, (u8 *)&Value.TableADCMEM0[SD16RTD][POINT_0], 2);
			break;
		case POINT_2:
		case POINT_3:
		case POINT_4:
		case POINT_5:
			Value.TableRTD[Value.PointCalibrate-EEP_RTD]=Value.Fadc;
			Value.ValueCalibrate+=100;
			if(++Value.PointCalibrate>=(EEP_RTD+4)){
				Flag.SAVETOFLASH=1;
				save_parameter();
				_reset_init();
			}
			//Write_I2C(EEP_GAIN8, (u8 *)&Value.TableADCMEM0[SD16GAIN8][POINT_1], 2);	
			//Value.PointCalibrate=EEP_MAXADC_RESET;
			break;
		case EEP_PTC2K:
		case EEP_PTC2K+1:
		case EEP_PTC2K+2:
		case EEP_PTC2K+3:
		case EEP_PTC2K+4:
		case EEP_PTC2K+5:
		case EEP_PTC2K+6:
			Value.TablePTC2K[Value.PointCalibrate-EEP_PTC2K]=Value.Fadc;
			Value.ValueCalibrate+=5;
			if(++Value.PointCalibrate>=(EEP_PTC2K+7)){
				Flag.SAVETOFLASH=1;
				save_parameter();
				_reset_init();
			}
			//Write_I2C(EEP_GAIN8, (u8 *)&Value.TableADCMEM0[SD16GAIN8][POINT_1], 2);	
			//Value.PointCalibrate=EEP_MAXADC_RESET;
			break;
		case EEP_NTC2K:
		case EEP_NTC2K+1:
		case EEP_NTC2K+2:
		case EEP_NTC2K+3:
		case EEP_NTC2K+4:
		case EEP_NTC2K+5:
		case EEP_NTC2K+6:
		case EEP_NTC2K+7:
		case EEP_NTC2K+8:
		case EEP_NTC2K+9:
			Value.TableNTC2K[Value.PointCalibrate-EEP_NTC2K]=Value.Fadc;
			if(Value.PointCalibrate<EEP_NTC2K+4)
				Value.ValueCalibrate+=10;
			else if(Value.PointCalibrate==EEP_NTC2K+4)
				Value.ValueCalibrate+=50;
			else
				Value.ValueCalibrate+=100;
				
			if(++Value.PointCalibrate>=(EEP_NTC2K+10)){
				Flag.SAVETOFLASH=1;
				save_parameter();
				_reset_init();
			}
			//Write_I2C(EEP_GAIN8, (u8 *)&Value.TableADCMEM0[SD16GAIN8][POINT_1], 2);	
			//Value.PointCalibrate=EEP_MAXADC_RESET;
			break;
	}
#endif	
}
void start_time_mode(void){
	if(Flag.START_TIME) return;
	if(++BaseTimeCount.mSecx2>=TIME1SEC){
		BaseTimeCount.mSecx2=0;
		if(++BaseTimeCount.Sec>=Value.StartTime){
			BaseTimeCount.Sec=0;
			Flag.START_TIME=1;
			Flag.ST_BLINK=0;
		}
	}
}
void up_parameter(void){
	if((!Flag.EDIT)){ 
		Flag.EDIT=1;
		if((Status.Main==OPERATION_MODE)&&((Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM))){
			Flag.BLINK=1;Value.BlinkTime=0;
			Flag.SV_EDIT=1;
		}
	}
	else{
		if((Status.Main==OPERATION_MODE)&&((Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM))){Flag.SV_CHANGED=1;}
		switch(Status.Main){
			default:
				switch(Key.Status){
					case KEY_ACTIVE:
					case KEY_HOLD:
					case KEY_STEP_PLUS_1:
						*Xdptr+=1;
						break;
					case KEY_STEP_PLUS_10:
						*Xdptr+=10;
						break;	
					case KEY_STEP_PLUS_100:
						*Xdptr+=100;
						break;	
				}
				if(*Xdptr>=Maximum){
					*Xdptr=Maximum;
					Flag.VALUELIMIT=1;
				}
				break;
			case RELAYFUNC_MODE:	
				if(Value.Option==OPTION_AB){
					*Xdptr=(*Xdptr==OUT1_ALARM_OUT2_ALARM) ? OUT1_CTRL_OUT2_NONE : *Xdptr+1;
				}
				else{
					if(*Xdptr==OUT1_ALARM_OUT2_NONE){
						*Xdptr=OUT1_CTRL_OUT2_NONE;
					}
				}
				if(*Xdptr>=Maximum){
					*Xdptr=Maximum;
				}				
				Flag.VALUELIMIT=1;		
				break;
			case CONTROL_MODE:	
				*Xdptr=(*Xdptr==COOLING_TIME) ? HEATING_HYSTERESIS : *Xdptr+1;
				if(*Xdptr>=Maximum){
					*Xdptr=Maximum;
				}				
				Flag.VALUELIMIT=1;		
				break;
			case FUNCALARM1_MODE:
				*Xdptr=*Xdptr==ABSOLUTE_RANGE_HI_LO_LIMIT ? SEQUENCE_ABSOLUTE_HI_LO_LIMIT : *Xdptr+1;
				if(*Xdptr>=Maximum){
					*Xdptr=Maximum;
					Flag.VALUELIMIT=1;
				}				
				break;
			case FUNCALARM2_MODE:
				if(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM){
					*Xdptr=*Xdptr==DEVIATION_RANGE_HI_LO_LIMIT ? SEQUENCE_ABSOLUTE_HI_LO_LIMIT : *Xdptr+1;
				}
				else{
					*Xdptr=*Xdptr==ABSOLUTE_RANGE_HI_LO_LIMIT ? SEQUENCE_ABSOLUTE_HI_LO_LIMIT : *Xdptr+1;
				}
				if(*Xdptr>=Maximum){
					*Xdptr=Maximum;
					Flag.VALUELIMIT=1;
				}				
				break;
			case PASSWORD_MODE:
				if(Flag.ENTER_PASSWORD){
					if(++Value.Password[PWColumn]>9) Value.Password[PWColumn]=0;
				}
				Flag.VALUELIMIT=1;
				break;
			case CONFIG_RELAY_MODE:
				if(*Xdptr==Minimum){
					*Xdptr=Maximum;
				}		
				Flag.VALUELIMIT=1;		
				break;
			case CALIBRATE_INPUT_MODE:
				Flag.SAVETOFLASH=1;
				save_calibrate();
				_reset_init();
				break;
			case ROOM_TEMP_MODE:
				Flag.VALUELIMIT=1;
				break;
		}
	}
}
void dn_parameter(void){
	if((!Flag.EDIT)){ 
		Flag.EDIT=1;
		if((Status.Main==OPERATION_MODE)&&((Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM))){
			Flag.BLINK=1;Value.BlinkTime=0;
			Flag.SV_EDIT=1;
		}
	}
	else{
		if((Status.Main==OPERATION_MODE)&&((Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM))){Flag.SV_CHANGED=1;}
		switch(Status.Main){
			default:
				switch(Key.Status){
					case KEY_ACTIVE:
					case KEY_HOLD:
					case KEY_STEP_PLUS_1:
						*Xdptr-=1;
						break;
					case KEY_STEP_PLUS_10:
						*Xdptr-=10;
						break;
					case KEY_STEP_PLUS_100:
						*Xdptr-=100;
						break;	
				}
				if(*Xdptr<=Minimum){
					*Xdptr=Minimum;
					Flag.VALUELIMIT=1;
				}
				break;
			case RELAYFUNC_MODE:	
				if(Value.Option==OPTION_AB){
					*Xdptr=(*Xdptr==OUT1_CTRL_OUT2_NONE) ? OUT1_ALARM_OUT2_ALARM : *Xdptr-1;
				}
				else{
					if(*Xdptr==OUT1_CTRL_OUT2_NONE){
						*Xdptr=OUT1_ALARM_OUT2_NONE;
					}
				}
				if(*Xdptr<=Minimum){
					*Xdptr=Minimum;
				}				
				Flag.VALUELIMIT=1;		
				break;
			case CONTROL_MODE:	
				*Xdptr=(*Xdptr==HEATING_HYSTERESIS) ? COOLING_TIME : *Xdptr-1;
				if(*Xdptr<=Minimum){
					*Xdptr=Minimum;
				}				
				Flag.VALUELIMIT=1;		
				break;
			case FUNCALARM1_MODE:			
				*Xdptr=*Xdptr==SEQUENCE_ABSOLUTE_HI_LO_LIMIT ? ABSOLUTE_RANGE_HI_LO_LIMIT : *Xdptr-1;
				if(*Xdptr<=Minimum){
					*Xdptr=Minimum;
					Flag.VALUELIMIT=1;
				}
				break;
			case FUNCALARM2_MODE:			
				if(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM){
					*Xdptr=(*Xdptr==SEQUENCE_ABSOLUTE_HI_LO_LIMIT) ? DEVIATION_RANGE_HI_LO_LIMIT : *Xdptr-1;
				}
				else{
					*Xdptr=*Xdptr==SEQUENCE_ABSOLUTE_HI_LO_LIMIT ? ABSOLUTE_RANGE_HI_LO_LIMIT : *Xdptr-1;
				}
				if(*Xdptr<=Minimum){
					*Xdptr=Minimum;
					Flag.VALUELIMIT=1;
				}
				break;
			case PASSWORD_MODE:
				if(Flag.ENTER_PASSWORD){
					if(++PWColumn>=3) PWColumn=0;
				}
				Flag.VALUELIMIT=1;
				break;
			case CONFIG_RELAY_MODE:
				if(*Xdptr==Maximum){
					*Xdptr=Minimum;
				}				
				Flag.VALUELIMIT=1;		
				break;
			case ROOM_TEMP_MODE:
				Flag.VALUELIMIT=1;
				break;
			case CALIBRATE_INPUT_MODE:
				switch(Value.Input){
					case PTC_2K:
						//cal_ohm_ptc10kohm_init();
                                                cal_ohm_ntc2kohm_init();
						break;
					case PTC_10K:
						cal_ohm_ntc2kohm_init();
						break;
					case NTC_2K:
						cal_ohm_ntc10kohm_init();
						break;
					case NTC_10K:
						cal_ohm_ptc2kohm_init();
						break;
				}
				Flag.VALUELIMIT=1;
				break;
		}
	}
}
s8 lock_parameter(void){	
	s8 lock;

	switch(Status.Main){
		case OPERATION_MODE:
			if(((Value.FunctionRelay==OUT1_CTRL_OUT2_NONE)||(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM))&&((Value.LockKey==1)||(Value.LockKey==2))) lock=1;
			else lock=0;
			break;
		case LOCKKEY_MODE:
		case ROOM_TEMP_MODE:
		case PASSWORD_MODE:
		case CONFIG_RELAY_MODE:
			lock=0;
			break;
		case ALARM1_HI_MODE:
		case ALARM1_LO_MODE:
		case ALARM1_HYSTERESIS_MODE:
			if(!Flag.SETTING){
				return (Value.LockKey==1||Value.LockKey==2) ? 1 : 0;
			}
			else{
				return (Value.LockKey==1||Value.LockKey==3) ? 1 : 0;
			}
			break;
		default:
			if((Value.LockKey==1)||(Value.LockKey==3)) lock=1;
			else lock=0;
			break;
	}
	return lock;
}
u8 key_load(void){
	u8 key_val;

	key_val=P4IN&(BIT7|BIT6);
	key_val|=(P7IN&BIT0);	
	//return((P4IN&(BIT7|BIT6))|(P7IN&BIT0));
	return key_val;
}
u8 key_compare(void){
	return(key_load()==Key.Last) ? TRUE : (((key_load()==(UPKEYVal&DNKEYVal))&&(Key.Last==UPKEYVal||Key.Last==DNKEYVal)) ? TRUE : FALSE);
}
u8 key_release(void){
	return(key_load()!=NONEKEYVal) ? FALSE : TRUE;
}
void key_event(void){
	if(FrontKeyStatus!=0){
		if(++FrontKeyStatusTimeout>=TIME10SEC){
			FrontKeyStatus=0;
			FrontKeyStatusTimeout=0;
		}
	}

	switch(Key.Status){
		case KEY_PRESS:
			if(key_load()!=NONEKEYVal){
				Key.Last=key_load();
				Flag.VALUELIMIT=0;
				Flag.LOCK_ON=0;
				Key.HoldTime=0;
				Key.AdjustTimeOut=0;
				Key.Hold=0;
				Key.Status=KEY_DEBOUNCE;
			}
			else{
				if((Status.Main>=PASSWORD_MODE)){
					Key.Status=KEY_PRESS;
				}
				else{					
					if(Flag.SETTING){
						if(++Key.AdjustTimeOut>=TIME30SEC){
							Key.AdjustTimeOut=0;
							check_save_parameter();
							save_parameter();
							operation_mode();
						}
					}
					else{
						if(Status.Main==OPERATION_MODE){
							if(Flag.SV_EDIT){
								if(Flag.SV_CHANGED){
									if(++Key.AdjustTimeOut>=TIME2SEC){
										Flag.SV_CHANGED=0;
										Flag.BLINK=1;
										Value.BlinkTime=0;
									}
								}
								else{
									if(++Key.AdjustTimeOut>=TIME10SEC){
										Key.AdjustTimeOut=0;
										Flag.EDIT=0;
										Flag.SV_EDIT=0;
										Flag.BLINK=0;
										check_save_parameter();
										save_parameter();
										DataLast=*Xdptr;
									}
								}
							}
						}
						else{
							if(++Key.AdjustTimeOut>=TIME10SEC){
								Key.AdjustTimeOut=0;
								check_save_parameter();
								save_parameter();
								operation_mode();
							}
						}
					}
				}
			}
			break;
		case KEY_DEBOUNCE:
			if(++Key.HoldTime>=TIME50mSEC){
				key_compare();
				if(key_compare()){
					Key.New=key_load();
					switch(Key.New){
						case UPKEYVal:
							FrontKeyStatus=1;
							break;
						case DNKEYVal:
							FrontKeyStatus=2;
							break;
						case SETKEYVal:
							FrontKeyStatus=3;
							break;
					}
					FrontKeyStatusTimeout=0;
					Key.HoldTime=0;
					Key.Status=KEY_ACTIVE;
				}
				else{
					Key.Status=KEY_RELEASE;
				}
			}
			break;
		case KEY_ACTIVE:
			switch(Key.New){
				case UPKEYVal:	/*up*/
					if(lock_parameter()){
						Flag.LOCK_ON=1;
						Key.Status=KEY_RELEASE;
					}
					else{
						up_parameter();
						Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_HOLD;
					}
					break;
				case DNKEYVal:	/*down*/
					if(lock_parameter()){
						Flag.LOCK_ON=1;
						Key.Status=KEY_RELEASE;
					}
					else{
						dn_parameter();
						Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_HOLD;
					}
					break;
				case SETKEYVal:	/*set*/
					if(Status.Main==PASSWORD_MODE){
						if(!Flag.ENTER_PASSWORD){
							Flag.EDIT=1;
							Flag.ENTER_PASSWORD=1;
						}
						else{
							if(Value.Password[0]==6&&Value.Password[1]==3&&Value.Password[2]==4){
								if(Flag.CONFIG_MODEL){
									config_relay_mode();
								}
								else{
									calibrate_mode();
								}
							}
							else{
								_reset_init();
							}
						}
						Key.Status=KEY_RELEASE;	
					}
					else if(Status.Main==CALIBRATE_INPUT_MODE){
						if(!Flag.CALEN){
							Flag.CALEN=1;
							Flag.WAITING=0;
						}
						else{
							if(!Flag.START_CAL){
								Flag.START_CAL=1;
								Flag.WAITING=0;
							}
							else{
								if(Flag.WAITING){
									calibrate_routine();
								}
							}
						}
						Key.Status=KEY_RELEASE;	
					}
					else if(Status.Main==CONFIG_RELAY_MODE){
						check_save_parameter();
						save_parameter();
						_reset_init();
						Key.Status=KEY_RELEASE;	
					}
					else{
						if(Flag.SV_EDIT){
							Flag.SV_EDIT=0;
							Flag.SV_CHANGED=0;
							check_save_parameter();
							save_parameter();
							DataLast=*Xdptr;
						}
						else{
							if(!Flag.SETTING){
								edit_alarm();
							}
							else{
								setting_parameter_next();
							}
						}
						Key.Status=KEY_HOLD;	
					}
					break;
				default:
					Key.Status=KEY_RELEASE;	
					break;
			}
			break;
		case KEY_HOLD:
			switch(Key.New){
				case UPKEYVal:	/*up*/
					if(UPKEY){
						if(++Key.HoldTime>=TIME500mSEC){
							Key.HoldTime=0;
							up_parameter();
							Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_1;
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
				case DNKEYVal:	/*down*/
					if(DNKEY){
						if(++Key.HoldTime>=TIME500mSEC){
							Key.HoldTime=0;
							dn_parameter();
							Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_1;
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
				case SETKEYVal:	/*down*/
					if(SETKEY){
						if(++Key.HoldTime>=TIME2SEC){
							Key.HoldTime=0;
							if(!Flag.SETTING){
								if(Flag.EDIT){
									check_save_parameter();
									save_parameter();
								}
								setting_parameter_mode();
								Key.Status=KEY_STEP_PLUS_1;
							}
							else{
								save_parameter();
								operation_mode();
								Key.Status=KEY_RELEASE;
							}
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
			}
			break;
		case KEY_STEP_PLUS_1:
			switch(Key.New){
				case UPKEYVal:	/*up*/
					if(UPKEY){
						if(++Key.HoldTime>=TIME100mSEC){
							Key.HoldTime=0;
							up_parameter();
							if(++Key.Hold>=98){
								Key.Hold=0;
								Key.Status=KEY_STEP_PLUS_10;
							}
							else{
								Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_1;
							}
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
				case DNKEYVal:	/*down*/
					if(DNKEY){
						if(++Key.HoldTime>=TIME100mSEC){
							Key.HoldTime=0;
							dn_parameter();
							if(++Key.Hold>=98){
								Key.Hold=0;
								Key.Status=KEY_STEP_PLUS_10;
							}
							else{
								Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_1;
							}
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
				case SETKEYVal:	/*down*/
					if(SETKEY){
						if(++Key.HoldTime>=TIME5SEC){
							Key.HoldTime=0;
							password_mode();
							Key.Status=KEY_RELEASE;
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
			}
			break;
		case KEY_STEP_PLUS_10:
			switch(Key.New){
				case UPKEYVal:	/*up*/
					if(UPKEY){
						if(++Key.HoldTime>=TIME100mSEC){
							Key.HoldTime=0;
							up_parameter();
							if(++Key.Hold>=100){
								Key.Hold=0;
								Key.Status=KEY_STEP_PLUS_100;
							}
							else{
								Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_10;
							}
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
				case DNKEYVal:	/*down*/
					if(DNKEY){
						if(++Key.HoldTime>=TIME100mSEC){
							Key.HoldTime=0;
							dn_parameter();
							if(++Key.Hold>=100){
								Key.Hold=0;
								Key.Status=KEY_STEP_PLUS_100;
							}
							else{
								Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_10;
							}
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
			}
			break;
		case KEY_STEP_PLUS_100:
			switch(Key.New){
				case UPKEYVal:	/*up*/
					if(UPKEY){
						if(++Key.HoldTime>=TIME100mSEC){
							Key.HoldTime=0;
							up_parameter();
							Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_100;
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
				case DNKEYVal:	/*down*/
					if(DNKEY){
						if(++Key.HoldTime>=TIME100mSEC){
							Key.HoldTime=0;
							dn_parameter();
							Key.Status=(Flag.VALUELIMIT) ? KEY_RELEASE : KEY_STEP_PLUS_100;
						}
					}
					else{
						Key.Status=KEY_RELEASE;
					}
					break;
			}
			break;
		case KEY_RELEASE:
			 if(key_release()){
				Flag.VALUELIMIT=0;
				Flag.LOCK_MODE=0;
				//Flag.BLINK=0;
				if(Flag.LOCK_ON){
					Flag.LOCK_ON=0;
				}
				Key.HoldTime=0;
			 	Key.Status=KEY_PRESS;
			}
			break;
	}
}

