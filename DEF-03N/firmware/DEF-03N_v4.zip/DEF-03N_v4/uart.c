#include <msp430.h>
#include "uart.h"
#include "global.h"

#define UART_DIVISOR 437U

void uart_init(void)
{
    UCA0CTL1 = UCSWRST;
    UCA0CTL0 = 0U;                    /* 8 data bits, no parity, 1 stop bit */
    UCA0CTL1 |= UCSSEL_2;             /* SMCLK = 8.388608 MHz */
    
    P2SEL |= BIT4 | BIT5;             /* P2.4 = UCA0TXD, P2.5 = UCA0RXD (ตรงตามวงจรจริง) */
    
    P2DIR |= BIT4;                    /* P2.4 (UCA0TXD / CPU_TX) ต้องเป็น OUTPUT */
    P2DIR &= ~BIT5;                   /* P2.5 (UCA0RXD / CPU_RX) ต้องเป็น INPUT */

    UCA0BR0 = (unsigned char)(UART_DIVISOR & 0x00FFU);
    UCA0BR1 = (unsigned char)(UART_DIVISOR >> 8);
    UCA0MCTL = 0U;                    /* 19,200 bps */
    
    UCA0CTL1 &= (unsigned char)~UCSWRST;
    IE2 |= UCA0RXIE;                  /* เปิดใช้งาน UART RX Interrupt */
}

void uart_putc(char c)
{
    while ((IFG2 & UCA0TXIFG) == 0U) {
    }
    UCA0TXBUF = (unsigned char)c;
}

void uart_write(const char *text)
{
    while (*text != '\0') {
        uart_putc(*text++);
    }
}

unsigned char uart_rx_ready(void)
{
    return (unsigned char)((IFG2 & UCA0RXIFG) != 0U);
}

char uart_getc(void)
{
    while (uart_rx_ready() == 0U) {
    }
    return (char)UCA0RXBUF;
}

int putchar(int c)
{
    if (c == '\n') {
        uart_putc('\r');
    }
    uart_putc((char)c);
    return c;
}

// รับข้อมูลจากพอร์ตมาเก็บใน buffer
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
    // คือการเช็คว่า "มีข้อมูลเข้ามาหรือยัง?"
    if (IFG2 & UCA0RXIFG) 
    {
        u8 rx_data = UCA0RXBUF; // อ่านค่าออกมารอบเดียวก่อนเพื่อเคลียร์ Hardware Flag ป้องกันการแย่งข้อมูล

        /* Keep a completed request stable until main has processed it. */
        if (!Modbus.FrameReady && Modbus.ByteReq < sizeof(Modbus.ReqBuf)) {
            Modbus.ReqBuf[Modbus.ByteReq++] = rx_data;
            
            // ถ้าได้รับข้อมูลมาถึงไบต์ที่ 2 (ซึ่งตามโครงสร้าง Modbus RTU คือ Function Code)
            // ให้เอามาเก็บไว้ใน Mb_Func 
            // if (Modbus.ByteReq == 2) {
            //     Modbus.Mb_Func = rx_data; 
            // }
        } 
        else {
            // บัฟเฟอร์เต็ม (ป้องกันข้อมูลล้น)
            volatile u8 dummy = rx_data;
        }

        if (!Modbus.FrameReady) {
            Modbus.RxTimeOut = 0; // รีเซ็ตเวลาเพื่อเริ่มต้นนับช่วงเงียบใหม่ (T3.5)
            Modbus.Frx = 1;       // เซ็ต Flag ว่ากำลังอยู่ในช่วงรับข้อมูล
        }
    }
}
