typedef float f32;	
typedef unsigned long u32;	
typedef long s32;
typedef unsigned int u16;	
typedef int s16; 
typedef unsigned char u8;  
typedef char s8; 

typedef struct{
	u8 Status;
	u8 Last;
	u8 New;
	u8 PassWordStep;
	u8 PassWord;
	u8 Hold;
	u16 HoldTime;
	u16 AdjustTimeOut;
}Key_sType;

typedef struct{
	u8 Status;
	u16 SamplingCount;
	s32 Output;
	s32 Output_1;
	s32 Pterm;
	s32 Iterm;
	s32 Dterm;
	s32 Err;
	s32 Err_1;
	s32 Err_2;
	s32 sumErr;
	s32 preErr;
	s32 dErr;
	f32 ItermBuff;
	f32 Kp;
	f32 Ki;
	f32 Kd;
	s32 OutputBuffer[4];
	u32 CycleTimeOn;
	u32 CycleTime;
	u32 CycleTimeCount;
}PID_sType;


// โค้ดพิมพ์เขียว
typedef struct{	
	s16 SVAutotune;
	s16 SV2;				
	
	s16 CTAbnormal2;	/*52*/
	s16 CTMornitor2;	/*51*/
	s16 FunctionAbnormal2;	/*50*/
	s16 CTAbnormal1;	/*45*/
	s16 CTMornitor1;	/*44*/
	s16 FunctionAbnormal1;	/*43*/
	s16 DeadBand;	/*38*/
	s16 PositionOff2;	/*37*/
	s16 PositionOn2;	/*36*/
	s16 ManualReset;	/*33*/
	s16 CycleTime2;	/*32*/
	s16 DerivetiveTime2;	/*31*/
	s16 IntregralTime2;	/*30*/
	s16 ProportionalBand2;	/*29*/
	s16 ManipulatedLimitLow2;	/*28*/
	s16 ManipulatedLimitHigh2;	/*27*/
	s16 Manipulated2;	/*26*/
	s16 CycleTime1;	/*25*/
	s16 DerivetiveTime1;	/*24*/
	s16 IntregralTime1;	/*23*/
	s16 ProportionalBand1;	/*22*/
	s16 ManipulatedLimitLow1;	/*21*/
	s16 ManipulatedLimitHigh1;	/*20*/
	s16 Manipulated1;	/*19*/
	s16 AutotuneFactor;	/*17*/
	s16 Autotune;	/*16*/
	s16 Control;	/*15*/	
	s16 SlaveAddress;	/*11*/
	s16 Baudrate;	/*10*/
	s16 FunctionKey;	/*9*/
	s16 SVLimitHigh;		/*8*/
	s16 SVLimitLow;			/*7*/
	u16 TableRTD[8];		/*27-30*/
	u16 TableADCMEM0[4][2];	/*19-26*/
	

	u16 TableNTC10K[10];	/*27-36*/
	u16 TableNTC2K[11];		/*17-26*/
	
	u16 TablePTC10K[11];	/*7-16*/
	u16 TablePTC2K[7];		/*0-6*/
	
	s16 Option;				/*23*/
	s16 HysteresisAlarm2;	/*22*/
	s16 AlarmLimitLow2;		/*21*/
	s16 AlarmLimitHigh2;	/*20*/
	s16 FunctionAlarm2;		/*19*/
	s16 HysteresisAlarm1;	/*18*/
	s16 AlarmLimitLow1;		/*17*/
	s16 AlarmLimitHigh1;	/*16*/
	s16 FunctionAlarm1;		/*15*/
	s16 OutputDelayOff;		/*14*/
	s16 OutputDelayOn;		/*13*/
	s16 PositionOff1;		/*12*/
	s16 PositionOn1;		/*11*/
	s16 ModeControl;		/*10*/		
	s16 FunctionRelay;		/*9*/
	s16 StartTime;			/*8*/
	s16 LockKey;			/*7*/
	s16 ScaleCF;			/*6*/
	s16 DecimalPoint;		/*5*/
	s16 PVFilter;			/*4*/
	s16 PVAdjust;			/*3*/
	s16 Input;				/*2*/
	s16 SV;					/*1*/
	
	s16 PV;					/*0*/
	
    u16 TimeEditDisplay;
	s16 PASSWORD;	/*1*/

	//s32 Transfer;	
	s16 PVReal;		
	s16 TMP75Temp;		
	
	volatile s16 SampleSD16_0;
	s16 SampleSD16_1;
	s16 SampleSD16_2;
	s16 PointCalibrate;
	s16 ValueCalibrate;
	s16 BlinkTime;
	s16 STBlinkTime;

	
	s16 MeterCmd;       // คำสั่ง Voltmeter/Ohmmeter จาก Modbus
	s16 MeterStatus;    // สถานะ Voltmeter/Ohmmeter ให้ Modbus อ่าน
	
	s16 Selection;
	s16 TypeInput;
	s16 TypeOutput1;
	s16 TypeOutput2;
	s16 ManualOutput;	
	
	volatile u16 ADCMEM0;	
	volatile u16 ADCMEM1;
	u16 ADCMEM2;
	u16 FAdcNTC;
	u32 ADCMEM1SUM;
	u32 ADCMEM2SUM;
	volatile u16 ADC_Buff1[8];
	volatile u16 ADC_Buff2[4];
	s16 PVBuffer[128];
	
	volatile u16 Fadc;
	u16 Fadc1;

	u16 mSecCountOutput;
	u16 SecCountOutput;
	
	u16 mSecCountAlarm;
	u16 SecCountAlarm;
	
	f32 AnalogMeasure;	
	f32 R_NTC;	
	f32 R_PT100;			
	f32 T_NTC;		
	f32 T_TMP75;	
	f32 NTCCoefficients;

	f32 VoltPerLSB;   // ค่า Volt ต่อ 1 LSB คำนวณจากแรงดันอ้างอิงที่รู้ค่า
	f32 VoltMv;       // ผลลัพธ์แรงดันที่คำนวณได้ (mV)
	f32 Vcc;          // เพิ่มบรรทัดนี้ — แรงดันอ้างอิงที่ cal ได้จริง (V)
	f32 Rsensor;      // เพิ่มบรรทัดนี้ — ค่าความต้านทานที่คำนวณได้ (Ohm)
	u16 OhmCalAdc[6];

	s8 Password[4];
}Value_sType;

typedef struct{
	u8 Initial;
	u8 Main;
	u8 Output1;
	u8 Output2;
}Status_sType;

typedef struct{
	u16 mSecx2;
	u16 Sec;
	u16 Min;
}Counter_sType;

typedef union{
	u32 Word;
	struct{
		u32 AL1SQ:1;
		u32 AL2SQ:1;
		u32 EDIT:1;
		u32 RL_ON:1;
		
		u32 RL_OFF:1;
		u32 SAVETOFLASH:1;
		u32 WAITING:1;
		u32 BLINK:1;
		u32 MODBUS_SAVE:1;
		
		u32 VALUELIMIT:1;
		u32 LOCK_ON:1;
		u32 SETTING:1;
		u32 SIGN:1;
		
		u32 CONFIG_MODEL:1;
		u32 CALEN:1;
		u32 START_CAL:1;
		u32 START_TIME:1;
		
		u32 DP_CHANGED:1;
		u32 ST_BLINK:1;
		u32 PID2EN:1;
		u32 OUT1ON:1; 
		
		u32 SV_CHANGED:1;	
		u32 SV_EDIT:1; 	
		u32 ALARM_EDIT:1;
		u32 HEATER_ABNORMAL:1; 
		
		u32 UPDATE_DTERM_2:1; 		
		u32 LOCK_MODE:1; 
		u32 DP:1; 
		u32 ENTER_PASSWORD:1; 
		
		u32 POWER_RESET:1; 
		u32 POWER_RESET_FOR_TEMP:1; 
		u32 UPDATE_TEMPERATURE:1; 
		u32 UPDATE_ADC:1; 
	};
}Flag_uType;

typedef union{
	u32 Word;
	struct{
		u32 UPDATE_TEMPERATURE:1;
		u32 UPDATE_ADC:1;
		u32 ALARM1OUT:1;
		u32 ABNORMAL1OUT:1;
		
		u32 ALARM2OUT:1;
		u32 ABNORMAL2OUT:1;
		u32 AT:1;
		u32 BLINK:1;
		
		u32 VALUELIMIT:1;
		u32 LOCK1:1;
		u32 SETTING:1;
		u32 SIGN:1;
		
		u32 PASSWORD:1;
		u32 CALEN:1;
		u32 HEATER_DELAY:1;
		u32 UPDATE_DTERM_1:1;
		
		u32 DP_CHANGED:1;
		u32 PID1EN:1;
		u32 PID2EN:1;
		u32 MANUAL:1;
		
		u32 FRX:1;
		u32 OUT1ON:1; 
		u32 HEATER_ABNORMAL:1; 
		u32 UPDATE_DTERM_2:1; 
		
		u32 CONFIG:1; 
		u32 DP:1; 
		u32 FTX:1; 
		u32 START_TIME:1; 
		
		u32 POWER_RESET:1; 
		u32 POWER_RESET_FOR_TEMP:1; 
		u32 PID1_FIRST_TIME:1; 
		u32 PID2_FIRST_TIME:1; 
	};
}Flag1_uType;
typedef union{
	u8 Byte;
	struct{
		u8 PVHIGHLIMIT:1;
		u8 PVLOWLIMIT:1;
		u8 NOINPUT:1;
		u8 IGNORE:5;
	};
}ERROR_uType;

typedef union{
	u16 Word;
	struct{
		u8 Lo;
		u8 Hi;
	}byte;
}U_uInt;
typedef union{
	u8 Byte;
	struct{
		u8 NC1:1;
		u8 NC2:1;
		u8 NC3:1;
		u8 NC4:1;
		u8 NC5:1;
		u8 NC6:1;
		u8 AL2:1;
		u8 AL1:1;	
	};
}Led_uType;

typedef struct{
	u8 ReqBuf[64];
	u8 RspBuf[64];
	volatile u8 ByteReq;
	u8 ByteRsp;
	volatile u16 RxTimeOut;
	u16 TxTimeOut;
	u8 CrcHi;
	u8 CrcLo;
	volatile u8 Mb_Func;
	volatile u8 Frx;
	volatile u8 RxLength;
	volatile u8 FrameReady;
}Modbus_sType;
