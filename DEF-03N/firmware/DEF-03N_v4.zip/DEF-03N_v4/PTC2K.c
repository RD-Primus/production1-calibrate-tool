#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"
#include "ptc2k_table.h"

void get_PTC2K(void){	
	f32 rptc, tbl, tbh, r0, t0;
#if 0
#if 1
	vin=22178;
	vin=(vin/65535)*0.0375;
	vin=(vin*332000)/2000;
#else	
	vin=43930;
	vin=(vin/65535)*0.0375;
	vin=(vin*334000)/4000;
#endif	
		
	vout=Value.Fadc;
	vout=(vout/65535)*0.0375;
	rx=vout/vin;
	rptc=(330000*rx)/(1-rx);
	Value.R_PT100=rptc;
		
#else
	rptc=Value.Fadc;
	
	if(rptc<Value.TablePTC2K[POINT_0]){
		tbl=Value.TablePTC2K[POINT_0];
		tbh=Value.TablePTC2K[POINT_1];
		r0=1000;
	}
	else if(rptc<Value.TablePTC2K[POINT_1]){
		tbl=Value.TablePTC2K[POINT_0];
		tbh=Value.TablePTC2K[POINT_1];
		r0=1000;
	}
	else if(rptc<Value.TablePTC2K[POINT_2]){
		tbl=Value.TablePTC2K[POINT_1];
		tbh=Value.TablePTC2K[POINT_2];
		r0=1500;
	}
	else if(rptc<Value.TablePTC2K[POINT_3]){
		tbl=Value.TablePTC2K[POINT_2];
		tbh=Value.TablePTC2K[POINT_3];
		r0=2000;
	}
	else if(rptc<Value.TablePTC2K[POINT_4]){
		tbl=Value.TablePTC2K[POINT_3];
		tbh=Value.TablePTC2K[POINT_4];
		r0=2500;
	}
	else if(rptc<Value.TablePTC2K[POINT_5]){
		tbl=Value.TablePTC2K[POINT_4];
		tbh=Value.TablePTC2K[POINT_5];
		r0=3000;
	}
	else{
		tbl=Value.TablePTC2K[POINT_5];
		tbh=Value.TablePTC2K[POINT_6];
		r0=3500;
	}
	rptc=(((rptc-tbl)/(tbh-tbl))*500)+r0;
	Value.R_PT100=rptc;
#endif	

	Error.Byte=0;
	if(rptc<1000){
		Error.PVLOWLIMIT=1;		
		t0=-40;
	}
	else if(rptc>4200){
		Error.PVHIGHLIMIT=1;
		t0=130;
	}
	else{
		if(rptc<PTC2KTable[POINT_0]){
			tbl=PTC2KTable[POINT_0];
			tbh=PTC2KTable[POINT_1];
			t0=-40;
		}
		else if(rptc<PTC2KTable[POINT_1]){
			tbl=PTC2KTable[POINT_0];
			tbh=PTC2KTable[POINT_1];
			t0=-40;
		}
		else if(rptc<PTC2KTable[POINT_2]){
			tbl=PTC2KTable[POINT_1];
			tbh=PTC2KTable[POINT_2];
			t0=-30;
		}
		else if(rptc<PTC2KTable[POINT_3]){
			tbl=PTC2KTable[POINT_2];
			tbh=PTC2KTable[POINT_3];
			t0=-20;
		}
		else if(rptc<PTC2KTable[POINT_4]){
			tbl=PTC2KTable[POINT_3];
			tbh=PTC2KTable[POINT_4];
			t0=-10;
		}
		else if(rptc<PTC2KTable[POINT_5]){
			tbl=PTC2KTable[POINT_4];
			tbh=PTC2KTable[POINT_5];
			t0=0;
		}
		else if(rptc<PTC2KTable[POINT_6]){
			tbl=PTC2KTable[POINT_5];
			tbh=PTC2KTable[POINT_6];
			t0=10;
		}
		else if(rptc<PTC2KTable[POINT_7]){
			tbl=PTC2KTable[POINT_6];
			tbh=PTC2KTable[POINT_7];
			t0=20;
		}
		else if(rptc<PTC2KTable[POINT_8]){
			tbl=PTC2KTable[POINT_7];
			tbh=PTC2KTable[POINT_8];
			t0=30;
		}
		else if(rptc<PTC2KTable[POINT_9]){
			tbl=PTC2KTable[POINT_8];
			tbh=PTC2KTable[POINT_9];
			t0=40;
		}
		else if(rptc<PTC2KTable[POINT_10]){
			tbl=PTC2KTable[POINT_9];
			tbh=PTC2KTable[POINT_10];
			t0=50;
		}
		else if(rptc<PTC2KTable[POINT_11]){
			tbl=PTC2KTable[POINT_10];
			tbh=PTC2KTable[POINT_11];
			t0=60;
		}
		else if(rptc<PTC2KTable[POINT_12]){
			tbl=PTC2KTable[POINT_11];
			tbh=PTC2KTable[POINT_12];
			t0=70;
		}
		else if(rptc<PTC2KTable[POINT_13]){
			tbl=PTC2KTable[POINT_12];
			tbh=PTC2KTable[POINT_13];
			t0=80;
		}
		else if(rptc<PTC2KTable[POINT_14]){
			tbl=PTC2KTable[POINT_13];
			tbh=PTC2KTable[POINT_14];
			t0=90;
		}
		else if(rptc<PTC2KTable[POINT_15]){
			tbl=PTC2KTable[POINT_14];
			tbh=PTC2KTable[POINT_15];
			t0=100;
		}
		else if(rptc<PTC2KTable[POINT_16]){
			tbl=PTC2KTable[POINT_15];
			tbh=PTC2KTable[POINT_16];
			t0=110;
		}
		else{
			tbl=PTC2KTable[POINT_16];
			tbh=PTC2KTable[POINT_17];
			t0=120;
		}
		t0+=((rptc-tbl)*10/(tbh-tbl));
		t0=c_to_f(t0);
	}
        if(Value.ScaleCF==1)
		{
		if(t0>=267)   {	Error.PVHIGHLIMIT=1;	t0=267;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	}
		}
		else
		{
		if(t0>=131)   {	Error.PVHIGHLIMIT=1;	t0=130;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	} 
		}
	if(Flag.DP)
		{
		if(t0>=100)   
                    {	Error.PVHIGHLIMIT=1;	t0=99.8;	}   
                if(t0<-19.98)   
                    {	Error.PVLOWLIMIT=1;		t0=-19.98;	}
		}
	Value.AnalogMeasure=t0*10;
}

