#include 	"Typedef.h"

extern void _reset_init(void);
extern void ADC16A_init(void);

extern void start_time_mode(void);
extern void operation_mode(void);
extern void setting_parameter_mode(void);
extern void setting_parameter_next(void);
extern void password_mode(void);

//――――――――――――――――――――――――――――――――――――――――――//
extern void calibrate_mode(void);
extern void calibrate_routine(void);
extern void save_calibrate(void);
extern void cal_ohm_ptc2kohm_init(void);
extern void cal_ohm_ptc10kohm_init(void);
extern void cal_ohm_ntc2kohm_init(void);
extern void cal_ohm_ntc10kohm_init(void);
//――――――――――――――――――――――――――――――――――――――――――//

extern void scan_7segment(void);
extern void get_PTC2K(void);
extern void get_PTC10K(void);
extern void get_NTC2K(void);
extern void get_NTC10K(void);
extern f32 NTC_calculate(f32 rntc,f32 r25,f32 B25_100);

extern void min_max_value(void);
extern void check_save_parameter(void);
extern f32 c_to_f(f32 c);
extern s16 filter_pv(void);
extern s16 undecimal(s16 *pv);
extern s16 round_up(s32 temp);

extern void key_event(void);


extern void output1_event(void);
extern void alarm1(void);
extern void alarm2(void);

extern void write_SegA(s8* value);
extern void read_SegA(s8* value);
extern void write_SegA_n(s8* value, u8 n);
extern void read_SegA_n(s8* value, u8 n);


extern void write_SegB(s8* value);
extern void read_SegB(s8* value);
extern void write_SegC(s8* value);
extern void read_SegC(s8* value);

extern void write_SegD(s8* value);
extern void read_SegD(s8* value);

extern void (*get_input[])(void);
extern void (*display_page[])(void);

extern u8 Output1Status; 
extern u8 Output2Status; 

extern s16 Maximum;
extern s16 Minimum;
extern s16 *Xdptr;
extern s16 DataLast;

extern u8 DigitData[5];
extern u8 Digit; 
extern u8 PWColumn;

extern volatile s16 FrontKeyStatus;
extern u16 FrontKeyStatusTimeout;

extern u8 ADCMUX; 
extern u8 ADCMuxSample0;

extern s16 DATATMP175Last;

extern f32 mV;
extern f32 mVCJ;
extern f32 tmp175temp;

extern Value_sType Value;
extern Modbus_sType Modbus;

extern Key_sType Key;
extern Status_sType Status;
extern Counter_sType BaseTimeCount;
//extern PID_sType PID1;
//extern PID_sType PID2;
extern volatile Flag_uType Flag;
extern ERROR_uType Error;
//extern AL_uType AL1Hold;
//extern AL_uType AL2Hold;
extern Led_uType Led;

