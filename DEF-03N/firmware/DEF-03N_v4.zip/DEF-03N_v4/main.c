#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"
#include "Segment.h"
#include "uart.h"
#include "modbus.h"

const f32 NTC_Temp_Table[]={
	87.559,
	68.237,
	53.650,
	42.506,
	33.892,
	27.219,
	22.021,
	17.926,
	14.674,
	12.081,
	10.000,
	
	8.315,
	6.948,
	5.834,
	4.917,
	4.161,
	3.535,
	3.014,
	2.586,
	2.228,
	1.925,
	1.669
};
#if 0
const u16 NTC_ADC_Table[]={
	59426,
	55069,
	50165,
	44613,
	38255,
	30913,
	22336,
	12180,
	11061,
	9921,
	8760,
	7555,
	6375,
	5145,
	3889,
	2610,
	1305
};
#else
const u16 NTC_ADC_Table[]={
#if 0
	39745,//80K
	37377,//75K
	34993,//70K
	32601,//65K
	30147,//60K
	27767,//55K
	25281,//50K
	22281,//45K
	20369,//40K
	17900,//35K
	15405,//30K
	12935,//25K
	10413,//20K
	7876,//15K
	5329,//10K
	4812,//9K
	4307,//8K
	3789,//7K
	3274,//6K
	2689,//5K
	2245,//4K
	1695,//3K
	1178,//2K
	695//1K	
#else	
	64404,//80K
	63294,//75K
	62797,//70K
	59063,//65K
	55224,//60K
	51290,//55K
	47253,//50K
	43106,//45K
	38884,//40K
	34463,//35K
	29962,//30K
	25332,//25K
	20566,//20K
	15658,//15K
	10607,//10K
	9577,//9K
	8543,//8K
	7502,//7K
	6454,//6K
	5401,//5K
	4346,//4K
	3277,//3K
	2205,//2K
	1125//1K	
#endif	
};
#endif

void save_parameter(void);

typedef struct {
	f32 VoltPerLSB;
	f32 Vcc;
} VoltOhmCalType;

static void save_volt_ohm_cal(void){
	VoltOhmCalType cal;
	cal.VoltPerLSB = Value.VoltPerLSB;
	cal.Vcc        = Value.Vcc;
	write_SegA_n((s8 *)&cal, sizeof(VoltOhmCalType));
	__delay_cycles(DELAY_20MS_CYCLES);
	__delay_cycles(DELAY_20MS_CYCLES);
}

void get_Voltmeter(void);   
void calibrate_voltmeter(void);

void get_Ohmmeter(void);
void calibrate_ohmmeter(void);

const s16 SettingRangeMax[4][2][2]={	
	{{130,	266}, {999,	999}},
	{{130,	266}, {999,	999}},
	{{130,	266}, {999,	999}},
	{{130,	266}, {999,	999}}
};
const s16 SettingRangeMin[4][2][2]={	
	{{-40,	-40}, {-199, -199}},	
	{{-40,	-40}, {-199, -199}},
	{{-40,	-40}, {-199, -199}},
	{{-40,	-40}, {-199, -199}}
};

void (*get_input[]) (void)={
	get_PTC2K,
	get_PTC10K,
	get_NTC2K,
	get_NTC10K,
	get_Voltmeter,
	get_Ohmmeter
};

#define INPUT_HANDLER_COUNT   ((u8)(sizeof(get_input) / sizeof(get_input[0])))
#define DISPLAY_PAGE_COUNT    28U

static void update_input_safe(void)
{
	if (Value.Input >= INPUT_HANDLER_COUNT) {
		Value.Input = PTC_2K;
	}
	get_input[Value.Input]();
}

static void update_display_safe(void)
{
	if (Status.Main >= DISPLAY_PAGE_COUNT) {
		Status.Main = OPERATION_MODE;
	}
	display_page[Status.Main]();
}

void io_init(void){
	P1SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P1OUT=0;
	P1DIR=0xFF;                             // P1.1 & P1.5 to output direction
	
	P2SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P2OUT=0;
	P2DIR=0xFF;                             // P1.1 & P1.5 to output direction
	
	P3SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P3OUT=0;
	P3DIR=0x31;                             // P1.1 & P1.5 to output direction
	
	P4SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P4OUT=0;
	P4DIR=0x3F;                             // P1.1 & P1.5 to output direction
	
	P5SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P5OUT=0;
	P5DIR=0xFF;                             // P1.1 & P1.5 to output direction
	
	P7SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P7OUT=0;
	P7DIR=0xFE;                             // P1.1 & P1.5 to output direction
	
	P8SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P8OUT=0;
	P8DIR=0xFF;                             // P1.1 & P1.5 to output direction
	
	P9SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P9OUT=0;
	P9DIR=0xFF;                             // P1.1 & P1.5 to output direction
	
	P10SEL=0x00;                             // P1.1 & P1.5 to output MCLK & ACLK
	P10OUT=0;
	P10DIR=0xFF;                             // P1.1 & P1.5 to output direction

	OUT1_OFF;LED_OUT1_OFF;
	AL2_OFF;LED_AL2_OFF;
	
}
void basic_timer_init(void){
	BTCTL=BT_ADLY_2;
	//sbi(IE2, BTIE);
}
void timer_A_init(void){
	CCTL0|=CCIE;                             // CCR0 interrupt enabled
	//CCR0 = 26041;
	//CCR0 = 10416;
	CCR0 = 20000;
	TACTL = TASSEL_2 + MC_1;                  // SMCLK, continuous mode
}
void timer_B_init(void){
	TBCCTL0=CCIE;                           // CCR0 interrupt enabled
	TBCCR0=0x3fff;
	TBCTL=TBSSEL_2+MC_1;                  // SMCLK, continuous mode
}
void ADC16A_init(void){  
	/*64 Sample/Sec  SMCLK=8.388608MHz*/
	/*
	Sample/Sec=SMCLK/(SD16DIV_3 x SD16XDIV_2 x SD16OSR_1024)
	Sample/Sec=8388608/(8x16x1024)
	Sample/Sec=64 Sample/Sec
	*/
 	SD16CTL=SD16VMIDON+SD16REFON+SD16SSEL_1+SD16DIV_3+SD16XDIV_2;         // 1.2V ref, SMCLK  
 	SD16CCTL0=SD16OSR_1024; 	
	  
	switch(Value.Input){
		case PTC_2K:	/*PTC 2 K*/
			SD16INCTL0=SD16INCH_0+SD16GAIN_8+SD16INTDLY_0;   
			SD16CCTL0|=SD16UNI;
			cbi(P10OUT, BIT1);
			sbi(P10OUT, BIT2);
			break; 
		case PTC_10K:	/*PTC 10 K TFPT1206L1002FM .... 7.53K at -40 C ... 14.89K at 130 C */
			// SD16INCTL0=SD16INCH_0+SD16GAIN_2+SD16INTDLY_0;   
			SD16INCTL0=SD16INCH_0+SD16GAIN_1+SD16INTDLY_0;   
			SD16CCTL0|=SD16UNI;
			// cbi(P10OUT, BIT1);
			// sbi(P10OUT, BIT2);
			sbi(P10OUT, BIT1);
			cbi(P10OUT, BIT2);
			break; 
		case NTC_2K:	/*NTC 2 K*/
			SD16INCTL0=SD16INCH_0+SD16GAIN_1+SD16INTDLY_0;   
			SD16CCTL0|=SD16UNI;
			cbi(P10OUT, BIT1);
			sbi(P10OUT, BIT2);
			break; 
		case NTC_10K:	/*NTC 10 K NCP15XH103F03RC  .... 195.625K at -40 C ... 0.531K at 125 C */
			SD16INCTL0=SD16INCH_0+SD16GAIN_1+SD16INTDLY_0;   
			SD16CCTL0|=SD16UNI;
			sbi(P10OUT, BIT1);
			cbi(P10OUT, BIT2);
			break;

		//----
		case VOLTMETER_TEST:
			SD16INCTL0=SD16INCH_0+SD16GAIN_1+SD16INTDLY_0;   
			SD16CCTL0|=SD16UNI;
			sbi(P10OUT, BIT1);
			cbi(P10OUT, BIT2);
			break;
		//----
		case OHMMETER_TEST:
			SD16INCTL0 = SD16INCH_0 + SD16GAIN_1 + SD16INTDLY_0;
			SD16CCTL0 |= SD16UNI;
			sbi(P10OUT, BIT1);   // ต่อ connector เดียวกับ VOLTMETER_TEST (J1)
			cbi(P10OUT, BIT2);
			break;
		//----

	}      
#if 0
	SD16CCTL1=SD16UNI+SD16OSR_1024+SD16IE;
	SD16INCTL1=SD16INCH_1+SD16GAIN_2+SD16INTDLY_0;
	SD16CCTL0|=SD16SC;
	SD16CCTL1|=SD16SC;
#else
	SD16CCTL1=SD16UNI+SD16OSR_1024;
	SD16INCTL1=SD16INCH_1+SD16GAIN_1+SD16INTDLY_0;
	
	
	//SD16CCTL0|=SD16IE;
	SD16CCTL0|=SD16GRP;
	SD16CCTL1|=SD16IE;
	//SD16CCTL2|=SD16IE;
	__delay_cycles(DELAY_4MS_CYCLES);	// Delay for 1.2V ref startup  
 	SD16CCTL1|=SD16SC;
#endif  
}
U_uInt abc;
u8 show_mode = 0;
u8 saved_sensor_input = PTC_2K;  // จำโหมดเซนเซอร์ล่าสุดก่อนสลับไป volt/ohm test

void ram_init(void){
	FrontKeyStatus=0;
	FrontKeyStatusTimeout=0;

	read_SegD((s8 *)&Value.SV);
	if(Value.Input<PTC_2K||Value.Input>NTC_10K){		
		Value.SV=50;
		Value.Input=PTC_2K;
		Value.PVAdjust=0;
		Value.PVFilter=0;
		Value.DecimalPoint=0;
		Value.ScaleCF=0;
		Value.LockKey=0;
		Value.StartTime=0;
		Value.FunctionRelay=OUT1_CTRL_OUT2_NONE;
		Value.ModeControl=HEATING_HYSTERESIS;
		Value.PositionOn1=0;
		Value.PositionOff1=0;
		Value.OutputDelayOn=0;
		Value.OutputDelayOff=0;
		Value.FunctionAlarm1=0;
		Value.AlarmLimitHigh1=0;
		Value.AlarmLimitLow1=0;
		Value.HysteresisAlarm1=0;
		Value.FunctionAlarm2=0;
		Value.AlarmLimitHigh2=0;
		Value.AlarmLimitLow2=0;
		Value.HysteresisAlarm2=0;
		
		Value.TablePTC2K[POINT_0]=10222; /*1K*/
		Value.TablePTC2K[POINT_1]=15279; /*1.5K*/
		Value.TablePTC2K[POINT_2]=20281; /*2K*/
		Value.TablePTC2K[POINT_3]=25236; /*2.5K*/
		Value.TablePTC2K[POINT_4]=30141; /*3K*/
		Value.TablePTC2K[POINT_5]=34998; /*3.5K*/
		Value.TablePTC2K[POINT_6]=39807; /*4K*/
		
		Value.TablePTC10K[POINT_0]=2631; /*1K*/
		Value.TablePTC10K[POINT_1]=7756; /*3K*/
		Value.TablePTC10K[POINT_2]=12683; /*5K*/
		Value.TablePTC10K[POINT_3]=17424; /*7K*/
		Value.TablePTC10K[POINT_4]=21988; /*9K*/
		Value.TablePTC10K[POINT_5]=29385; /*11K*/
		Value.TablePTC10K[POINT_6]=30626; /*13K*/
		Value.TablePTC10K[POINT_7]=34171; /*15K*/
#if 0		
		Value.TableNTC2K[POINT_0]=1330;  /*1K*/
		Value.TableNTC2K[POINT_1]=2641;  /*2K*/
		Value.TableNTC2K[POINT_2]=3927;  /*3K*/
		Value.TableNTC2K[POINT_3]=5187;  /*4K*/
		Value.TableNTC2K[POINT_4]=6424;  /*5K*/
		Value.TableNTC2K[POINT_5]=12266; /*10K*/
		Value.TableNTC2K[POINT_6]=22479; /*20K*/
		Value.TableNTC2K[POINT_7]=31106; /*30K*/
		Value.TableNTC2K[POINT_8]=38498; /*40K*/
		Value.TableNTC2K[POINT_9]=44893; /*50K*/
#else
		Value.TableNTC2K[POINT_0]=135; /*100R*/
		Value.TableNTC2K[POINT_1]=1330;  /*1K*/
		Value.TableNTC2K[POINT_2]=2641;  /*2K*/
		Value.TableNTC2K[POINT_3]=3927;  /*3K*/
		Value.TableNTC2K[POINT_4]=5187;  /*4K*/
		Value.TableNTC2K[POINT_5]=6424;  /*5K*/
		Value.TableNTC2K[POINT_6]=12266; /*10K*/
		Value.TableNTC2K[POINT_7]=22479; /*20K*/
		Value.TableNTC2K[POINT_8]=31106; /*30K*/
		Value.TableNTC2K[POINT_9]=38498; /*40K*/
		Value.TableNTC2K[POINT_10]=44893; /*50K*/
#endif
		
		Value.TableNTC10K[POINT_0]=279;  	/*1K*/
		Value.TableNTC10K[POINT_1]=1414;  	/*5K*/
		Value.TableNTC10K[POINT_2]=2805;  	/*10K*/
		Value.TableNTC10K[POINT_3]=10545;  	/*40K*/
		Value.TableNTC10K[POINT_4]=17383;  	/*70K*/
		Value.TableNTC10K[POINT_5]=23470;  	/*100K*/
		Value.TableNTC10K[POINT_6]=28921;  	/*130K*/
		Value.TableNTC10K[POINT_7]=33832;  	/*160K*/
		Value.TableNTC10K[POINT_8]=38274;  	/*190K*/
		Value.TableNTC10K[POINT_9]=42319;  	/*220K*/
		
		Value.Option=OPTION_A;
		
		write_SegB((s8 *)&Value.TableNTC2K[NTC2K_50K-NTC2K_500R]);	
		__delay_cycles(DELAY_20MS_CYCLES);
		__delay_cycles(DELAY_20MS_CYCLES);
		write_SegC((s8 *)&Value.TablePTC2K[PTC2K_4K]);	
		__delay_cycles(DELAY_20MS_CYCLES);
		__delay_cycles(DELAY_20MS_CYCLES);
		write_SegD((s8 *)&Value.SV);			
	}

	read_SegD((s8 *)&Value.SV);	
	__delay_cycles(DELAY_20MS_CYCLES);
	__delay_cycles(DELAY_20MS_CYCLES);
	read_SegB((s8 *)&Value.TableNTC2K[NTC2K_50K-NTC2K_500R]);	
	__delay_cycles(DELAY_20MS_CYCLES);
	__delay_cycles(DELAY_20MS_CYCLES);
	read_SegC((s8 *)&Value.TablePTC2K[PTC2K_4K]);	

	{
		VoltOhmCalType cal;
		read_SegA_n((s8 *)&cal, sizeof(VoltOhmCalType));
		__delay_cycles(DELAY_20MS_CYCLES);
		__delay_cycles(DELAY_20MS_CYCLES);

		Value.VoltPerLSB = (cal.VoltPerLSB > 0.0 && cal.VoltPerLSB < 1.0) ? cal.VoltPerLSB : 0.0;
		Value.Vcc        = (cal.Vcc > 0.0 && cal.Vcc < 5.0)             ? cal.Vcc        : 0.0;
	}
	
	if(Value.Input<PTC_2K||Value.Input>NTC_10K){
		Value.Input=PTC_2K;
		write_SegD((s8 *)&Value.SV);	
	}

	Value.NTCCoefficients=NTCREF;
	Value.ManipulatedLimitHigh1=1000;
	Value.ManipulatedLimitLow1=0;
	Value.Control=OUT1_ONOFF;
	
	Flag.Word=0;
	Error.Byte=0;
	Key.Status=KEY_PRESS;
	Key.PassWord=0;
	Key.PassWordStep=0;
	Value.Selection=SET_INPUT;
	Status.Main=INIT_0_MODE;
	Output1Status=INITIAL_CONTROL;
	Flag.DP=Value.DecimalPoint;

	Digit=0;
	
	//Value.Input=PT100;
}
static u8 mcu_clk_init(void){
	u16 i;
	
	// Stop watchdog timer to prevent time out reset
	WDTCTL=WDTPW+WDTHOLD;
	
	// Power on reset 
	SVSCTL=PORON+VLD3;	
	__delay_cycles(DELAY_20MS_CYCLES);
	//
	//  ACLK = 32.768kHz, MCLK = SMCLK = DCO = default FLL = 7.995392MHz
	//	DCO= (121+1)*32.768 kHz = 7995.392 kHz
	//
	//	FLL_CTL0=0x30
	//		DCOPLUS = 0b0 	--> DCO is Divided
	//		XTS_FLL	 = 0b0 	--> Low Freq
	//		XCAPxPF  = 0b11 	--> ~10pF
	//		XT2OF	 = 0b0	--> No fault 
	//		XT1OF      = 0b0	--> LFXT1 High-Freq No fault
	//		LFOF		 = 0b0	--> LFXT1 Low-Freq No fault
	//		DCOF	 = 0b0	--> DCO oscillator No fault
	// OSCFault flag still set?
#if 0	
	FLL_CTL0|=XCAP11PF+DCOPLUS;
	// FLL_CTL0 |= DCOPLUS + XCAP11PF;           // DCO+ set, freq = xtal x D x N+1
	SCFI0|=FLLD_2+FN_2;                            // x2 DCO freq, 8MHz nominal DCO
	SCFQCTL=121;                            // (121+1) x 32768 x 2 = 7.999784 MHz
#else
	FLL_CTL0|=DCOPLUS+XCAP11PF;           	// DCO+ set, freq = xtal x D x N+1   
	SCFI0=FLLD_2+FN_2;                      		// x2 DCO freq, 8MHz nominal DCO
	SCFQCTL=127;                            			// (127+1) x 32768 x 2 = 8.388608 MHz
	FLL_CTL1|=XT2OFF;						//SMCLK & MCLK = DOCLK	=8Mhz
	for(i=0U;i<OSC_STARTUP_MAX_RETRIES;i++){
		IFG1&=(u8)~OFIFG;                  // Clear oscillator fault flag
		__delay_cycles(OSC_FAULT_SETTLE_CYCLES);
		if((IFG1&OFIFG)==0U){
			break;
		}
	}
	
#endif

	return (u8)((IFG1&OFIFG)==0U);
}
void _reset_init(void){	
	io_init();
	uart_init();
	ram_init();
	ADC16A_init();	
	basic_timer_init();	
	//timer_A_init();
	timer_B_init();
	modbus_init();
}


int main(void){
	u8 clock_ready=mcu_clk_init();
	_reset_init();

	show_mode = 0;
	saved_sensor_input = Value.Input;
	Value.MeterCmd = METER_CMD_NONE;
	Value.MeterStatus = METER_STATUS_IDLE;

	if(clock_ready!=0U){
		uart_write("DEF-03N v4 ready\r\n");
	}
	__enable_interrupt();

	/*
	 * ADC16A_init() starts the converter in _reset_init(), but Value.Faหdc is
	 * produced by two averaging stages.  At power-up ADC_Buff2[] is still
	 * filled with zeroes, so do not enter the Modbus/main loop until all four
	 * filtered slots have received real conversions.  The timeout prevents a
	 * failed ADC interrupt from hanging the controller during boot.
	 */
	{
		u8 adc_warmup_count = 0;
		u16 adc_warmup_timeout = 0;

		Flag.UPDATE_TEMPERATURE = 0;
		while((adc_warmup_count < 4U) && (adc_warmup_timeout < 250U)){
			if(Flag.UPDATE_TEMPERATURE){
				Flag.UPDATE_TEMPERATURE = 0;
				adc_warmup_count++;
			}
			__delay_cycles(DELAY_4MS_CYCLES);
			adc_warmup_timeout++;
		}
	}

	while(1){	
		/* routine every 2ms */
		if(bis(IFG2, BTIFG)){
			cbi(IFG2, BTIFG);
			if(Status.Main==INIT_0_MODE){
#if 1				
				if(!Status.Initial){
					if(++Value.TimeEditDisplay>=TIME4SEC){
						Value.TimeEditDisplay=0;
						if(SETKEY&&!UPKEY&&!DNKEY){
							password_mode();
							Key.Status=KEY_RELEASE;
						}
						else{
							Status.Initial=1;
							Flag.BLINK=0;
						}
					}
				}
				else{
					if(++Value.TimeEditDisplay>=TIME1SEC){
						Value.TimeEditDisplay=0;
						Status.Initial=0;
						Flag.EDIT=0;
						Status.Main=INIT_1_MODE;
					}
				}
#else				
				if(++Value.TimeEditDisplay>=TIME4SEC){
					Value.TimeEditDisplay=0;
					if(SETKEY&&!UPKEY&&!DNKEY){
						password_mode();
						Key.Status=KEY_RELEASE;
					}
					else{
						Flag.EDIT=0;
						Status.Main=INIT_1_MODE;
					}
				}
#endif				
			}
			else if(Status.Main==INIT_1_MODE){
				if(++Value.TimeEditDisplay>=TIME1SEC){
					Value.TimeEditDisplay=0;
					LED_AL1_OFF;
					LED_AL2_OFF;
					if(!Flag.EDIT){
						Flag.EDIT=1;
					}
					else{
						Flag.POWER_RESET_FOR_TEMP=1;
						Value.BlinkTime=0;
						Value.STBlinkTime=0;
						operation_mode();
					}	
				}
			}
			else{
				start_time_mode();
				key_event();
			 	output1_event();
				alarm1();
				alarm2();
			}
			update_display_safe();
			//scan_7segment();
		}	
		
		/* update temperature every 125ms */
	 	if(Flag.UPDATE_TEMPERATURE){			
			Flag.UPDATE_TEMPERATURE=0;
			update_input_safe();
			// check error here	//
			
			if(Value.Input==VOLTMETER_TEST){
				/* ASCII telemetry is sent only while the Modbus receiver is idle. */
				if(show_mode == 7 &&
				   Modbus.ByteReq == 0 &&
				   !Modbus.FrameReady &&
				   ((UCA0STAT & UCBUSY) == 0)) {
					char buf[64];
					s16 volt_lsb_x1000000 = (s16)(Value.VoltPerLSB * 1000000.0);  
					s16 volt_mv_x10       = (s16)(Value.VoltMv * 10.0);           

					sprintf(buf, "ADC=%d V/LSB=%d V=%d.%d mV\r\n",
							(s16)Value.Fadc,
							volt_lsb_x1000000,
							volt_mv_x10/10, volt_mv_x10%10);
					uart_write(buf);
				}
    		}
			else if(Value.Input==OHMMETER_TEST){    
				/* Stop starting new ASCII lines as soon as a Modbus request arrives. */
				if(show_mode == 8 &&
				   Modbus.ByteReq == 0 &&
				   !Modbus.FrameReady &&
				   ((UCA0STAT & UCBUSY) == 0)) {
					char buf[64];
					s16 rohm_x10 = (s16)(Value.Rsensor / 100.0);
					s16 vcc_x1000 = (s16)(Value.Vcc * 1000.0);   

					sprintf(buf, "ADC=%d Vcc=%dmV Rsen=%d.%d kOhm\r\n",
							(s16)Value.Fadc, vcc_x1000, rohm_x10/10, rohm_x10%10);   
					uart_write(buf);
				}
			}		
			else {
				//Value.PVReal=round_up((s32)(Value.AnalogMeasure*10)); 
				Value.PVReal=round_up((s32)(Value.AnalogMeasure*10)); 
				Value.PVReal=filter_pv();
				Value.PV=undecimal(&Value.PVReal);
				if(Error.PVLOWLIMIT){
					Value.PV=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				}
				if(Error.PVHIGHLIMIT){
					Value.PV=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				}
			}
	 	}

		//――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――//
		modbus();
		modbus_calibration_service();
		if (Flag.MODBUS_SAVE == 1) 
        {
            if ((UCA0STAT & UCBUSY) == 0) 
            { 
                Flag.SAVETOFLASH = 1; 
                save_parameter(); 
                
                if(Xdptr != 0) {
                    DataLast = *Xdptr; 
                }

                Flag.MODBUS_SAVE = 0; 
            }
        }
		
		//――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――//

		if(Value.MeterCmd != METER_CMD_NONE){
			if((UCA0STAT & UCBUSY) == 0){
				show_mode = 0;
				Value.MeterStatus = METER_STATUS_BUSY;

				switch(Value.MeterCmd){
					case METER_CMD_CAL_VOLTMETER:
						if(Value.Input != VOLTMETER_TEST && Value.Input != OHMMETER_TEST){
							saved_sensor_input = Value.Input;
						}
						Value.Input = VOLTMETER_TEST;
						ADC16A_init();
						{
							u8 wait_count = 0;
							while(wait_count < 5){
								if(Flag.UPDATE_TEMPERATURE){
									Flag.UPDATE_TEMPERATURE = 0;
									wait_count++;
								}
							}
						}
						if(Value.Fadc != 0){
							calibrate_voltmeter();
							show_mode = 7;
							Value.MeterStatus = METER_STATUS_VOLTMETER;
							uart_write("Modbus: Cal Voltmeter Done.\r\n");
						}
						else{
							Value.MeterStatus = METER_STATUS_ERROR;
						}
						break;

					case METER_CMD_CAL_OHMMETER:
						if(Value.Input != VOLTMETER_TEST && Value.Input != OHMMETER_TEST){
							saved_sensor_input = Value.Input;
						}
						Value.Input = OHMMETER_TEST;
						ADC16A_init();
						{
							u8 wait_count = 0;
							while(wait_count < 5){
								if(Flag.UPDATE_TEMPERATURE){
									Flag.UPDATE_TEMPERATURE = 0;
									wait_count++;
								}
							}
						}
						if(Value.Fadc != 0 && Value.VoltPerLSB > 0.0){
							calibrate_ohmmeter();
							show_mode = 8;
							Value.MeterStatus = METER_STATUS_OHMMETER;
							uart_write("Modbus: Cal Ohmmeter Done.\r\n");
						}
						else{
							Value.MeterStatus = METER_STATUS_ERROR;
						}
						break;

					case METER_CMD_SHOW_VOLTMETER:
						if(Value.Input != VOLTMETER_TEST && Value.Input != OHMMETER_TEST){
							saved_sensor_input = Value.Input;
						}
						Value.Input = VOLTMETER_TEST;
						ADC16A_init();
						if(Value.VoltPerLSB > 0.0){
							show_mode = 7;
							Value.MeterStatus = METER_STATUS_VOLTMETER;
						}
						else{
							Value.MeterStatus = METER_STATUS_ERROR;
						}
						break;

					case METER_CMD_SHOW_OHMMETER:
						if(Value.Input != VOLTMETER_TEST && Value.Input != OHMMETER_TEST){
							saved_sensor_input = Value.Input;
						}
						Value.Input = OHMMETER_TEST;
						ADC16A_init();
						if(Value.VoltPerLSB > 0.0 && Value.Vcc > 0.0){
							show_mode = 8;
							Value.MeterStatus = METER_STATUS_OHMMETER;
						}
						else{
							Value.MeterStatus = METER_STATUS_ERROR;
						}
						break;

					case METER_CMD_EXIT:
						Value.Input = saved_sensor_input;
						ADC16A_init();
						Value.MeterStatus = METER_STATUS_IDLE;
						uart_write("Modbus: Back to temperature mode.\r\n");
						break;

					default:
						Value.MeterStatus = METER_STATUS_ERROR;
						break;
				}
				Value.MeterCmd = METER_CMD_NONE;
			}
		}

	};

}

void check_save_parameter(void){

	if(Status.Main==INPUT_MODE){
		if(*Xdptr!=DataLast){
			ADC16A_init();
			Flag.SAVETOFLASH=1;
		}
	}
	else if(Status.Main==DECIMALPOINT_MODE){
		if(*Xdptr!=DataLast){
			if(DataLast==0){
				Flag.DP=1;
				Value.SV*=10;
				Value.PVAdjust*=10;
				Value.PositionOn1*=10;
				Value.PositionOff1*=10;
				Value.AlarmLimitHigh1*=10;
				Value.AlarmLimitLow1*=10;
				Value.HysteresisAlarm1*=10;
				Value.AlarmLimitHigh2*=10;
				Value.AlarmLimitLow2*=10;
				Value.HysteresisAlarm2*=10;
				
				if(Value.SV<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.SV=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.SV>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.SV=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				
				if(Value.PVAdjust<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PVAdjust=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.PVAdjust>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PVAdjust=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				
				if(Value.PositionOn1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOn1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.PositionOn1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOn1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				
				if(Value.PositionOff1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOff1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.PositionOff1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOff1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				
				if(Value.AlarmLimitHigh1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitHigh1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.AlarmLimitHigh1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitHigh1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				
				if(Value.AlarmLimitLow1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitLow1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.AlarmLimitLow1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitLow1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				
				if(Value.HysteresisAlarm1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.HysteresisAlarm1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
				if(Value.HysteresisAlarm1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.HysteresisAlarm1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			}
			else if(DataLast==1){
				Flag.DP=0;
				Value.SV/=10;
				Value.PVAdjust/=10;
				Value.PositionOn1/=10;
				Value.PositionOff1/=10;
				Value.AlarmLimitHigh1/=10;
				Value.AlarmLimitLow1/=10;
				Value.HysteresisAlarm1/=10;
				Value.AlarmLimitHigh2/=10;
				Value.AlarmLimitLow2/=10;
				Value.HysteresisAlarm2/=10;
			}
			Flag.SAVETOFLASH=1;
		}
	}
	else if(Status.Main==CONFIG_RELAY_MODE){
		if(!Flag.SAVETOFLASH){	
			if(*Xdptr!=DataLast){
				Flag.SAVETOFLASH=1;
				Value.FunctionRelay=OUT1_CTRL_OUT2_NONE;
			}
		}		
	}
	else{
		if(!Flag.SAVETOFLASH){	
			if(*Xdptr!=DataLast){
				Flag.SAVETOFLASH=1;
			}
		}
	}	

}
s16 limit_alarm_max(s16 func, u8 side, s16 high){
	s16 ret_val;
	
	switch(func){
		case DEVIATION_HI_LO_LIMIT:
		case DEVIATION_HI_LIMIT:
		case DEVIATION_LO_LIMIT:
		case DEVIATION_RANGE_HI_LO_LIMIT:
		case SEQUENCE_DEVIATION_HI_LO_LIMIT:
		case SEQUENCE_DEVIATION_HI_LIMIT:
		case SEQUENCE_DEVIATION_LO_LIMIT:
		case SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT:
			ret_val=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case ABSOLUTE_HI_LO_LIMIT:
		case ABSOLUTE_RANGE_HI_LO_LIMIT:
		case SEQUENCE_ABSOLUTE_HI_LO_LIMIT:
		case SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT:
			ret_val=(side==ALH) ? SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF] : high;
			break;
		case ABSOLUTE_HI_LIMIT:
		case ABSOLUTE_LO_LIMIT:
		case SEQUENCE_ABSOLUTE_HI_LIMIT:
		case SEQUENCE_ABSOLUTE_LO_LIMIT:
			ret_val=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
	}
	return ret_val;
}
s16 limit_alarm_min(s16 func, u8 side, s16 low){
	s16 ret_val;
	
	switch(func){
		case DEVIATION_HI_LO_LIMIT:
		case DEVIATION_HI_LIMIT:
		case DEVIATION_LO_LIMIT:
		case DEVIATION_RANGE_HI_LO_LIMIT:
		case SEQUENCE_DEVIATION_HI_LO_LIMIT:
		case SEQUENCE_DEVIATION_HI_LIMIT:
		case SEQUENCE_DEVIATION_LO_LIMIT:
		case SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT:
			ret_val=0;
			break;
		case ABSOLUTE_HI_LO_LIMIT:
		case ABSOLUTE_RANGE_HI_LO_LIMIT:
		case SEQUENCE_ABSOLUTE_HI_LO_LIMIT:
		case SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT:
			ret_val=(side==ALL) ? SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF] : low;
			break;
		case ABSOLUTE_HI_LIMIT:
		case ABSOLUTE_LO_LIMIT:
		case SEQUENCE_ABSOLUTE_HI_LIMIT:
		case SEQUENCE_ABSOLUTE_LO_LIMIT:
			ret_val=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
	}
	return ret_val;
}
void min_max_value(void){
	switch(Status.Main){
		case OPERATION_MODE:
			Xdptr=&Value.SV;	
			Minimum=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			Maximum=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case INPUT_MODE:
			Xdptr=&Value.Input;	
			Minimum=PTC_2K;
			Maximum=NTC_10K;
			break;	
		case PVADJUST_MODE:
			Xdptr=&Value.PVAdjust;
			Minimum=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			Maximum=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case PVFILTER_MODE:
			Xdptr=&Value.PVFilter;
			Minimum=0;
			Maximum=15;
			break;
		case DECIMALPOINT_MODE:
			Xdptr=&Value.DecimalPoint;
			Minimum=0;
			Maximum=1;
			break;
		case UNIT_MODE:
			Xdptr=&Value.ScaleCF;
			Minimum=0;
			Maximum=1;
			break;
		case LOCKKEY_MODE:
			Xdptr=&Value.LockKey;
			Minimum=0;
			Maximum=3;
			break;
		case STARTTIME_MODE:
			Xdptr=&Value.StartTime;
			Minimum=1;
			Maximum=599;
			break;
		case RELAYFUNC_MODE:
			Xdptr=&Value.FunctionRelay;
			Minimum=OUT1_ALARM_OUT2_NONE;
			Maximum=Value.Option==OPTION_A ? OUT1_CTRL_OUT2_NONE : OUT1_CTRL_OUT2_ALARM;
			break;
		case CONTROL_MODE:
			Xdptr=&Value.ModeControl;
			Minimum=COOLING_HYSTERESIS;
			Maximum=HEATING_TIME;
			break;
		case POSITION_ON_MODE:
			Xdptr=&Value.PositionOn1;
			Minimum=0;
			//Maximum=!Value.DecimalPoint ? 100 : 1000;
			Maximum=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case POSITION_OFF_MODE:
			Xdptr=&Value.PositionOff1;
			//Minimum=!Value.DecimalPoint ? -100 : -1000;
			//Maximum=!Value.DecimalPoint ? 100 : 1000;
			Minimum=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			Maximum=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case OUTPUT_DELAY_ON_MODE:
			Xdptr=&Value.OutputDelayOn;
			Minimum=0;
			Maximum=599;
			break;
		case OUTPUT_DELAY_OFF_MODE:
			Xdptr=&Value.OutputDelayOff;
			Minimum=0;
			Maximum=599;
			break;
		case FUNCALARM1_MODE:
			Xdptr=&Value.FunctionAlarm1;
			Minimum=NOT_USED;
			Maximum=SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT;
			break;
		case ALARM1_HI_MODE:
			Xdptr=&Value.AlarmLimitHigh1;
			Minimum=limit_alarm_min(Value.FunctionAlarm1, ALH, Value.AlarmLimitLow1);
			Maximum=limit_alarm_max(Value.FunctionAlarm1, ALH, Value.AlarmLimitHigh1);
			break;
		case ALARM1_LO_MODE:
			Xdptr=&Value.AlarmLimitLow1;
			Minimum=limit_alarm_min(Value.FunctionAlarm1, ALL, Value.AlarmLimitLow1);
			Maximum=limit_alarm_max(Value.FunctionAlarm1, ALL, Value.AlarmLimitHigh1);
			break;
		case ALARM1_HYSTERESIS_MODE:
			Xdptr=&Value.HysteresisAlarm1;
			Minimum=0;
			//Maximum=!Value.DecimalPoint ? 10 : 100;
			Maximum=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case FUNCALARM2_MODE:
			Xdptr=&Value.FunctionAlarm2;
			Minimum=NOT_USED;
			Maximum=(Value.FunctionRelay==OUT1_CTRL_OUT2_ALARM) ? SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT : SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT;
			break;
		case ALARM2_HI_MODE:
			Xdptr=&Value.AlarmLimitHigh2;
			Minimum=limit_alarm_min(Value.FunctionAlarm2, ALH, Value.AlarmLimitLow2);
			Maximum=limit_alarm_max(Value.FunctionAlarm2, ALH, Value.AlarmLimitHigh2);
			break;
		case ALARM2_LO_MODE:
			Xdptr=&Value.AlarmLimitLow2;
			Minimum=limit_alarm_min(Value.FunctionAlarm2, ALL, Value.AlarmLimitLow2);
			Maximum=limit_alarm_max(Value.FunctionAlarm2, ALL, Value.AlarmLimitHigh2);
			break;
		case ALARM2_HYSTERESIS_MODE:
			Xdptr=&Value.HysteresisAlarm2;
			Minimum=0;
			//Maximum=!Value.DecimalPoint ? 10 : 100;
			Maximum=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
			break;
		case CONFIG_RELAY_MODE:
			Xdptr=&Value.Option;
			Minimum=OPTION_A;
			Maximum=OPTION_AB;
			break;
	}
	DataLast=*Xdptr;
}
s16 round_up(s32 temp){
	u8 sign;
	
	sign=0;
	if(temp<0){
		sign=1;
		temp=-temp;
	}
	if((temp%10)>=5){
		temp+=10;
	}
	temp=temp/10;
	if(sign) temp=-temp;

	return (s16)temp;
}
s16 filter_pv(void){
	s8 i;
	s32 pvfilter;
	
	for(i=119;i>0;i--){
		Value.PVBuffer[i]=Value.PVBuffer[i-1];
	}
	Value.PVBuffer[i]=Value.PVReal;
	
	if(Value.PVFilter==0){
		pvfilter=Value.PVBuffer[0];
	}
	else{
		pvfilter=0;
		for(i=0;i<(Value.PVFilter*8);i++){
			pvfilter+=Value.PVBuffer[i];
		}
		pvfilter=pvfilter/(Value.PVFilter*8);
	}
	return (s16)pvfilter;
}
f32 c_to_f(f32 c){
	f32 f=c;

	if(Value.ScaleCF==1){
		f=f*9/5+32;
	}
	return f;
}
s16 undecimal(s16 *pv){
	if(!Flag.DP){
		*pv=round_up(*pv);
	}
	*pv+=Value.PVAdjust;
	return *pv;
}
s8 diff(u16 a, u16 b){
	s8 bool;

	bool=FALSE;
	if(a>b){
		if((a-b)>=GAPADC_R_POT){
			bool=TRUE;
		}
	}
	else{
		if((b-a)>=GAPADC_R_POT){
			bool=TRUE;
		}
	}
	return bool;
}

//------------------------------------------------------------
#define VOLTMETER_REF_VOLT   0.04  // แรงดันอ้างอิงคงที่ที่จ่ายเข้าไปจริง
void calibrate_voltmeter(void){
    if(Value.Fadc != 0){
        Value.VoltPerLSB = (f32)VOLTMETER_REF_VOLT / (f32)Value.Fadc;
		save_volt_ohm_cal();
    }
}

void get_Voltmeter(void){
    Value.VoltMv = (f32)Value.Fadc * Value.VoltPerLSB * 1000.0;
}
//-----------------------------------------------------------
#define OHM_RREF   100000.0   // ตัวต้านทานอ้างอิงที่รู้ค่าแน่นอน ใช้ตอน cal (100k Ohm)
#define OHM_R100K  100000.0   // ตัวต้านทาน 100k คงที่ในวงจร (ใช้ตอนวัดจริง)

void calibrate_ohmmeter(void){
    f32 vsen_volt;
    f32 i_ref;
    f32 v100k;

    get_Voltmeter();
    vsen_volt = Value.VoltMv / 1000.0;

    i_ref = vsen_volt / OHM_RREF;
    v100k = i_ref * OHM_R100K;
    Value.Vcc = vsen_volt + v100k;
    save_volt_ohm_cal();
}

void get_Ohmmeter(void){
    f32 vsen_volt;
    f32 denom;
    f32 i_sensor;

    get_Voltmeter();
    vsen_volt = Value.VoltMv / 1000.0;

    denom = Value.Vcc - vsen_volt;
    if(denom > 0.0001){
        i_sensor = denom / OHM_R100K;
        Value.Rsensor = vsen_volt / i_sensor;
    }
}
//---------------------------------------------------------------------------------

void get_temperature_NTC(void){
	f32 tbh, tbl, range, ntc;
	
	Value.ADCMEM1SUM+=Value.ADCMEM1;
	if(++Value.SampleSD16_2>=ADCSAMPLE2){
		Value.SampleSD16_2=0;
		Value.ADCMEM1SUM/=ADCSAMPLE2;
		Value.NTCCoefficients=1;
		Value.FAdcNTC=(u16)(Value.NTCCoefficients*Value.ADCMEM1SUM);
		Value.ADCMEM1SUM=0;
#if 1		
		if(Value.FAdcNTC>NTC_ADC_Table[R25K]){			
			if(Value.FAdcNTC>NTC_ADC_Table[R55K]){
				if(Value.FAdcNTC>NTC_ADC_Table[R80K]){
					ntc=75.0;
					tbh=NTC_ADC_Table[R80K];
					tbl=NTC_ADC_Table[R75K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R75K]){
					ntc=75.0;
					tbh=NTC_ADC_Table[R80K];
					tbl=NTC_ADC_Table[R75K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R70K]){
					ntc=70.0;
					tbh=NTC_ADC_Table[R75K];
					tbl=NTC_ADC_Table[R70K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R65K]){
					ntc=65.0;
					tbh=NTC_ADC_Table[R70K];
					tbl=NTC_ADC_Table[R65K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R60K]){
					ntc=60.0;
					tbh=NTC_ADC_Table[R65K];
					tbl=NTC_ADC_Table[R60K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R55K]){
					ntc=55.0;
					tbh=NTC_ADC_Table[R60K];
					tbl=NTC_ADC_Table[R55K];
					range=5.0;
				}
			}
			else{ 
				if(Value.FAdcNTC>NTC_ADC_Table[R50K]){
					ntc=50.0;
					tbh=NTC_ADC_Table[R55K];
					tbl=NTC_ADC_Table[R50K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R45K]){
					ntc=45.0;
					tbh=NTC_ADC_Table[R50K];
					tbl=NTC_ADC_Table[R45K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R40K]){
					ntc=40.0;
					tbh=NTC_ADC_Table[R45K];
					tbl=NTC_ADC_Table[R40K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R35K]){
					ntc=35.0;
					tbh=NTC_ADC_Table[R40K];
					tbl=NTC_ADC_Table[R35K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R30K]){
					ntc=30.0;
					tbh=NTC_ADC_Table[R35K];
					tbl=NTC_ADC_Table[R30K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R25K]){
					ntc=25.0;
					tbh=NTC_ADC_Table[R30K];
					tbl=NTC_ADC_Table[R25K];
					range=5.0;
				}
			}
		}
		else{
			if(Value.FAdcNTC>NTC_ADC_Table[R20K]){
				if(Value.FAdcNTC>NTC_ADC_Table[R20K]){
					ntc=20.0;
					tbh=NTC_ADC_Table[R25K];
					tbl=NTC_ADC_Table[R20K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R15K]){
					ntc=15.0;
					tbh=NTC_ADC_Table[R20K];
					tbl=NTC_ADC_Table[R15K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R10K]){
					ntc=10.0;
					tbh=NTC_ADC_Table[R15K];
					tbl=NTC_ADC_Table[R10K];
					range=5.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R9K]){
					ntc=9.0;
					tbh=NTC_ADC_Table[R10K];
					tbl=NTC_ADC_Table[R9K];
					range=1.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R8K]){
					ntc=8.0;
					tbh=NTC_ADC_Table[R9K];
					tbl=NTC_ADC_Table[R8K];
					range=1.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R7K]){
					ntc=7.0;
					tbh=NTC_ADC_Table[R8K];
					tbl=NTC_ADC_Table[R7K];
					range=1.0;
				}
			}
			else{
				if(Value.FAdcNTC>NTC_ADC_Table[R6K]){
					ntc=6.0;
					tbh=NTC_ADC_Table[R7K];
					tbl=NTC_ADC_Table[R6K];
					range=1.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R5K]){
					ntc=5.0;
					tbh=NTC_ADC_Table[R6K];
					tbl=NTC_ADC_Table[R5K];
					range=1.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R4K]){
					ntc=4.0;
					tbh=NTC_ADC_Table[R5K];
					tbl=NTC_ADC_Table[R4K];
					range=1.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R3K]){
					ntc=3.0;
					tbh=NTC_ADC_Table[R4K];
					tbl=NTC_ADC_Table[R3K];
					range=1.0;
				}
				else if(Value.FAdcNTC>NTC_ADC_Table[R2K]){
					ntc=2.0;
					tbh=NTC_ADC_Table[R3K];
					tbl=NTC_ADC_Table[R2K];
					range=1.0;
				}
				else{
					ntc=1.0;
					tbh=NTC_ADC_Table[R2K];
					tbl=NTC_ADC_Table[R1K];
					range=1.0;
				}
			}
		}
#else
		if(Value.FAdcNTC>NTC_ADC_Table[R80K]){
			ntc=80.0;
			tbh=NTC_ADC_Table[R80K];
			tbl=NTC_ADC_Table[R70K];
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R70K]){
			ntc=70.0;
			tbh=NTC_ADC_Table[R80K];
			tbl=NTC_ADC_Table[R70K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R60K]){
			ntc=60.0;
			tbh=NTC_ADC_Table[R70K];
			tbl=NTC_ADC_Table[R60K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R50K]){
			ntc=50.0;
			tbh=NTC_ADC_Table[R60K];
			tbl=NTC_ADC_Table[R50K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R40K]){
			ntc=40.0;
			tbh=NTC_ADC_Table[R50K];
			tbl=NTC_ADC_Table[R40K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R30K]){
			ntc=30.0;
			tbh=NTC_ADC_Table[R40K];
			tbl=NTC_ADC_Table[R30K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R20K]){
			ntc=20.0;
			tbh=NTC_ADC_Table[R30K];
			tbl=NTC_ADC_Table[R20K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R10K]){
			ntc=10.0;
			tbh=NTC_ADC_Table[R20K];
			tbl=NTC_ADC_Table[R10K];
			range=10.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R9K]){
			ntc=9.0;
			tbh=NTC_ADC_Table[R10K];
			tbl=NTC_ADC_Table[R9K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R8K]){
			ntc=8.0;
			tbh=NTC_ADC_Table[R9K];
			tbl=NTC_ADC_Table[R8K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R7K]){
			ntc=7.0;
			tbh=NTC_ADC_Table[R8K];
			tbl=NTC_ADC_Table[R7K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R6K]){
			ntc=6.0;
			tbh=NTC_ADC_Table[R7K];
			tbl=NTC_ADC_Table[R6K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R5K]){
			ntc=5.0;
			tbh=NTC_ADC_Table[R6K];
			tbl=NTC_ADC_Table[R5K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R4K]){
			ntc=4.0;
			tbh=NTC_ADC_Table[R5K];
			tbl=NTC_ADC_Table[R4K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R3K]){
			ntc=3.0;
			tbh=NTC_ADC_Table[R4K];
			tbl=NTC_ADC_Table[R3K];
			range=1.0;
		}
		else if(Value.FAdcNTC>NTC_ADC_Table[R2K]){
			ntc=2.0;
			tbh=NTC_ADC_Table[R3K];
			tbl=NTC_ADC_Table[R2K];
			range=1.0;
		}
		else{
			ntc=1.0;
			tbh=NTC_ADC_Table[R2K];
			tbl=NTC_ADC_Table[R1K];
			range=1.0;
		}
#endif		

		ntc+=((((f32)Value.FAdcNTC-tbl)*range)/(tbh-tbl));
		Value.R_NTC=ntc;
		Value.R_NTC*=1.05;
#if 1
		Value.T_NTC=NTC_calculate((Value.R_NTC*1000), 10000, 3950);
		// Value.T_NTC=NTC_calculate((Value.R_NTC*1000), 10000, 3380);
#else
#if 1
		if(Value.R_NTC>NTC_Temp_Table[T25C]){
			if(Value.R_NTC>NTC_Temp_Table[T00C]){
				if(Value.R_NTC>NTC_Temp_Table[T_25C]){
					ntc=-25.0;
					tbh=NTC_Temp_Table[T_25C];
					tbl=NTC_Temp_Table[T_20C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T_20C]){
					ntc=-20.0;
					tbh=NTC_Temp_Table[T_25C];
					tbl=NTC_Temp_Table[T_20C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T_15C]){
					ntc=-15.0;
					tbh=NTC_Temp_Table[T_20C];
					tbl=NTC_Temp_Table[T_15C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T_10C]){
					ntc=-10.0;
					tbh=NTC_Temp_Table[T_15C];
					tbl=NTC_Temp_Table[T_10C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T_05C]){
					ntc=-5.0;
					tbh=NTC_Temp_Table[T_10C];
					tbl=NTC_Temp_Table[T_05C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T00C]){
					ntc=0.0;
					tbh=NTC_Temp_Table[T_05C];
					tbl=NTC_Temp_Table[T00C];
				}
			}
			else{
				if(Value.R_NTC>NTC_Temp_Table[T05C]){
					ntc=5.0;
					tbh=NTC_Temp_Table[T00C];
					tbl=NTC_Temp_Table[T05C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T10C]){
					ntc=10.0;
					tbh=NTC_Temp_Table[T05C];
					tbl=NTC_Temp_Table[T10C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T15C]){
					ntc=15.0;
					tbh=NTC_Temp_Table[T10C];
					tbl=NTC_Temp_Table[T15C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T20C]){
					ntc=20.0;
					tbh=NTC_Temp_Table[T15C];
					tbl=NTC_Temp_Table[T20C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T25C]){
					ntc=25.0;
					tbh=NTC_Temp_Table[T20C];
					tbl=NTC_Temp_Table[T25C];
				}
			}
		}
		else{
			if(Value.R_NTC>NTC_Temp_Table[T55C]){
				if(Value.R_NTC>NTC_Temp_Table[T30C]){
					ntc=30.0;
					tbh=NTC_Temp_Table[T25C];
					tbl=NTC_Temp_Table[T30C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T35C]){
					ntc=35.0;
					tbh=NTC_Temp_Table[T30C];
					tbl=NTC_Temp_Table[T35C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T40C]){
					ntc=40.0;
					tbh=NTC_Temp_Table[T35C];
					tbl=NTC_Temp_Table[T40C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T45C]){
					ntc=45.0;
					tbh=NTC_Temp_Table[T40C];
					tbl=NTC_Temp_Table[T45C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T50C]){
					ntc=50.0;
					tbh=NTC_Temp_Table[T45C];
					tbl=NTC_Temp_Table[T50C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T55C]){
					ntc=55.0;
					tbh=NTC_Temp_Table[T50C];
					tbl=NTC_Temp_Table[T55C];
				}
			}
			else{
				if(Value.R_NTC>NTC_Temp_Table[T60C]){
					ntc=60.0;
					tbh=NTC_Temp_Table[T55C];
					tbl=NTC_Temp_Table[T60C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T65C]){
					ntc=65.0;
					tbh=NTC_Temp_Table[T60C];
					tbl=NTC_Temp_Table[T65C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T70C]){
					ntc=70.0;
					tbh=NTC_Temp_Table[T65C];
					tbl=NTC_Temp_Table[T70C];
				}
				else if(Value.R_NTC>NTC_Temp_Table[T75C]){
					ntc=75.0;
					tbh=NTC_Temp_Table[T70C];
					tbl=NTC_Temp_Table[T75C];
				}
				else{
					ntc=80.0;
					tbh=NTC_Temp_Table[T75C];
					tbl=NTC_Temp_Table[T80C];
				}
			}
		}
#else		
		if(Value.R_NTC>NTC_Temp_Table[T_25C]){
			ntc=-25.0;
			tbh=NTC_Temp_Table[T_25C];
			tbl=NTC_Temp_Table[T_20C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T_20C]){
			ntc=-20.0;
			tbh=NTC_Temp_Table[T_25C];
			tbl=NTC_Temp_Table[T_20C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T_15C]){
			ntc=-15.0;
			tbh=NTC_Temp_Table[T_20C];
			tbl=NTC_Temp_Table[T_15C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T_10C]){
			ntc=-10.0;
			tbh=NTC_Temp_Table[T_15C];
			tbl=NTC_Temp_Table[T_10C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T_05C]){
			ntc=-5.0;
			tbh=NTC_Temp_Table[T_10C];
			tbl=NTC_Temp_Table[T_05C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T00C]){
			ntc=0.0;
			tbh=NTC_Temp_Table[T_05C];
			tbl=NTC_Temp_Table[T00C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T05C]){
			ntc=5.0;
			tbh=NTC_Temp_Table[T00C];
			tbl=NTC_Temp_Table[T05C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T10C]){
			ntc=10.0;
			tbh=NTC_Temp_Table[T05C];
			tbl=NTC_Temp_Table[T10C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T15C]){
			ntc=15.0;
			tbh=NTC_Temp_Table[T10C];
			tbl=NTC_Temp_Table[T15C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T20C]){
			ntc=20.0;
			tbh=NTC_Temp_Table[T15C];
			tbl=NTC_Temp_Table[T20C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T25C]){
			ntc=25.0;
			tbh=NTC_Temp_Table[T20C];
			tbl=NTC_Temp_Table[T25C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T30C]){
			ntc=30.0;
			tbh=NTC_Temp_Table[T25C];
			tbl=NTC_Temp_Table[T30C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T35C]){
			ntc=35.0;
			tbh=NTC_Temp_Table[T30C];
			tbl=NTC_Temp_Table[T35C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T40C]){
			ntc=40.0;
			tbh=NTC_Temp_Table[T35C];
			tbl=NTC_Temp_Table[T40C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T45C]){
			ntc=45.0;
			tbh=NTC_Temp_Table[T40C];
			tbl=NTC_Temp_Table[T45C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T50C]){
			ntc=50.0;
			tbh=NTC_Temp_Table[T45C];
			tbl=NTC_Temp_Table[T50C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T55C]){
			ntc=55.0;
			tbh=NTC_Temp_Table[T50C];
			tbl=NTC_Temp_Table[T55C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T60C]){
			ntc=60.0;
			tbh=NTC_Temp_Table[T55C];
			tbl=NTC_Temp_Table[T60C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T65C]){
			ntc=65.0;
			tbh=NTC_Temp_Table[T60C];
			tbl=NTC_Temp_Table[T65C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T70C]){
			ntc=70.0;
			tbh=NTC_Temp_Table[T65C];
			tbl=NTC_Temp_Table[T70C];
		}
		else if(Value.R_NTC>NTC_Temp_Table[T75C]){
			ntc=75.0;
			tbh=NTC_Temp_Table[T70C];
			tbl=NTC_Temp_Table[T75C];
		}
		else{
			ntc=80.0;
			tbh=NTC_Temp_Table[T75C];
			tbl=NTC_Temp_Table[T80C];
		}
#endif		
		ntc-=((Value.R_NTC-tbl)*5.0)/(tbh-tbl);
		Value.T_NTC=ntc;
		if(Value.T_NTC<-25.0) Value.T_NTC=-25.0;
		if(Value.T_NTC>80.0) Value.T_NTC=80.0;		
#endif		
	}
}

#pragma vector=SD16A_VECTOR
__interrupt void ADC16A_ISR(void){
	s16 i, j;
	u16 temp;	
	s32 buffer;

	switch(SD16IV){
		case SD16IV_SD16MEM0:
			Value.ADCMEM0=SD16MEM0;  
			//Value.ADCMEM2=SD16MEM2; 
					
			Flag.UPDATE_ADC=1;
			Value.ADC_Buff1[Value.SampleSD16_0]=Value.ADCMEM0;
			if(++Value.SampleSD16_0>=ADCSAMPLE0){
				Value.SampleSD16_0=0;
				for(i=0;i<ADCSAMPLE0-1;i++){
					for(j=i+1;j<ADCSAMPLE0;j++){
						if(Value.ADC_Buff1[i]>Value.ADC_Buff1[j]){
							temp=Value.ADC_Buff1[j];
							Value.ADC_Buff1[j]=Value.ADC_Buff1[i];
							Value.ADC_Buff1[i]=temp;
						}
					}
				}
				buffer=0;
				for(i=2;i<=5;i++) buffer+=Value.ADC_Buff1[i];
				for(i=0;i<3;i++) Value.ADC_Buff2[i]=Value.ADC_Buff2[i+1];
				Value.ADC_Buff2[i]=buffer/4;
				buffer=0;
				for(i=0;i<4;i++) buffer+=Value.ADC_Buff2[i];
				Value.Fadc=buffer/4;
				Flag.UPDATE_TEMPERATURE=1;
			}	
			break;
		case SD16IV_SD16MEM2:
			break;
		case SD16IV_SD16MEM1:
			Value.ADCMEM0=SD16MEM0;  
			Value.ADCMEM1=SD16MEM1; 
			//Value.ADCMEM2=SD16MEM2; 
					
			Flag.UPDATE_ADC=1;
			Value.ADC_Buff1[Value.SampleSD16_0]=Value.ADCMEM0;
			if(++Value.SampleSD16_0>=ADCSAMPLE0){
				Value.SampleSD16_0=0;
				for(i=0;i<ADCSAMPLE0-1;i++){
					for(j=i+1;j<ADCSAMPLE0;j++){
						if(Value.ADC_Buff1[i]>Value.ADC_Buff1[j]){
							temp=Value.ADC_Buff1[j];
							Value.ADC_Buff1[j]=Value.ADC_Buff1[i];
							Value.ADC_Buff1[i]=temp;
						}
					}
				}
				buffer=0;
				for(i=2;i<=5;i++) buffer+=Value.ADC_Buff1[i];
				for(i=0;i<3;i++) Value.ADC_Buff2[i]=Value.ADC_Buff2[i+1];
				Value.ADC_Buff2[i]=buffer/4;
				buffer=0;
				for(i=0;i<4;i++) buffer+=Value.ADC_Buff2[i];
				Value.Fadc=buffer/4;
				Flag.UPDATE_TEMPERATURE=1;
			}	
			get_temperature_NTC();
			break;
		default:
			break;
	}
}

#pragma vector=BASICTIMER_VECTOR
__interrupt void basic_timer_ISR(void){
}

#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A (void){
}

// Timer B0 interrupt service routine
#pragma vector=TIMERB0_VECTOR
__interrupt void Timer_B (void)
{
    scan_7segment(); 
    modbus_timeout_check(); 
    modbus_calibration_tick();
}




