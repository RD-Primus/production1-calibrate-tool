#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"
#include "Segment.h"

/*|dp|g|f|e|d|c|b|a| active low*/
const u8 Segment[]={
	FONT_0,
	FONT_1,
	FONT_2,
	FONT_3,
	FONT_4,
	FONT_5,
	FONT_6,
	FONT_7,
	FONT_8,
	FONT_9,
	FONT_A,		
	FONT_B,		
	FONT_C,		
	FONT_D,		
	FONT_E,		
	FONT_F		
};

void display_page0(void);
void display_page1(void);
void display_page2(void);
void display_page3(void);
void display_page4(void);
void display_page5(void);
void display_page6(void);
void display_page7(void);
void display_page8(void);
void display_page9(void);
void display_page10(void);
void display_page11(void);
void display_page12(void);
void display_page13(void);
void display_page14(void);
void display_page15(void);
void display_page16(void);
void display_page17(void);
void display_page18(void);
void display_page19(void);
void display_page20(void);
void display_page21(void);
void display_page22(void);
void display_page23(void);
void display_page24(void);
void display_page25(void);
void display_page26(void);
void display_page27(void);

void (*display_page[])(void)={
	display_page0,
	display_page1,
	display_page2,
	display_page3,
	display_page4,
	display_page5,
	display_page6,
	display_page7,
	display_page8,
	display_page9,
	display_page10,
	display_page11,
	display_page12,
	display_page13,
	display_page14,
	display_page15,
	display_page16,
	display_page17,
	display_page18,
	display_page19,
	display_page20,
	display_page21,
	display_page22,
	display_page23,
	display_page24,
	display_page25,
	display_page26,
	display_page27
};


void scan_7segment(void){
	P8OUT=0xE0;
	P9OUT=DigitData[Digit];
	//P3OUT^=(Digit==2) ? 0x01 : ((Digit==0) ? 0x04 : 0x1<<Digit);
	P8OUT^=(0x20<<Digit);
	if(++Digit>2) Digit=0;
}
void set_char(u8 *p, s16 a, s16 b, s16 c){
	*p++=a;
	*p++=b;
	*p=c;
}
void set_time(s16 val){
	Counter_sType t;
	u8 chr[3];

	t.Min=val/60;
	t.Sec=val%60;
	
	chr[0]=t.Min%10;
	chr[1]=(t.Sec/10)%10;
	chr[2]=t.Sec%10;

	DigitData[0]=Segment[chr[0]]&FONT_DP;
	DigitData[1]=Segment[chr[1]];
	DigitData[2]=Segment[chr[2]];
}
void display_lock(void){
	set_char(&DigitData[0], FONT_L, FONT_O, FONT_C);
}
void set_num_lo(s16 val){
	u8 chr[3];
	
	Flag.SIGN=0;
	if(val<0){
		Flag.SIGN=1;
		val=-val;
	}
	chr[0]=(val/100)%10;
	chr[1]=(val/10)%10;
	chr[2]=(val)%10;
	switch(Status.Main){
		case OPERATION_MODE:
			DigitData[0]=(Flag.EDIT&&Flag.BLINK&&!Flag.SV_CHANGED)? FONT_BLANK : ((Flag.SIGN) ? (!chr[0] ? FONT_MINUS : Segment[chr[0]]&FONT_MINUS) : (!chr[0] ? FONT_BLANK : Segment[chr[0]]));
			DigitData[1]=(Flag.EDIT&&Flag.BLINK&&!Flag.SV_CHANGED)? FONT_S : ((Value.DecimalPoint==0) ? ((!chr[0]&&!chr[1]) ? FONT_BLANK : Segment[chr[1]]) : Segment[chr[1]]&FONT_DP);
			DigitData[2]=(Flag.EDIT&&Flag.BLINK&&!Flag.SV_CHANGED)? ((!Flag.ST_BLINK) ? FONT_P : FONT_P&FONT_DP) : ((!Flag.ST_BLINK) ? Segment[chr[2]] : Segment[chr[2]]&FONT_DP);
			break;
		case PVADJUST_MODE:
		case SCALE_LO_MODE:
		case SCALE_HI_MODE:
		case ALARM1_HI_MODE:
		case ALARM1_LO_MODE:
		case ALARM1_HYSTERESIS_MODE:
		case ALARM2_HI_MODE:
		case ALARM2_LO_MODE:
		case ALARM2_HYSTERESIS_MODE:
		case POSITION_ON_MODE:
		case POSITION_OFF_MODE:
			DigitData[0]=((Flag.SIGN) ? (!chr[0] ? FONT_MINUS : Segment[chr[0]]&FONT_MINUS) : (!chr[0] ? FONT_BLANK : Segment[chr[0]]));
			DigitData[1]=((Value.DecimalPoint==0) ? ((!chr[0]&&!chr[1]) ? FONT_BLANK : Segment[chr[1]]) : Segment[chr[1]]&FONT_DP);
			DigitData[2]=Segment[chr[2]];
			break;
		case INIT_1_MODE:
		case INPUT_MODE:
#if 0			
			DigitData[0]=Value.Input==PT100 ? FONT_P : FONT_T;
			DigitData[1]=Value.Input==PT100 ? FONT_T : FONT_MINUS;
			DigitData[2]=Value.Input==PT100 ? FONT_MINUS : (Value.Input==TC_TYPE_K ? FONT_H : FONT_J);
#else
			DigitData[0]=FONT_BLANK;
			DigitData[1]=FONT_0;
			DigitData[2]=Segment[chr[2]];
#endif
			break;
		case DECIMALPOINT_MODE:
			DigitData[0]=FONT_BLANK;
			DigitData[1]=(Value.DecimalPoint==0) ? FONT_BLANK : FONT_0&FONT_DP;
			DigitData[2]=FONT_0;
			break;
		case FUNCALARM1_MODE:
		case FUNCALARM2_MODE:
		case RELAYFUNC_MODE:
		case CONTROL_MODE:
			DigitData[0]=FONT_BLANK;
			DigitData[1]=Segment[chr[1]];
			DigitData[2]=Segment[chr[2]];
			break;
		case CALIBRATE_INPUT_MODE:
			if( (Value.Input==NTC_10K)||(Value.Input==PTC_10K)){
				DigitData[0]=!chr[0] ? FONT_BLANK : Segment[chr[0]];
				DigitData[1]=!chr[0]&&!chr[1] ? FONT_BLANK : Segment[chr[1]];
				DigitData[2]=Segment[chr[2]];
			}
			else{
				DigitData[0]=!chr[0] ? FONT_BLANK : Segment[chr[0]];
				DigitData[1]=Segment[chr[1]]&FONT_DP;
				DigitData[2]=Segment[chr[2]];
			}
			break;
		case ROOM_TEMP_MODE:
			DigitData[0]=Segment[chr[0]];
			DigitData[1]=Segment[chr[1]]&FONT_DP;
			DigitData[2]=Segment[chr[2]];
			break;
		default:
			DigitData[0]=!chr[0] ? FONT_BLANK : Segment[chr[0]];
			DigitData[1]=!chr[0]&&!chr[1] ? FONT_BLANK : Segment[chr[1]];
			DigitData[2]=Segment[chr[2]];
			break;
	}
}
void set_num_hex(u16 value, u8 *dprt){
	*dprt++=!(value/0x100) ? FONT_BLANK : Segment[value/0x100%0x10];
	*dprt++=!(value/0x10) ? FONT_BLANK : Segment[value/0x10%0x10];
	*dprt=Segment[value%0x10];
}
void display_page0(void){	
#if 1	
	if(Status.Initial==0){
		if(!Flag.BLINK){
			set_char(&DigitData[0], FONT_8&FONT_DP, FONT_8&FONT_DP, FONT_8&FONT_DP);
			LED_AL1_ON;
			LED_AL2_ON;
		}
		else{
			set_char(&DigitData[0], FONT_BLANK, FONT_BLANK, FONT_BLANK);
			LED_AL1_OFF;
			LED_AL2_OFF;
		}
		if(++Value.BlinkTime>=TIME500mSEC){
			Value.BlinkTime=0;
			Flag.BLINK^=1;			
		}	
	}
	else{
		set_char(&DigitData[0], FONT_BLANK, FONT_V&FONT_DP, FONT_3);	/*rEv.3*/
	}
#else
	if(!Flag.BLINK){
		set_char(&DigitData[0], FONT_8&FONT_DP, FONT_8&FONT_DP, FONT_8&FONT_DP);
		LED_AL1_ON;
		LED_AL2_ON;
	}
	else{
		set_char(&DigitData[0], FONT_BLANK, FONT_BLANK, FONT_BLANK);
		LED_AL1_OFF;
		LED_AL2_OFF;
	}
	if(++Value.BlinkTime>=TIME500mSEC){
		Value.BlinkTime=0;
		Flag.BLINK^=1;			
	}	
#endif
}

void display_page1(void){
	display_page3();
}
void display_page2(void){
#if 1	
	if(!Flag.SV_EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			if(Error.PVHIGHLIMIT){
				set_char(&DigitData[0], FONT_OVER, FONT_OVER, ((!Flag.ST_BLINK) ? FONT_OVER : FONT_OVER&FONT_DP));
			}
			else if(Error.PVLOWLIMIT){
				set_char(&DigitData[0], FONT_UNDER, FONT_UNDER, ((!Flag.ST_BLINK) ? FONT_UNDER : FONT_UNDER&FONT_DP));
			}
			else{
				set_num_lo(Value.PV);
			}
		}
	}
	else{
		set_num_lo(Value.SV);
		if(++Value.BlinkTime>=TIME500mSEC){
			Value.BlinkTime=0;	
			Flag.BLINK^=1;
		}	
	}
	if(!Flag.START_TIME){
		if(++Value.STBlinkTime>=TIME250mSEC){
			Value.STBlinkTime=0;	
			Flag.ST_BLINK^=1;
		}	
	}
#else	
	set_num_hex(Value.Fadc, &DigitData[3]);
#endif
}
void display_page3(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_I, FONT_N, FONT_P);
		}
	}
	else{
		set_num_lo(Value.Input);
	}
}
void display_page4(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_P, FONT_U, FONT_S);
		}
	}
	else{
		set_num_lo(Value.PVAdjust);
	}
}
void display_page5(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_L, FONT_P, FONT_F);
		}
	}
	else{
		set_num_lo(Value.PVFilter);
	}
}
void display_page6(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_BLANK, FONT_D, FONT_P);
		}
	}
	else{
		set_num_lo(Value.DecimalPoint);
	}
}
void display_page7(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_C, FONT_SLASH, FONT_F);
		}
	}
	else{
		set_char(&DigitData[0], FONT_BLANK, FONT_UNIT, (!(Value.ScaleCF) ? FONT_C : FONT_F));
	}
}
void display_page8(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_L, FONT_O, FONT_C);
		}
	}
	else{
		set_num_lo(Value.LockKey);
	}
}
void display_page9(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_BLANK, FONT_S, FONT_T);
		}
	}
	else{
		set_time(Value.StartTime);
	}
}
void display_page10(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_BLANK, FONT_R, FONT_L);
		}
	}
	else{
		set_num_lo(Value.FunctionRelay);
	}
}
void display_page11(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_C, FONT_O, FONT_N);
		}
	}
	else{
		set_num_lo(Value.ModeControl);
	}
}
void display_page12(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_H, FONT_Y, FONT_1);
		}
	}
	else{
		set_num_lo(Value.PositionOn1);
	}
}
void display_page13(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_H, FONT_Y, FONT_2);
		}
	}
	else{
		set_num_lo(Value.PositionOff1);
	}
}
void display_page14(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_D, FONT_T, FONT_1);
		}
	}
	else{
		set_time(Value.OutputDelayOn);
	}
}
void display_page15(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_D, FONT_T, FONT_2);
		}
	}
	else{
		set_time(Value.OutputDelayOff);
	}
}
void display_page16(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_F, FONT_U, FONT_1);
		}
	}
	else{
		set_num_lo(Value.FunctionAlarm1);
	}
}
void display_page17(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_H, FONT_I, FONT_1);
		}
	}
	else{
		set_num_lo(Value.AlarmLimitHigh1);
	}
}
void display_page18(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_L, FONT_O, FONT_1);
		}
	}
	else{
		set_num_lo(Value.AlarmLimitLow1);
	}
}
void display_page19(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_H, FONT_S, FONT_1);
		}
	}
	else{
		set_num_lo(Value.HysteresisAlarm1);
	}
}
void display_page20(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_F, FONT_U, FONT_2);
		}
	}
	else{
		set_num_lo(Value.FunctionAlarm2);
	}
}
void display_page21(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_H, FONT_I, FONT_2);
		}
	}
	else{
		set_num_lo(Value.AlarmLimitHigh2);
	}
}
void display_page22(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_L, FONT_O, FONT_2);
		}
	}
	else{
		set_num_lo(Value.AlarmLimitLow2);
	}
}
void display_page23(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_H, FONT_S, FONT_2);
		}
	}
	else{
		set_num_lo(Value.HysteresisAlarm2);
	}
}
void display_page24(void){
	if(!Flag.EDIT){
		if(Flag.LOCK_ON){
			display_lock();
		}
		else{
			set_char(&DigitData[0], FONT_BLANK, FONT_C, FONT_J);
		}
	}
	else{
		set_num_lo((s16)(Value.T_NTC*10));
	}
}
void display_page25(void){
	if(!Flag.ENTER_PASSWORD){
		set_char(&DigitData[0], FONT_P, FONT_A, FONT_S);
	}
	else{
		DigitData[0]=PWColumn==0 ? (!Flag.BLINK ? Segment[Value.Password[0]] : FONT_BLANK) : Segment[Value.Password[0]];
		DigitData[1]=PWColumn==1 ? (!Flag.BLINK ? Segment[Value.Password[1]] : FONT_BLANK) : Segment[Value.Password[1]];
		DigitData[2]=PWColumn==2 ? (!Flag.BLINK ? Segment[Value.Password[2]] : FONT_BLANK) : Segment[Value.Password[2]];
		
		if(++Value.BlinkTime>=TIME250mSEC){
			Value.BlinkTime=0;
			Flag.BLINK^=1;				
		}
	}
}
void display_page26(void){
	if(!Flag.CALEN){
		set_char(&DigitData[0], FONT_R, FONT_E, FONT_S);
	}
	else{
		if(!Flag.START_CAL){
			if(Value.PointCalibrate<PTC10K_1K)
				set_char(&DigitData[0], FONT_BLANK, FONT_P, FONT_2);
			else if(Value.PointCalibrate<NTC2K_500R)
				set_char(&DigitData[0], FONT_P, FONT_1, FONT_0);
			else if(Value.PointCalibrate<NTC10K_1K)
				set_char(&DigitData[0], FONT_BLANK, FONT_N, FONT_2);
			else
				set_char(&DigitData[0], FONT_N, FONT_1, FONT_0);
			
		}
		else{
			if(!Flag.WAITING){
				set_num_lo(Value.ValueCalibrate);
				if(++Value.BlinkTime>=TIME1SEC){
					Value.BlinkTime=0;
					Flag.WAITING=1;
				}
			}
			else{
				set_num_hex(Value.Fadc, &DigitData[0]);	
			}	
		}
	}
}

void display_page27(void){
	if(!Flag.EDIT){
		set_char(&DigitData[0], FONT_O, FONT_P, FONT_T);
	}
	else{
		set_char(&DigitData[0], FONT_BLANK, FONT_A, (Value.Option==OPTION_AB ? FONT_B : FONT_N));
	}
}


