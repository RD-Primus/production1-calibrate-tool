# วิเคราะห์ Firmware DEF-03 และแนวทาง Port ไป CCS 12.8.1.00005

## 1. ขอบเขตและภาพรวม

เอกสารนี้วิเคราะห์ source ในโฟลเดอร์ `code/` ซึ่งเดิมเป็นโครงการ IAR Embedded Workbench สำหรับ MCU **MSP430F4783** แล้วสรุปแนวทางย้ายไป **Code Composer Studio 12.8.1.00005 (CCS)** โดยคงพฤติกรรมเดิมของ firmware ให้มากที่สุด

โมดูลหลักมีดังนี้

| ไฟล์ | หน้าที่ |
|---|---|
| `main.c` | startup, clock, GPIO, ADC SD16_A, timer, main loop, ADC ISR และฟังก์ชันแปลง/กรองค่า |
| `Global.c/.h` | นิยาม global objects และ prototype ที่ใช้ข้ามโมดูล |
| `Typedef.h` | type alias, structure และ bit-field/union ทั้งระบบ |
| `Config.h` | macro ของ I/O, timing, constant และ enum ของ mode |
| `Key.c` | state machine ของปุ่ม/หน้า setting และอ่านเขียน Information Flash |
| `Display.c`, `Segment.h` | สร้างข้อมูล 7-segment และ multiplex display |
| `Output.c` | control relay แบบ ON/OFF, alarm และ state machine ของ output |
| `PTC2K.c`, `PTC10K.c`, `NTC2K.c`, `NTC10K.c` | แปลง ADC/resistance เป็นอุณหภูมิ |

> ข้อสังเกต: project IAR ระบุ MSP430F4783, hardware multiplier, 430X instruction set, data/code model แบบที่ IAR เลือกไว้ และ optimization ระหว่าง Debug/Release ไม่เท่ากัน การ port รอบแรกควรใช้ optimization ต่ำก่อน เพื่อเทียบพฤติกรรมได้ง่าย

---

## 2. Startup และ Main Loop

### 2.1 ลำดับเริ่มระบบ

ลำดับจาก `main()` คือ

```text
Reset
  |
  +-- mcu_clk_init()
  |     +-- หยุด watchdog
  |     +-- เปิด SVS/POR threshold
  |     +-- ตั้ง FLL/DCO = 8.388608 MHz
  |     +-- รอ oscillator fault หาย
  |
  +-- _reset_init()
  |     +-- io_init()
  |     +-- ram_init()
  |     +-- ADC16A_init()
  |     +-- basic_timer_init()
  |     +-- timer_B_init()
  |
  +-- เปิด global interrupt
  |
  +-- while (1)
        +-- งานทุกประมาณ 2 ms จาก Basic Timer flag
        +-- งานแปลงอุณหภูมิเมื่อ ADC ISR ตั้ง flag
```

`timer_A_init()` และ `uart_init()` มีอยู่ แต่ไม่ได้ถูกเรียกใน `_reset_init()` ส่วน Basic Timer ISR และ Timer A ISR ไม่มีงานใช้งานใน build ปัจจุบัน

### 2.2 Cooperative foreground loop ทุกประมาณ 2 ms

`basic_timer_init()` ตั้ง:

```c
BTCTL = BT_ADLY_2;
// IE2 |= BTIE;       /* ถูกปิดไว้ */
```

ดังนั้น Basic Timer ไม่ได้เรียก ISR แต่ hardware ยังตั้ง interrupt flag เป็นคาบ และ main loop poll flag:

```c
if (IFG2 & BTIFG) {
    IFG2 &= ~BTIFG;
    ...
}
```

Source เดิมเขียน `bis(IFG2, BTIE)` และ `cbi(IFG2, BTIE)` โดยบน header รุ่นนี้ `BTIE`/`BTIFG` ใช้ bit position เดียวกันคนละ register จึงทำงานได้ แต่ชื่อทำให้อ่านผิดได้ง่าย ใน code CCS ควรใช้ชื่อ `BTIFG` เมื่อเข้าถึง `IFG2` โดยตรง

งานใน time slice นี้แบ่งตาม `Status.Main`:

1. `INIT_0_MODE`
   - นับ `Value.TimeEditDisplay`
   - ช่วง power-up รอประมาณ 4 วินาที
   - ถ้ากด SET โดยไม่กด UP/DOWN จะเข้า `password_mode()`
   - ถ้าไม่กด จะเปลี่ยนเฟส initial และรอเพิ่มประมาณ 1 วินาที

2. `INIT_1_MODE`
   - ทุกประมาณ 1 วินาที ปิด LED alarm
   - สลับ flag edit/initial display
   - รอบถัดไปตั้ง `POWER_RESET_FOR_TEMP` และเข้า `operation_mode()`

3. Mode ปกติ
   - `start_time_mode()` จัดการ delay ก่อนเริ่ม control
   - `key_event()` debounce/hold/แก้ค่า parameter
   - `output1_event()` state machine ของ output relay
   - `alarm1()` และ `alarm2()` ประเมิน alarm

4. ทุก mode เรียก `display_page[Status.Main]()` เพื่อสร้าง `DigitData[]`

งานเหล่านี้ไม่ใช่ ISR จึงสามารถใช้เวลานานกว่า ISR ได้ แต่ต้องเสร็จก่อน time slice ถัดไปเพื่อไม่ให้ event 2 ms หลุด เนื่องจาก flag เป็นเพียงหนึ่งบิต ไม่ใช่ counter

### 2.3 งานอัปเดตอุณหภูมิใน foreground

เมื่อ `ADC16A_ISR()` เก็บ sample ครบ 8 ค่า จะตั้ง `Flag.UPDATE_TEMPERATURE` จากนั้น main loop:

1. clear flag
2. เรียก sensor conversion ผ่าน function pointer:

   ```c
   get_input[Value.Input]();
   ```

3. แปลง `Value.AnalogMeasure` เป็นหน่วย 0.1 ด้วย `round_up()`
4. กรอง PV ด้วย `filter_pv()`
5. ปรับ decimal representation ด้วย `undecimal()`
6. clamp ค่าเมื่อ `Error.PVLOWLIMIT` หรือ `Error.PVHIGHLIMIT`

ตาราง function pointer:

| `Value.Input` | ค่า enum | ฟังก์ชัน |
|---|---:|---|
| `PTC_2K` | 0 | `get_PTC2K()` |
| `PTC_10K` | 1 | `get_PTC10K()` |
| `NTC_2K` | 2 | `get_NTC2K()` |
| `NTC_10K` | 3 | `get_NTC10K()` |

ต้องตรวจ range ของ `Value.Input` ก่อน index เสมอ โค้ด startup ตรวจและคืนค่า default แล้ว แต่ corruption ระหว่าง run ยังทำให้เรียก address ผิดได้

---

## 3. Interrupt Flow

ไม่มี “interrupt loop” แยกต่างหาก แต่มี ISR 4 จุด โดยใช้งานจริง 2 จุด:

| Vector | เปิดใช้งาน | งาน |
|---|---|---|
| `SD16A_VECTOR` | ใช่ | รับ ADC, sort/filter sample และตั้ง flag ให้ foreground |
| `TIMERB0_VECTOR` | ใช่ | multiplex 3-digit 7-segment |
| `BASICTIMER_VECTOR` | ไม่ได้ enable | ISR ว่าง; foreground poll `BTIFG` |
| `TIMERA0_VECTOR` | ไม่ได้ init | code ภายในถูก `#if 0` |

### 3.1 SD16_A ISR

ADC ถูกตั้งเป็น grouped conversion:

- SD16 channel 0: sensor input
- SD16 channel 1: auxiliary/NTC-related input
- interrupt enable อยู่ที่ channel 1
- เริ่ม conversion ด้วย `SD16CCTL1 |= SD16SC`
- ISR อ่าน `SD16IV` เพื่อรู้ source

เส้นทางหลักเมื่อ `SD16IV_SD16MEM1`:

```text
อ่าน SD16MEM0 และ SD16MEM1
  |
เก็บ MEM0 ลง ADC_Buff1[8]
  |
ครบ 8 samples?
  +-- ไม่ครบ: ออกจาก ISR
  +-- ครบ:
        sort 8 ค่า จากน้อยไปมาก
        เฉลี่ยค่า index 2..5 (ตัด outlier ต่ำ 2 และสูง 2)
        shift ADC_Buff2[4] และใส่ค่าเฉลี่ยใหม่
        เฉลี่ย ADC_Buff2 ทั้ง 4 -> Value.Fadc
        ตั้ง Flag.UPDATE_TEMPERATURE
        เรียก get_temperature_NTC()
```

การกรองจึงมีสองชั้น:

- trimmed mean 4 ค่ากลางจาก sample 8 ค่า
- moving average 4 block

ตาม comment ของ source: SMCLK 8.388608 MHz, divider `8 × 16`, OSR 1024 ทำให้ประมาณ 64 conversion/s ดังนั้น 8 sample ใช้ประมาณ 125 ms และค่าเฉลี่ยชั้นสองครอบคลุมข้อมูลประมาณ 500 ms

ข้อควรระวังในการ port:

- ตัวแปรที่ ISR และ foreground ใช้ร่วมกัน โดยเฉพาะ `Flag`, `Value.Fadc`, ADC buffers และ sample indices ควรประกาศ `volatile` หรือจัด critical section ให้ชัดเจน
- source เดิมไม่ได้ประกาศ global objects เป็น `volatile`; optimization ของ TI compiler อาจทำให้อาการต่างจาก IAR
- ISR ทำ bubble sort และ floating-point work บางส่วนผ่าน `get_temperature_NTC()` ซึ่งค่อนข้างหนัก ควรวัด ISR duration หลัง port
- อย่าย้าย conversion ทั้งหมดเข้า ISR เพิ่มในรอบแรก

### 3.2 Timer B0 ISR และ display scan

ค่าตั้ง timer:

```c
TBCCTL0 = CCIE;
TBCCR0  = 0x3FFF;               /* 16383 */
TBCTL   = TBSSEL_2 + MC_1;      /* SMCLK, up mode */
```

ที่ SMCLK 8.388608 MHz:

```text
interrupt period = (16383 + 1) / 8,388,608
                 = 1.953125 ms
```

ISR เรียก `scan_7segment()`:

- `P9OUT` ส่ง segment pattern แบบ active-low
- `P8.5..P8.7` เลือก digit
- สแกน digit 0..2 วนรอบ
- refresh ต่อ digit ประมาณ `1 / (3 × 1.953 ms) = 170.7 Hz`

### 3.3 Interrupt priority/interaction

MSP430 ปิด GIE อัตโนมัติเมื่อเข้า ISR และ source ไม่เปิด nested interrupt ดังนั้น:

- SD16 ISR สามารถหน่วง Timer B display ISR
- Timer B ISR สั้นมากและโดยปกติไม่กระทบ ADC มาก
- การเขียน flash ปิด interrupt ด้วย `_DINT()` เพื่อป้องกัน execution/ISR ระหว่าง erase/write

หลัง port ควรจับ timing ด้วย GPIO debug pin หรือ logic analyzer โดยเฉพาะ SD16 ISR และ Timer B jitter

---

## 4. โครงสร้างตัวแปร

### 4.1 Primitive type

ใน `Typedef.h`:

| Alias | เดิม | ขนาดที่คาดบน MSP430 |
|---|---|---:|
| `u8`, `s8` | `unsigned char`, `char` | 8 bit |
| `u16`, `s16` | `unsigned int`, `int` | 16 bit |
| `u32`, `s32` | `unsigned long`, `long` | 32 bit |
| `f32` | `float` | 32 bit |

เพื่อให้ layout แน่นอนใน CCS แนะนำเปลี่ยนเป็น `<stdint.h>`:

```c
typedef uint8_t  u8;
typedef int8_t   s8;
typedef uint16_t u16;
typedef int16_t  s16;
typedef uint32_t u32;
typedef int32_t  s32;
typedef float    f32;
```

ควรเพิ่ม compile-time checks:

```c
_Static_assert(sizeof(u8)  == 1, "u8 size");
_Static_assert(sizeof(u16) == 2, "u16 size");
_Static_assert(sizeof(u32) == 4, "u32 size");
_Static_assert(sizeof(f32) == 4, "f32 size");
```

ถ้า compiler mode ไม่รองรับ C11 ให้ใช้ typedef-based static assertion แทน

### 4.2 Global objects

นิยามใน `Global.c` และประกาศ `extern` ใน `Global.h`:

| Object | หน้าที่ |
|---|---|
| `Value` (`Value_sType`) | parameter, runtime value, ADC buffers, calibration tables และ time counters |
| `Key` (`Key_sType`) | state, debounce, hold, password และ edit timeout |
| `Status` (`Status_sType`) | initial flag, current UI mode, output state |
| `Flag` (`Flag_uType`) | event/control flags 32 บิต |
| `Error` (`ERROR_uType`) | PV high/low/no-input flags |
| `Led` (`Led_uType`) | LED bit representation |
| `BaseTimeCount` | counter เวลา |
| `DigitData[5]`, `Digit` | display data และ digit index |
| `Xdptr`, `DataLast`, `Maximum`, `Minimum` | pointer และ limits ระหว่างแก้ parameter |
| `Output1Status`, `Output2Status` | legacy/global output state เพิ่มเติม |

### 4.3 `Value_sType`

`Value_sType` รวมข้อมูลหลายชนิดไว้ใน object เดียว:

1. Parameter/configuration เช่น SV, input type, decimal point, relay/alarm mode
2. Calibration tables สำหรับ PTC/NTC
3. Runtime PV และค่าที่วัดจาก ADC
4. ADC sample buffers
5. display/edit counters
6. resistance/temperature แบบ floating point

ส่วน parameter ตั้งแต่ `SV` ย้อนขึ้นไปถูกผูกกับ Information Flash ด้วย pointer arithmetic แบบอิง layout ของ structure โดยตรง ดังนั้น **ห้ามจัดเรียง field, เปลี่ยน packing หรือเปลี่ยนขนาด type ในรอบ port แรก**

ให้ตรวจอย่างน้อย:

```c
sizeof(Value_sType)
offsetof(Value_sType, SV)
offsetof(Value_sType, TablePTC2K)
offsetof(Value_sType, TableNTC2K)
```

แล้วเทียบ memory dump IAR กับ CCS

### 4.4 Flag unions และ bit-field

`Flag_uType` ใช้ `u32 Word` overlay กับ bit-field 32 บิต และ `ERROR_uType` ใช้ `u8 Byte` overlay กับ bit-field การเรียง bit-field เป็น compiler-dependent แม้ MSP430 จะมักให้ผลตรงกัน จึงต้องตรวจจริง

ทางปลอดภัยระยะยาวคือแทน bit-field ด้วย mask:

```c
#define FLAG_UPDATE_TEMPERATURE (1UL << 30)
```

แต่ในรอบ migration แรกสามารถคง struct เดิม แล้วทำ unit test ตรวจว่า:

```c
Flag.Word = 0;
Flag.UPDATE_TEMPERATURE = 1;
/* ตรวจค่า Flag.Word ที่ debugger */
```

### 4.5 ข้อมูลร่วม ISR/foreground

อย่างน้อย object เหล่านี้มีการแชร์ context:

- `Flag.UPDATE_TEMPERATURE`
- `Flag.UPDATE_ADC`
- `Value.ADCMEM0/1`
- `Value.ADC_Buff1[]`, `Value.ADC_Buff2[]`
- `Value.SampleSD16_0`
- `Value.Fadc`
- `Digit` และ `DigitData[]`

แนะนำให้กำหนด `volatile` เฉพาะ object/field ที่จำเป็น หรือแยก ADC mailbox ออกจาก `Value_sType` เพื่อไม่ทำให้ compiler reload structure ทั้งก้อน อย่างไรก็ตาม การ refactor ควรทำหลัง firmware CCS ทำงานเทียบเท่าแล้ว

---

## 5. Module Initialization

### 5.1 Clock และ watchdog

`mcu_clk_init()`:

```c
WDTCTL   = WDTPW | WDTHOLD;
SVSCTL   = PORON | VLD3;
FLL_CTL0 |= DCOPLUS | XCAP11PF;
SCFI0    = FLLD_2 | FN_2;
SCFQCTL  = 127;
FLL_CTL1 |= XT2OFF;
```

clock tree ที่ source ตั้งใจใช้:

| Clock | Source/frequency |
|---|---|
| ACLK | LFXT1 32.768 kHz |
| MCLK | DCO/FLL 8.388608 MHz |
| SMCLK | DCO/FLL 8.388608 MHz |

สูตรตาม source คือ `(127 + 1) × 32.768 kHz × 2 = 8.388608 MHz`

หลังตั้งค่า มี loop clear `OFIFG` และรอจน oscillator stable ไม่มี timeout ถ้า crystal 32.768 kHz ไม่ทำงาน MCU จะค้างใน startup จึงควรตรวจ hardware crystal/capacitance และเพิ่ม timeout สำหรับ diagnostic ในรุ่นถัดไป

### 5.2 GPIO

`io_init()` กำหนด:

| Port | SEL | DIR | บทบาทที่พบใน code |
|---|---:|---:|---|
| P1 | `0x00` | `0xFF` | output ทั้ง port |
| P2 | `0x00` | `0xFF` | output; UART จะเปลี่ยน P2.4/P2.5 ถ้าเปิดใช้ |
| P3 | `0x00` | `0x31` | บาง pin output |
| P4 | `0x00` | `0x3F` | P4.6=DOWN, P4.7=SET เป็น input |
| P5 | `0x00` | `0xFF` | P5.1 = OUT1/AL1 relay |
| P7 | `0x00` | `0xFE` | P7.0=UP input, P7.1/P7.2 LED active-low |
| P8 | `0x00` | `0xFF` | digit select P8.5..P8.7 |
| P9 | `0x00` | `0xFF` | segment bus |
| P10 | `0x00` | `0xFF` | P10.7=AL2, P10.1/P10.2 sensor range/mux |

ทุก `PxOUT` ถูก clear ก่อนตั้ง direction จากนั้น macro ปิด output/LED ปรับระดับที่ต้องการอีกครั้ง

ข้อควรตรวจบน board:

- relay output active-high
- LED active-low
- key active-low และ source ไม่ได้เปิด internal pull-up; ต้องมี external pull-up
- ลำดับตั้ง `OUT` ก่อน `DIR` เพื่อไม่ให้ relay glitch

### 5.3 SD16_A ADC

ค่าหลัก:

```c
SD16CTL = SD16VMIDON | SD16REFON |
          SD16SSEL_1 | SD16DIV_3 | SD16XDIV_2;

SD16CCTL0 = SD16OSR_1024;
SD16CCTL1 = SD16UNI | SD16OSR_1024;
SD16INCTL1 = SD16INCH_1 | SD16GAIN_1 | SD16INTDLY_0;
SD16CCTL0 |= SD16GRP;
SD16CCTL1 |= SD16IE;
SD16CCTL1 |= SD16SC;
```

Channel 0 ถูกปรับตาม input type:

| Input | Gain | P10.1 | P10.2 |
|---|---:|---:|---:|
| PTC 2K | ×8 | 0 | 1 |
| PTC 10K | ×1 | 1 | 0 |
| NTC 2K | ×1 | 0 | 1 |
| NTC 10K | ×1 | 1 | 0 |

ทุก input ใช้ unipolar mode และ channel 0 ค่า `SD16INTDLY_0`

ก่อน start มี software delay ให้ reference 1.2 V เริ่มทำงาน ค่า delay ผูกกับ optimization/compiler จึงควรเปลี่ยนเป็น timer-based delay หรือคำนวณใหม่หลัง port

### 5.4 Basic Timer

`BTCTL = BT_ADLY_2` สร้างคาบประมาณ 2 ms จาก ACLK แต่ไม่ enable interrupt งาน scheduler ใช้ polling `BTIFG`

เพื่อรักษาพฤติกรรมเดิม:

- อย่า enable Basic Timer ISR ในรอบแรก
- เปลี่ยนเพียง macro ที่ poll ให้ชัดเจนเป็น `BTIFG`
- ตรวจคาบจริงด้วย GPIO

### 5.5 Timer B

Timer B ใช้ SMCLK, up mode, CCR0=16383 และเปิด CCR0 interrupt สำหรับ display refresh ทุก 1.953125 ms

ควรตั้ง counter clear อย่างชัดเจนใน CCS:

```c
TBCTL = TBSSEL_2 | MC_1 | TBCLR;
```

การเพิ่ม `TBCLR` ไม่ควรเปลี่ยน steady-state แต่ทำให้ phase เริ่มต้น deterministic

### 5.6 Timer A และ UART

ทั้งสองโมดูลไม่ได้เรียกใช้:

- Timer A ตั้งใจใช้ SMCLK/up mode และ `CCR0=20000`
- UART A0 ตั้ง ACLK/9600 baud บน P2.4/P2.5

ไม่ควรนำเข้า startup ของ CCS จนกว่าจะยืนยันว่าต้องใช้ เพราะอาจเปลี่ยน pin mux หรือเพิ่ม interrupt load

---

## 6. Information Flash และค่าเริ่มต้น

`ram_init()` อ่าน parameter จาก Information Flash:

| Segment | Address | ขนาดที่ code อ่าน/เขียน | ข้อมูล |
|---|---:|---:|---|
| D | `0x1000` | 64 bytes | parameter หลัก เริ่มอ้างจาก `Value.SV` |
| C | `0x1040` | 64 bytes | calibration PTC |
| B | `0x1080` | 64 bytes | calibration NTC |
| A | `0x10C0` | 64 bytes | มี routine แต่ไม่เห็นใช้งานใน flow หลัก |

ถ้า `Value.Input` ที่อ่านมาอยู่นอกช่วง 0..3 จะโหลด default ทั้งชุดและเขียนกลับ Flash จากนั้นตั้ง runtime state:

- `Flag.Word = 0`
- `Error.Byte = 0`
- key state = `KEY_PRESS`
- selection = `SET_INPUT`
- main state = `INIT_0_MODE`
- output state = `INITIAL_CONTROL`
- decimal-point flag ตาม parameter

### ความเสี่ยงสำคัญของ Flash routine

routine เดิม:

```c
value++;
for (i = 0; i < 64; i++, Flash_ptr++, value--) {
    *Flash_ptr = *value;
}
```

เป็นการ copy ถอยหลังจาก pointer ที่ส่งเข้าไปและพึ่ง layout ของ `Value_sType` อย่างมาก ต้องตรวจ address ต้นทางทุก byte ก่อนใช้กับ CCS

ข้อควรทำ:

1. backup Information Flash ของเครื่องตัวอย่างก่อนทดลอง
2. build utility dump byte `0x1000..0x10FF`
3. เทียบ byte mapping IAR/CCS
4. ปิด interrupt ระหว่าง erase/write เช่นเดิม
5. ตรวจ timing generator ของ Flash (`FCTL2`) ตาม datasheet; source ไม่ได้ตั้งใน routine
6. อย่า erase Segment A หากมี calibration/device data ที่ต้องเก็บ
7. เพิ่ม magic/version/CRC ใน format รุ่นใหม่ แต่ต้องมี migration path จาก format เดิม

---

## 7. ขั้นตอนสร้าง CCS Project

### 7.1 สร้าง project

1. เปิด CCS 12.8.1.00005
2. `File > New > CCS Project`
3. Target: `MSP430F4783`
4. Connection: เลือกตาม debugger จริง เช่น MSP-FET
5. Project type: Empty Project with main.c หรือ Empty Project
6. Compiler: TI MSP430 Compiler ที่ติดตั้งกับ CCS
7. ตั้ง output format เป็น ELF/EABI ตามค่า default ของ CCS

### 7.2 เพิ่ม source

เพิ่มเฉพาะ:

```text
main.c
Global.c
Key.c
Display.c
Output.c
PTC2K.c
PTC10K.c
NTC2K.c
NTC10K.c
```

และ header/table ที่เกี่ยวข้อง ไม่ควร compile `.sfr`, `.r43`, `.pbi`, `.d43` หรือ object/debug artifact จาก IAR

### 7.3 Device header

เปลี่ยนทุก:

```c
#include "msp430f4783.h"
```

เป็น:

```c
#include <msp430.h>
```

ห้ามใช้ `msp430f4783.h` และ `msp430x47x3.h` ที่มากับ IAR เพราะมี syntax `__no_init ... @ address` และ compiler-specific definitions ให้ใช้ device support package ของ TI เท่านั้น

ตรวจชื่อ register/vector กับ TI header โดยเฉพาะ:

- `SD16A_VECTOR`
- `TIMERB0_VECTOR`
- `BASICTIMER_VECTOR`
- `TIMERA0_VECTOR`
- `BTIFG`, `BTIE`

### 7.4 Compiler/ABI settings

รอบแรกแนะนำ:

- optimization: Off หรือ O0
- debug information: Full
- code/data model: เลือกตาม memory requirement ของ MSP430F4783 และ linker command file ที่ CCS สร้าง
- hardware multiplier: เปิดตาม device/default
- warning level: สูง แต่ยังไม่ใช้ warnings-as-errors จนแก้ legacy warnings ครบ
- C dialect: compiler default ที่รองรับ source เดิม

ตรวจ map file ให้แน่ใจว่า stack/heap เพียงพอ IAR project เดิมตั้ง stack และ heap ประมาณ 80 bytes แต่ code มี local arrays, floating-point และ `printf` support จึงควรวัด stack จริง ไม่คัดลอกตัวเลขนี้แบบไม่ตรวจ

### 7.5 Syntax mapping IAR ไป TI

| IAR/source เดิม | CCS/TI |
|---|---|
| `_EINT()` | `__enable_interrupt()` |
| `_DINT()` | `__disable_interrupt()` |
| `_NOP()` | `__no_operation()` |
| `#pragma vector=...` + `__interrupt` | TI compiler รองรับรูปแบบนี้; ตรวจ vector name จาก `<msp430.h>` |
| custom IAR device header | `<msp430.h>` |
| `void main(void)` | แนะนำ `int main(void)` และไม่มี return เพราะ loop ไม่จบ |
| `__low_level_put` | ไม่ใช่ TI runtime hook; ใช้ `putchar`, `fputc` หรือกำหนด low-level I/O ของ TI |

ตัวอย่าง ISR สำหรับ TI compiler:

```c
#pragma vector=SD16A_VECTOR
__interrupt void ADC16A_ISR(void)
{
    /* existing body */
}
```

### 7.6 Linker และ Information Memory

ใช้ linker command file ของ MSP430F4783 จาก TI device support ตรวจว่า:

- vector table อยู่ถูกตำแหน่ง
- Information Memory `0x1000..0x10FF` ไม่ถูกวาง section/code ทับ
- download setting ไม่ erase Information Memory โดยไม่ตั้งใจ
- `.text`, `.const`, `.data`, `.bss`, stack อยู่ใน memory ที่ถูกต้อง

สร้าง map file และค้นหา address `0x1000`, `0x1040`, `0x1080`, `0x10C0` ก่อน flash ครั้งแรก

---

## 8. การปรับ source ที่ควรทำก่อน Build แรก

รายการขั้นต่ำ:

1. ใช้ `<msp430.h>` แทน IAR headers
2. แปลง `_EINT`, `_DINT`, `_NOP`
3. แก้ `main` เป็น `int main(void)`
4. ใน main polling เปลี่ยน `BTIE` เป็น `BTIFG`
5. เพิ่ม `volatile` ให้ข้อมูลแชร์ ISR อย่างระมัดระวัง
6. ตรวจ type size, bit-field และ `Value_sType` layout
7. แก้ prototype ให้ตรง definition ทุกจุด
8. ตรวจ `putchar()` signature ให้ตรง TI RTS
9. เปิด compiler warnings แล้วแก้ implicit conversion, array bound และ enum/index warnings
10. ตรวจ macro/enum ที่ source อ้างแต่ไม่สอดคล้อง เช่น calibration index names ก่อนเปิด calibration mode

ตัวอย่างส่วน main:

```c
int main(void)
{
    mcu_clk_init();
    _reset_init();
    __enable_interrupt();

    for (;;) {
        if ((IFG2 & BTIFG) != 0U) {
            IFG2 &= (u8)~BTIFG;
            /* existing 2-ms task */
        }

        if (Flag.UPDATE_TEMPERATURE != 0U) {
            /* existing temperature task */
        }
    }
}
```

---

## 9. แผนทดสอบหลัง Port

### Phase 1: Build/Link

- ไม่มี IAR header เหลือใน include graph
- ไม่มี unresolved symbol
- vector ทุกตัวอยู่ใน map file
- code ไม่ทับ Information Flash
- ตรวจ RAM usage และ stack

### Phase 2: Startup/Clock

- watchdog หยุดตามต้องการ
- วัด MCLK/SMCLK ได้ 8.388608 MHz
- ACLK 32.768 kHz stable
- ไม่ค้างใน oscillator fault loop

### Phase 3: Timing

- Basic Timer flag ทุกประมาณ 1.953/2 ms
- Timer B ISR ทุก 1.953125 ms
- display ไม่มี flicker
- key debounce/hold time เท่า firmware IAR
- startup 4 s + 1 s ตรงเดิม

### Phase 4: ADC

- reference 1.2 V stable
- sample rateประมาณ 64 sample/s
- `Value.Fadc` เทียบ IAR ที่ input resistance เดียวกัน
- PTC2K/PTC10K/NTC2K/NTC10K ทุกช่วง
- open/short sensor และ error clamp

### Phase 5: Output และ alarm

- relay ไม่กระตุกระหว่าง reset
- heating/cooling hysteresis
- on/off delay
- Alarm 1/2 ทุก function ที่ใช้งาน
- output ถูกปิดเมื่อ PV error หรืออยู่ใน protected/config mode

### Phase 6: Flash persistence

- dump Information Flash ก่อน test
- อ่าน parameter เดิมได้ตรง
- save แล้ว reset ค่าไม่เปลี่ยน
- calibration table ไม่เสีย
- power cut ระหว่าง write ต้องถูกประเมิน เพราะ format เดิมไม่มี transaction/CRC

### Phase 7: Regression

สร้างตารางเทียบ IAR กับ CCS:

| Test | IAR | CCS | ผ่าน |
|---|---:|---:|---|
| MCLK | 8.388608 MHz | | |
| Timer B period | 1.953125 ms | | |
| ADC sample rate | ~64/s | | |
| PTC 2K @ จุดสอบเทียบ | | | |
| NTC 10K @ 25 °C | | | |
| startup time | ~5 s | | |
| key hold threshold | | | |
| relay hysteresis | | | |

---

## 10. ประเด็นที่ควรแก้หลังทำงานเทียบเท่าแล้ว

1. แยก persistent configuration ออกจาก runtime state
2. เลิก serialize ด้วย reverse pointer arithmetic และใช้ structure format ที่มี version/CRC
3. เปลี่ยน bit-field flags เป็น explicit masks
4. ย้ายงานคำนวณหนักทั้งหมดออกจาก ADC ISR
5. เปลี่ยน software NOP delays เป็น hardware timer
6. เพิ่ม timeout ใน oscillator startup
7. เปลี่ยน Basic Timer polling เป็น scheduler ที่นับ missed ticks หรือ ISR ตั้ง counter
8. เพิ่ม bounds check ก่อนเรียก `display_page[Status.Main]()` และ `get_input[Value.Input]()`
9. ลด global state และกำหนด ownership ของตัวแปรระหว่าง ISR/foreground
10. เพิ่ม unit test สำหรับ conversion tables, alarm limits และ state machines

---

## 11. สรุปจุดวิกฤตของการ Port

จุดที่มีโอกาสทำให้ CCS build ได้แต่ behavior ไม่ตรง IAR มากที่สุดคือ:

- ใช้ IAR device header ผิดชุด แทน TI `<msp430.h>`
- Basic Timer flag ถูกเข้าใจผิดว่าเป็น interrupt
- optimization ทำให้ตัวแปรแชร์ ISR/foreground ที่ไม่ `volatile` ผิดพฤติกรรม
- structure/bit-field layout เปลี่ยนจนอ่าน Information Flash ผิด
- delay loop เปลี่ยนระยะเวลาเมื่อ compiler/optimization เปลี่ยน
- SD16 ISR ใช้เวลานานจน display interrupt jitter
- linker/download erase Information Flash calibration

แนวทางที่ปลอดภัยคือ port แบบ **behavior-preserving** ก่อน: คง clock, timer, polling, ISR และ flash byte layout เดิม จากนั้นวัดเทียบ firmware IAR ทีละโมดูล แล้วจึง refactor โครงสร้างในรุ่นถัดไป
