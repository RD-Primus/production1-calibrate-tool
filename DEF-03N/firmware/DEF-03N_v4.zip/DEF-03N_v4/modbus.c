#include <msp430.h>
#include "config.h"
#include "global.h"
#include "modbus.h"

Modbus_sType Modbus;   
extern const s16 SettingRangeMax[4][2][2];
extern const s16 SettingRangeMin[4][2][2];

#define MODBUS_CAL_PASSWORD           634U
#define MODBUS_CAL_PTC2K_POINTS       7U
#define MODBUS_CAL_NTC2K_POINTS       11U
#define MODBUS_CAL_NTC10K_POINTS      10U
#define MODBUS_CAL_ALL_TYPES_MASK     0x07U
#define MODBUS_CAL_TIMEOUT_TICKS      ((u16)(TIME1SEC * 60U))

typedef struct{
    u16 TablePTC2K[MODBUS_CAL_PTC2K_POINTS];
    u16 TableNTC2K[MODBUS_CAL_NTC2K_POINTS];
    u16 TableNTC10K[MODBUS_CAL_NTC10K_POINTS];
    volatile u16 TimeoutTicks;
    s16 SavedInput;
    volatile u8 Active;
    u8 ReceivedMask;
} ModbusCalSession_sType;

static ModbusCalSession_sType ModbusCalSession;

const u8 CRCTableHigh[] = {
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,	0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
const u8 CRCTableLow[] = {
	0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 
	0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 
	0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 
	0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10, 
	0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 
	0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 
	0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 
	0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 
	0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 
	0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 
	0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 
	0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 
	0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54,
	0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 
	0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
	0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40
} ;

// คำนวณค่า CRC-16
void crc16(u8 *dptr, u8 n){
u8 i, j;
    Modbus.CrcHi = Modbus.CrcLo = 0xFF;
    for(i=0; i<n; i++, dptr++){
        j = Modbus.CrcHi ^ *dptr;
        Modbus.CrcHi = Modbus.CrcLo ^ CRCTableHigh[j];
        Modbus.CrcLo = CRCTableLow[j];
    }
}

typedef struct{
	u16 RegAddr;
	s16 *DataPtr;
	u8  Writable;
	s16 Min;     // : ค่าต่ำสุดที่ยอมให้เขียน
	s16 Max;     // : ค่าสูงสุดที่ยอมให้เขียน
} ModbusRegMap_sType;


const ModbusRegMap_sType RegMapTable[] = {
    // { RegAddr, DataPtr,       Writable, Min,   Max  }
    {0,  &Value.PV,                 0,   0,     0     }, // read-only, Min/Max ไม่ใช้
    {1,  &Value.SV,                 1,  -199,   999   },
    {2,  &Value.Input,              1,   0,     3     },
    {3,  &Value.PVAdjust,           1,  -999,   999   },
    {4,  &Value.PVFilter,           1,   0,     15    },
    {5,  &Value.DecimalPoint,       1,   0,     1     },
    {6,  &Value.ScaleCF,            1,   0,     1     },
    {7,  &Value.LockKey,            1,   0,     3     },
    {8,  &Value.StartTime,          1,   1,     599   },
    {9,  &Value.FunctionRelay,      1,   10,    21    },
    {10, &Value.ModeControl,        1,   0,     11    },
    {11, &Value.PositionOn1,        1,   0,     999   },
    {12, &Value.PositionOff1,       1,  -199,   999   },
    {13, &Value.OutputDelayOn,      1,   0,     599   },
    {14, &Value.OutputDelayOff,     1,   0,     599   },
    {15, &Value.FunctionAlarm1,     1,   0,     14    },
    {16, &Value.AlarmLimitHigh1,    1,  -999,   9999  },
    {17, &Value.AlarmLimitLow1,     1,  -999,   9999  },
    {18, &Value.HysteresisAlarm1,   1,   0,     999   },
    {19, &Value.FunctionAlarm2,     1,   0,     18    },
    {20, &Value.AlarmLimitHigh2,    1,  -999,   9999  },
    {21, &Value.AlarmLimitLow2,     1,  -999,   9999  },
    {22, &Value.HysteresisAlarm2,   1,   0,     999   },
    {23, &Value.Option,             1,   0,     1     }, // 0 = -A, 1 = -A-B
    {24, &Value.MeterCmd,           1,   METER_CMD_NONE, METER_CMD_EXIT },
    {25, &Value.MeterStatus,        0,   0,     0     },
    {26, (s16*)&Value.Fadc,         0,   0,     0     }, // ADC value (read-only)
    {27, (s16*)&FrontKeyStatus,     0,   0,     0     }, // front key: 0=none, 1=UP, 2=DOWN, 3=SET
};
#define REG_MAP_COUNT (sizeof(RegMapTable)/sizeof(RegMapTable[0]))

/* Modbus exception codes มาตรฐาน */
#define MB_EXC_ILLEGAL_FUNCTION  0x01
#define MB_EXC_ILLEGAL_ADDRESS   0x02
#define MB_EXC_ILLEGAL_VALUE     0x03
#define MB_EXC_DEVICE_BUSY       0x06


const ModbusRegMap_sType* find_register(u16 reg_addr){
	u8 i;
	for(i=0; i<REG_MAP_COUNT; i++){ // 1. ลูปวิ่งดูทีละแถวในตาราง ตั้งแต่แถวแรกยันแถวสุดท้าย
		if(RegMapTable[i].RegAddr == reg_addr){ // 2. "นี่คือจุดที่ใช้เช็คว่าตรงกันมั้ย!"
			return &RegMapTable[i]; // 3. ถ้าตรงกัน ส่งที่อยู่ (Pointer) ของแถวนี้กลับไปทันที
		}
	}
	return 0; // 4. ถ้าลูปจนครบทุกแถวแล้วยังไม่เจอ (ไม่เข้าเงื่อนไข if เลย) ให้ส่ง 0 (NULL) กลับไป   
}

static u8 value_in_range(s16 value, s16 min_value, s16 max_value){
    return (value >= min_value && value <= max_value) ? 1 : 0;
}

static u8 get_current_setting_range(s16 *min_value, s16 *max_value){
    if(Value.Input < PTC_2K || Value.Input > NTC_10K ||
       Value.DecimalPoint < 0 || Value.DecimalPoint > 1 ||
       Value.ScaleCF < 0 || Value.ScaleCF > 1){
        return 0;
    }

    *min_value = SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
    *max_value = SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
    return 1;
}

static u8 alarm1_function_is_valid(s16 value){
    if(value == NOT_USED){
        return 1;
    }
    if(value >= ABSOLUTE_HI_LO_LIMIT && value <= ABSOLUTE_RANGE_HI_LO_LIMIT){
        return 1;
    }
    if(value >= SEQUENCE_ABSOLUTE_HI_LO_LIMIT &&
       value <= SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT){
        return 1;
    }
    return 0;
}

static u8 alarm2_function_is_valid(s16 value){
    if(alarm1_function_is_valid(value)){
        return 1;
    }

    if(Value.FunctionRelay == OUT1_CTRL_OUT2_ALARM){
        if(value >= DEVIATION_HI_LO_LIMIT && value <= DEVIATION_RANGE_HI_LO_LIMIT){
            return 1;
        }
        if(value >= SEQUENCE_DEVIATION_HI_LO_LIMIT &&
           value <= SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT){
            return 1;
        }
    }
    return 0;
}

static u8 relay_function_is_valid(s16 value){
    if(Value.Option == OPTION_AB){
        return (value == OUT1_ALARM_OUT2_NONE ||
                value == OUT1_ALARM_OUT2_ALARM ||
                value == OUT1_CTRL_OUT2_NONE ||
                value == OUT1_CTRL_OUT2_ALARM) ? 1 : 0;
    }

    return (value == OUT1_ALARM_OUT2_NONE ||
            value == OUT1_CTRL_OUT2_NONE) ? 1 : 0;
}

static u8 control_mode_is_valid(s16 value){
    return (value == COOLING_HYSTERESIS ||
            value == COOLING_TIME ||
            value == HEATING_HYSTERESIS ||
            value == HEATING_TIME) ? 1 : 0;
}

static u8 alarm_limit_is_valid(s16 function, s16 value, s16 other_limit,
                               u8 high_side, s16 range_min, s16 range_max){
    if((function >= DEVIATION_HI_LO_LIMIT && function <= DEVIATION_RANGE_HI_LO_LIMIT) ||
       (function >= SEQUENCE_DEVIATION_HI_LO_LIMIT &&
        function <= SEQUENCE_DEVIATION_RANGE_HI_LO_LIMIT)){
        return value_in_range(value, 0, range_max);
    }

    if(function == ABSOLUTE_HI_LO_LIMIT ||
       function == ABSOLUTE_RANGE_HI_LO_LIMIT ||
       function == SEQUENCE_ABSOLUTE_HI_LO_LIMIT ||
       function == SEQUENCE_ABSOLUTE_RANGE_HI_LO_LIMIT){
        if(high_side){
            return value_in_range(value, other_limit, range_max);
        }
        return value_in_range(value, range_min, other_limit);
    }

    if(function == NOT_USED ||
       function == ABSOLUTE_HI_LIMIT || function == ABSOLUTE_LO_LIMIT ||
       function == SEQUENCE_ABSOLUTE_HI_LIMIT ||
       function == SEQUENCE_ABSOLUTE_LO_LIMIT){
        return value_in_range(value, range_min, range_max);
    }

    return 0;
}

/* Validate Modbus writes with the same ranges and discrete choices as the front panel. */
static u8 modbus_register_value_is_valid(u16 reg_addr, s16 value,
                                         const ModbusRegMap_sType *reg){
    s16 range_min;
    s16 range_max;

    switch(reg_addr){
        case 1:
        case 3:
        case 11:
        case 12:
        case 16:
        case 17:
        case 18:
        case 20:
        case 21:
        case 22:
            if(!get_current_setting_range(&range_min, &range_max)){
                return 0;
            }
            break;
        default:
            range_min = reg->Min;
            range_max = reg->Max;
            break;
    }

    switch(reg_addr){
        case 1:
        case 3:
        case 12:
            return value_in_range(value, range_min, range_max);
        case 9:
            return relay_function_is_valid(value);
        case 10:
            return control_mode_is_valid(value);
        case 11:
            return value_in_range(value, 0, range_max);
        case 15:
            return alarm1_function_is_valid(value);
        case 16:
            return alarm_limit_is_valid(Value.FunctionAlarm1, value,
                                        Value.AlarmLimitLow1, 1, range_min, range_max);
        case 17:
            return alarm_limit_is_valid(Value.FunctionAlarm1, value,
                                        Value.AlarmLimitHigh1, 0, range_min, range_max);
        case 18:
            return value_in_range(value, 0, range_max);
        case 19:
            return alarm2_function_is_valid(value);
        case 20:
            return alarm_limit_is_valid(Value.FunctionAlarm2, value,
                                        Value.AlarmLimitLow2, 1, range_min, range_max);
        case 21:
            return alarm_limit_is_valid(Value.FunctionAlarm2, value,
                                        Value.AlarmLimitHigh2, 0, range_min, range_max);
        case 22:
            return value_in_range(value, 0, range_max);
        default:
            return value_in_range(value, reg->Min, reg->Max);
    }
}

void send_exception(u8 func_code, u8 exception_code){
    u8 i;
    Modbus.RspBuf[0] = Modbus.ReqBuf[0];
    Modbus.RspBuf[1] = func_code | 0x80;   // ตั้ง bit สูงสุดของ function code บอกว่าเป็น error
    Modbus.RspBuf[2] = exception_code;
    Modbus.ByteRsp = 3;

    crc16(Modbus.RspBuf, Modbus.ByteRsp);
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.CrcHi;
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.CrcLo;

    for(i=0; i<Modbus.ByteRsp; i++){
        while((IFG2 & UCA0TXIFG)==0);
        UCA0TXBUF = Modbus.RspBuf[i];
    }
    while(UCA0STAT & UCBUSY);
    __delay_cycles(4000);
}

static void send_calibration_response(u8 command, u8 sensor_type, u8 status, u8 received_mask){
    u8 i;

    Modbus.ByteRsp = 0;
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.ReqBuf[0];
    Modbus.RspBuf[Modbus.ByteRsp++] = MODBUS_FUNC_CALIBRATION;
    Modbus.RspBuf[Modbus.ByteRsp++] = command;
    Modbus.RspBuf[Modbus.ByteRsp++] = sensor_type;
    Modbus.RspBuf[Modbus.ByteRsp++] = status;
    Modbus.RspBuf[Modbus.ByteRsp++] = received_mask;

    crc16(Modbus.RspBuf, Modbus.ByteRsp);
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.CrcHi;
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.CrcLo;

    for(i=0; i<Modbus.ByteRsp; i++){
        while((IFG2 & UCA0TXIFG)==0);
        UCA0TXBUF = Modbus.RspBuf[i];
    }
    while(UCA0STAT & UCBUSY);
    __delay_cycles(4000);
}

static u8 calibration_values_increasing(const u16 *table, u8 count){
    u8 i;

    if(count == 0 || table[0] == 0){
        return 0;
    }

    for(i=1; i<count; i++){
        if(table[i] <= table[i-1]){
            return 0;
        }
    }
    return 1;
}

static void calibration_select_input(u8 sensor_type){
    switch(sensor_type){
        case MODBUS_CAL_TYPE_PTC2K:
            Value.Input = PTC_2K;
            break;
        case MODBUS_CAL_TYPE_NTC2K:
            Value.Input = NTC_2K;
            break;
        case MODBUS_CAL_TYPE_NTC10K:
            Value.Input = NTC_10K;
            break;
        default:
            return;
    }
    ADC16A_init();
}

static void calibration_select_first_missing_input(void){
    if((ModbusCalSession.ReceivedMask & 0x01U) == 0){
        calibration_select_input(MODBUS_CAL_TYPE_PTC2K);
    }
    else if((ModbusCalSession.ReceivedMask & 0x02U) == 0){
        calibration_select_input(MODBUS_CAL_TYPE_NTC2K);
    }
    else if((ModbusCalSession.ReceivedMask & 0x04U) == 0){
        calibration_select_input(MODBUS_CAL_TYPE_NTC10K);
    }
}

static void calibration_end_session(u8 restore_input){
    s16 saved_input = ModbusCalSession.SavedInput;

    ModbusCalSession.Active = 0;
    ModbusCalSession.ReceivedMask = 0;
    ModbusCalSession.TimeoutTicks = 0;

    if(restore_input){
        Value.Input = saved_input;
        ADC16A_init();
    }
}

static void calibration_write_type(u8 sensor_type, u8 point_count, const u8 *data){
    u16 *destination;
    u8 expected_count;
    u8 received_bit;
    u8 i;

    destination = 0;
    expected_count = 0;
    received_bit = 0;

    switch(sensor_type){
        case MODBUS_CAL_TYPE_PTC2K:
            destination = ModbusCalSession.TablePTC2K;
            expected_count = MODBUS_CAL_PTC2K_POINTS;
            received_bit = 0x01U;
            break;
        case MODBUS_CAL_TYPE_NTC2K:
            destination = ModbusCalSession.TableNTC2K;
            expected_count = MODBUS_CAL_NTC2K_POINTS;
            received_bit = 0x02U;
            break;
        case MODBUS_CAL_TYPE_NTC10K:
            destination = ModbusCalSession.TableNTC10K;
            expected_count = MODBUS_CAL_NTC10K_POINTS;
            received_bit = 0x04U;
            break;
        default:
            send_calibration_response(MODBUS_CAL_CMD_WRITE_TYPE, sensor_type,
                                      MODBUS_CAL_STATUS_TYPE, ModbusCalSession.ReceivedMask);
            return;
    }

    if(point_count != expected_count){
        send_calibration_response(MODBUS_CAL_CMD_WRITE_TYPE, sensor_type,
                                  MODBUS_CAL_STATUS_LENGTH, ModbusCalSession.ReceivedMask);
        return;
    }

    for(i=0; i<point_count; i++){
        destination[i] = ((u16)data[i*2] << 8) | data[(i*2)+1];
    }

    if(!calibration_values_increasing(destination, point_count)){
        send_calibration_response(MODBUS_CAL_CMD_WRITE_TYPE, sensor_type,
                                  MODBUS_CAL_STATUS_DATA, ModbusCalSession.ReceivedMask);
        return;
    }

    ModbusCalSession.ReceivedMask |= received_bit;
    ModbusCalSession.TimeoutTicks = 0;
    calibration_select_first_missing_input();
    send_calibration_response(MODBUS_CAL_CMD_WRITE_TYPE, sensor_type,
                              MODBUS_CAL_STATUS_OK, ModbusCalSession.ReceivedMask);
}

static void calibration_commit(void){
    u8 i;
    u8 completed_mask;

    if(ModbusCalSession.ReceivedMask != MODBUS_CAL_ALL_TYPES_MASK){
        send_calibration_response(MODBUS_CAL_CMD_COMMIT, 0,
                                  MODBUS_CAL_STATUS_INCOMPLETE, ModbusCalSession.ReceivedMask);
        return;
    }

    __disable_interrupt();
    for(i=0; i<MODBUS_CAL_PTC2K_POINTS; i++){
        Value.TablePTC2K[i] = ModbusCalSession.TablePTC2K[i];
    }
    for(i=0; i<MODBUS_CAL_NTC2K_POINTS; i++){
        Value.TableNTC2K[i] = ModbusCalSession.TableNTC2K[i];
    }
    for(i=0; i<MODBUS_CAL_NTC10K_POINTS; i++){
        Value.TableNTC10K[i] = ModbusCalSession.TableNTC10K[i];
    }
    __enable_interrupt();

    Flag.SAVETOFLASH = 1;
    save_calibrate();

    completed_mask = ModbusCalSession.ReceivedMask;
    calibration_end_session(1);
    send_calibration_response(MODBUS_CAL_CMD_COMMIT, 0,
                              MODBUS_CAL_STATUS_OK, completed_mask);
}

static void handle_calibration_command(u8 request_length){
    u8 command;
    u8 sensor_type;
    u8 point_count;
    u16 password;
    u8 expected_length;

    command = (request_length > 2) ? Modbus.ReqBuf[2] : 0;
    sensor_type = (request_length > 3) ? Modbus.ReqBuf[3] : 0;

    if(request_length < 9){
        send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_LENGTH,
                                  ModbusCalSession.ReceivedMask);
        return;
    }

    password = ((u16)Modbus.ReqBuf[4] << 8) | Modbus.ReqBuf[5];
    point_count = Modbus.ReqBuf[6];

    if(password != MODBUS_CAL_PASSWORD){
        send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_PASSWORD,
                                  ModbusCalSession.ReceivedMask);
        return;
    }

    if(command == MODBUS_CAL_CMD_BEGIN){
        if(request_length != 9 || point_count != 0){
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_LENGTH,
                                      ModbusCalSession.ReceivedMask);
        }
        else if(Status.Main == CALIBRATE_INPUT_MODE || ModbusCalSession.Active){
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_BUSY,
                                      ModbusCalSession.ReceivedMask);
        }
        else{
            ModbusCalSession.SavedInput = Value.Input;
            ModbusCalSession.Active = 1;
            ModbusCalSession.ReceivedMask = 0;
            ModbusCalSession.TimeoutTicks = 0;
            calibration_select_input(MODBUS_CAL_TYPE_PTC2K);
            send_calibration_response(command, MODBUS_CAL_TYPE_PTC2K,
                                      MODBUS_CAL_STATUS_OK, 0);
        }
        return;
    }

    if(command == MODBUS_CAL_CMD_ABORT){
        if(request_length != 9 || point_count != 0){
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_LENGTH,
                                      ModbusCalSession.ReceivedMask);
        }
        else if(!ModbusCalSession.Active){
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_NOT_ACTIVE, 0);
        }
        else{
            calibration_end_session(1);
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_OK, 0);
        }
        return;
    }

    if(!ModbusCalSession.Active){
        send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_NOT_ACTIVE, 0);
        return;
    }

    if(command == MODBUS_CAL_CMD_WRITE_TYPE){
        expected_length = (u8)(9U + ((u16)point_count * 2U));
        if(request_length != expected_length){
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_LENGTH,
                                      ModbusCalSession.ReceivedMask);
            return;
        }
        calibration_write_type(sensor_type, point_count, &Modbus.ReqBuf[7]);
    }
    else if(command == MODBUS_CAL_CMD_COMMIT){
        if(request_length != 9 || point_count != 0){
            send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_LENGTH,
                                      ModbusCalSession.ReceivedMask);
        }
        else{
            calibration_commit();
        }
    }
    else{
        send_calibration_response(command, sensor_type, MODBUS_CAL_STATUS_COMMAND,
                                  ModbusCalSession.ReceivedMask);
    }
}

u16 ModbusSaveTimeout = 0;
void save_parameter(void);


void read_holding_register(void)
{
    u16 reg_addr, n_regs, i;
    u16 current_addr;
    const ModbusRegMap_sType *reg; 

    reg_addr = (Modbus.ReqBuf[2] << 8) | Modbus.ReqBuf[3];
    n_regs   = (Modbus.ReqBuf[4] << 8) | Modbus.ReqBuf[5];

    /* 28 registers need 61 response bytes; RspBuf provides 64 bytes. */
    if (n_regs == 0 || n_regs > 28){
        send_exception(0x03, MB_EXC_ILLEGAL_VALUE);
        return;
    }

    /* A read range is valid only when every requested register exists. */
    for (i = 0; i < n_regs; i++){
        if (find_register(reg_addr + i) == 0){
            send_exception(0x03, MB_EXC_ILLEGAL_ADDRESS);
            return;
        }
    }

    // สร้างหัวเฟรมตอบกลับ
    Modbus.ByteRsp = 0;
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.ReqBuf[0];   
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.ReqBuf[1];   
    Modbus.RspBuf[Modbus.ByteRsp++] = (u8)(n_regs * 2);   

    for (i = 0; i < n_regs; i++)
    {
        current_addr = reg_addr + i;
        u16 reg_value = 0;

        reg = find_register(current_addr);

        if (reg != 0)
        {
            reg_value = (u16)(*(reg->DataPtr));
        }
        Modbus.RspBuf[Modbus.ByteRsp++] = (u8)(reg_value >> 8);
        Modbus.RspBuf[Modbus.ByteRsp++] = (u8)(reg_value);
    }

    // คำนวณค่า CRC ปิดท้ายเฟรม (ใช้แบบที่เราจูนกันผ่านล่าสุด)
    crc16(Modbus.RspBuf, Modbus.ByteRsp);
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.CrcHi;   
    Modbus.RspBuf[Modbus.ByteRsp++] = Modbus.CrcLo;   

    // ยิงสัญญาณออกพอร์ต UART
    for (i = 0; i < Modbus.ByteRsp; i++) {
        while ((IFG2 & UCA0TXIFG) == 0);
        UCA0TXBUF = Modbus.RspBuf[i];
    }
    while (UCA0STAT & UCBUSY);
    __delay_cycles(4000);      
}


void write_single_register(void){
    u16 reg_addr;
    s16 reg_value;
    const ModbusRegMap_sType *reg;
    u16 i;
    s16 old_value;
    u8 need_adc_reinit = 0;           
    u8 need_scale_update = 0;
    u8 option_changed = 0;

    reg_addr = (Modbus.ReqBuf[2]<<8) | Modbus.ReqBuf[3];
    reg_value = (s16)((Modbus.ReqBuf[4]<<8) | Modbus.ReqBuf[5]);

    /* Do not let input or meter commands disturb a bulk-cal session. */
    if(ModbusCalSession.Active && (reg_addr == 2 || reg_addr == 24)){
        send_exception(0x06, MB_EXC_DEVICE_BUSY);
        return;
    }

    reg = find_register(reg_addr);

    if(reg == 0){
        send_exception(0x06, MB_EXC_ILLEGAL_ADDRESS);
        return;
    }
    if(reg->Writable == 0){
        send_exception(0x06, MB_EXC_ILLEGAL_ADDRESS);
        return;
    }

    if(!modbus_register_value_is_valid(reg_addr, reg_value, reg)){
        send_exception(0x06, MB_EXC_ILLEGAL_VALUE);
        return;
    }

    if(reg->DataPtr != 0)
    {
        old_value = *(reg->DataPtr);      

        __disable_interrupt();          // กันไม่ให้ ISR อื่นมาแทรกกลางการเขียนค่า

        *(reg->DataPtr) = reg_value;

        // --- rescale ค่าที่ผูกกับ DecimalPoint ให้เหมือนตอนกดปุ่ม ---
        if(reg_addr == 5 && old_value != reg_value){
            if(old_value == 0 && reg_value == 1){
                Flag.DP = 1;                          // <-- เพิ่มตรงนี้
                Value.SV*=10;
                Value.PVAdjust*=10;
                Value.PositionOn1*=10;
                Value.PositionOff1*=10;
                Value.AlarmLimitHigh1*=10;
                Value.AlarmLimitLow1*=10;
                Value.HysteresisAlarm1*=10;
                Value.AlarmLimitHigh2*=10;
                Value.AlarmLimitLow2*=10;
                Value.HysteresisAlarm2*=10;

                if(Value.SV<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.SV=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.SV>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.SV=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];

                if(Value.PVAdjust<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PVAdjust=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.PVAdjust>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PVAdjust=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];

                if(Value.PositionOn1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOn1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.PositionOn1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOn1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];

                if(Value.PositionOff1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOff1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.PositionOff1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.PositionOff1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];

                if(Value.AlarmLimitHigh1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitHigh1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.AlarmLimitHigh1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitHigh1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];

                if(Value.AlarmLimitLow1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitLow1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.AlarmLimitLow1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.AlarmLimitLow1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];

                if(Value.HysteresisAlarm1<SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.HysteresisAlarm1=SettingRangeMin[Value.Input][Value.DecimalPoint][Value.ScaleCF];
                if(Value.HysteresisAlarm1>SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF]) Value.HysteresisAlarm1=SettingRangeMax[Value.Input][Value.DecimalPoint][Value.ScaleCF];
            }
            else if(old_value == 1 && reg_value == 0){
                Flag.DP = 0;                          // <-- เพิ่มตรงนี้
                Value.SV/=10;
                Value.PVAdjust/=10;
                Value.PositionOn1/=10;
                Value.PositionOff1/=10;
                Value.AlarmLimitHigh1/=10;
                Value.AlarmLimitLow1/=10;
                Value.HysteresisAlarm1/=10;
                Value.AlarmLimitHigh2/=10;
                Value.AlarmLimitLow2/=10;
                Value.HysteresisAlarm2/=10;
            }
        }

        if(reg_addr != 24){
            Flag.MODBUS_SAVE = 1;       // MeterCmd is transient and must not be saved as a parameter.
        }
        __enable_interrupt();

        // เช็คไว้เฉยๆ ก่อน ยังไม่เรียก ADC16A_init() ตรงนี้
        if(reg_addr == 2 && old_value != reg_value){
            need_adc_reinit = 1;
        }

        if(reg_addr == 23 && old_value != reg_value){
            option_changed = 1;
            Value.FunctionRelay = OUT1_CTRL_OUT2_NONE;
        }

    }

    // สั่งยิงข้อมูลตอบกลับ (Echo) ลอกหน้าตาเฟรม Request ส่งกลับไป
    for(i=0; i<8; i++) Modbus.RspBuf[i] = Modbus.ReqBuf[i];
    Modbus.ByteRsp = 8;
    for(i=0; i<8; i++){
        while((IFG2 & UCA0TXIFG)==0);
        UCA0TXBUF = Modbus.RspBuf[i];
    }
    
    while(UCA0STAT & UCBUSY);           // รอจนไบต์สุดท้ายออกจากสายจริง
    __delay_cycles(4000);              // หน่วงเวลาท้ายเฟรมตามมาตรฐาน Modbus   

    // --- ค่อยมาทำ side-effect ที่หน่วงเวลาทีหลัง หลังตอบกลับ Master ไปแล้ว ---
    if(need_adc_reinit){
        ADC16A_init();
    }

    /*
     * Changing Option over Modbus must follow the same final path as the
     * front-panel CONFIG_RELAY_MODE: save the parameter and re-initialize
     * the controller.  Do this only after the complete Modbus echo has left
     * the UART, otherwise the master could receive a truncated response.
     */
    if(option_changed){
        Flag.MODBUS_SAVE = 0;
        ModbusSaveTimeout = 0;
        Flag.SAVETOFLASH = 1;
        save_parameter();
        _reset_init();
    }

}

void modbus_save_handler(void){
    if(Flag.MODBUS_SAVE){
        if(++ModbusSaveTimeout >= TIME2SEC){
            ModbusSaveTimeout = 0;
            Flag.MODBUS_SAVE = 0;
            Flag.SAVETOFLASH = 1;
            save_parameter();
        }
    }
    else{
        ModbusSaveTimeout = 0;
    }
}

void modbus_init(void){
	Modbus.ByteReq = 0;
	Modbus.ByteRsp = 0;
	Modbus.RxTimeOut = 0;

	Modbus.Frx = 0;      
	Modbus.Mb_Func = 0;  
	Modbus.RxLength = 0;
	Modbus.FrameReady = 0;
	ModbusCalSession.Active = 0;
	ModbusCalSession.ReceivedMask = 0;
	ModbusCalSession.TimeoutTicks = 0;
}

void modbus(void){
    u8 request_length;
    u8 received_crc_hi;
    u8 received_crc_lo;

    if (!Modbus.FrameReady) return;

    request_length = Modbus.RxLength;

    /* A valid RTU frame needs address, function and two CRC bytes. */
    if (request_length < 4){
        goto release_frame;
    }

    received_crc_hi = Modbus.ReqBuf[request_length - 2];
    received_crc_lo = Modbus.ReqBuf[request_length - 1];
    crc16(Modbus.ReqBuf, request_length - 2);
    if (Modbus.CrcHi != received_crc_hi || Modbus.CrcLo != received_crc_lo){
        goto release_frame;
    }

    /* Ignore frames addressed to another slave. */
    if (Modbus.ReqBuf[0] == 1)
    {   
        if(ModbusCalSession.Active){
            ModbusCalSession.TimeoutTicks = 0;
        }
        Modbus.Mb_Func = Modbus.ReqBuf[1];
        switch (Modbus.Mb_Func)
        {
            case 0x03: // คำสั่ง Read Holding Registers (อ่านค่าจากบอร์ด)
                if (request_length == 8)
                    read_holding_register();
                break;
                
            case 0x06: // คำสั่ง Write Single Register
                if (request_length == 8)
                    write_single_register(); 
                break;

            case MODBUS_FUNC_CALIBRATION:
                handle_calibration_command(request_length);
                break;
                
            default:
            
                   //ตอนนี้ตอบ ILLEGAL_FUNCTION กลับให้ master รู้ ===== */
                send_exception(Modbus.Mb_Func, MB_EXC_ILLEGAL_FUNCTION);
                break;
        }
    }

release_frame:
    __disable_interrupt();
    Modbus.Mb_Func = 0;
    Modbus.ByteReq = 0;
    Modbus.RxLength = 0;
    Modbus.RxTimeOut = 0;
    Modbus.Frx = 0;
    Modbus.FrameReady = 0;
    __enable_interrupt();
}

void modbus_timeout_check(void)
{
    if (Modbus.FrameReady)
    {
        return;
    }
    if (Modbus.Frx == 1) 
    {
        Modbus.Frx = 0;              
        Modbus.RxTimeOut = 0;        
    }
    else 
    {
        if (Modbus.ByteReq > 0)     
        {
            Modbus.RxTimeOut++;     

            /* Timer B period is about 1.95 ms; one quiet tick meets T3.5 at 19200 8N1. */
            if (Modbus.RxTimeOut >= 1) 
            {
                Modbus.RxLength = Modbus.ByteReq;
                Modbus.FrameReady = 1;
            }
        }
    }
}

void modbus_calibration_tick(void){
    if(ModbusCalSession.Active && ModbusCalSession.TimeoutTicks < MODBUS_CAL_TIMEOUT_TICKS){
        ModbusCalSession.TimeoutTicks++;
    }
}

void modbus_calibration_service(void){
    if(!ModbusCalSession.Active){
        return;
    }

    /* A front-panel calibration has priority over an unfinished PC session. */
    if(Status.Main == CALIBRATE_INPUT_MODE){
        calibration_end_session(0);
        return;
    }

    if(ModbusCalSession.TimeoutTicks >= MODBUS_CAL_TIMEOUT_TICKS){
        calibration_end_session(1);
    }
}
