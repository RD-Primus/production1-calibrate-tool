#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"


const f32 NTC10KT_B57621C103J62[]={	
	0.622,	/*120.0*/
	0.787,	/*110.0*/
	1.016,	/*100.0*/
	1.326,	/*90.0*/
	1.762,	/*80.0*/
	2.354,	/*70.0*/
	3.175,	/*60.0*/
	4.398,	/*50.0*/
	6.240,	/*40.0*/
	8.774,	/*30.0*/
	13.440,	/*20.0*/
	19.470,	/*10.0*/
	30.780,	/*0.0*/
	47.120,	/*-10.0*/
	76.200,	/*-20.0*/
	133.700,/*-30.0*/
	233.700/*-40.0*/
};

f32 PTC_calculate(f32 rptc, f32 r25){
	f32 t;

	rptc=rptc/r25;
	t=(28.54*pow(rptc, 3))-(158.5*pow(rptc, 2))+(474.8*rptc)-319.85;
	return (t);
}

// void get_PTC10K(void){	
// 	f32 rptc, tbl, tbh, r0, t0;
// #if 0
// #if 1
// 	vin=22178;
// 	vin=(vin/65535)*0.0375;
// 	vin=(vin*332000)/2000;
// #else	
// 	vin=43930;
// 	vin=(vin/65535)*0.0375;
// 	vin=(vin*334000)/4000;
// #endif	
		
// 	vout=Value.Fadc;
// 	vout=(vout/65535)*0.0375;
// 	rx=vout/vin;
// 	rptc=(330000*rx)/(1-rx);
// 	Value.R_PT100=rptc;
		
// #else
// 	rptc=Value.Fadc;
	
// 	if(rptc<Value.TablePTC10K[POINT_0]){
// 		tbl=Value.TablePTC10K[POINT_0];
// 		tbh=Value.TablePTC10K[POINT_1];
// 		r0=1000;
// 	}
// 	else if(rptc<Value.TablePTC10K[POINT_1]){
// 		tbl=Value.TablePTC10K[POINT_0];
// 		tbh=Value.TablePTC10K[POINT_1];
// 		r0=1000;
// 	}
// 	else if(rptc<Value.TablePTC10K[POINT_2]){
// 		tbl=Value.TablePTC10K[POINT_1];
// 		tbh=Value.TablePTC10K[POINT_2];
// 		r0=3000;	
// 	}
// 	else if(rptc<Value.TablePTC10K[POINT_3]){
// 		tbl=Value.TablePTC10K[POINT_2];
// 		tbh=Value.TablePTC10K[POINT_3];
// 		r0=5000;
// 	}
// 	else if(rptc<Value.TablePTC10K[POINT_4]){
// 		tbl=Value.TablePTC10K[POINT_3];
// 		tbh=Value.TablePTC10K[POINT_4];
// 		r0=7000;
// 	}
// 	else if(rptc<Value.TablePTC10K[POINT_5]){
// 		tbl=Value.TablePTC10K[POINT_4];
// 		tbh=Value.TablePTC10K[POINT_5];
// 		r0=9000;
// 	}
// 	else if(rptc<Value.TablePTC10K[POINT_6]){
// 		tbl=Value.TablePTC10K[POINT_5];
// 		tbh=Value.TablePTC10K[POINT_6];
// 		r0=11000;
// 	}
// 	else{
// 		tbl=Value.TablePTC10K[POINT_6];
// 		tbh=Value.TablePTC10K[POINT_7];
// 		r0=13000;
// 	}
// 	Error.Byte=0;
	
// 	rptc=(((rptc-tbl)/(tbh-tbl))*2000)+r0;
// 	Value.R_PT100=rptc;
// 	if(rptc<7500){
// 		Error.PVLOWLIMIT=1;		
// 		t0=-40;
// 	}
// 	else if(rptc<100){
// 		Error.PVHIGHLIMIT=1;
// 		t0=130;
// 	}
// 	else{
// 		t0=c_to_f(PTC_calculate(rptc, 10000));
// 	}
// #endif	
// 	Value.AnalogMeasure=t0*10;
// }

void get_PTC10K(void){	
	f32 rntc, tbl, tbh, r0, gap, t0;


	rntc=Value.Fadc;

#if 0

#else	
	if(rntc<Value.TableNTC10K[POINT_0]){
		tbl=Value.TableNTC10K[POINT_0];
		tbh=Value.TableNTC10K[POINT_1];
		r0=1000;
		gap=4000;
	}
	else if(rntc<Value.TableNTC10K[POINT_1]){
		tbl=Value.TableNTC10K[POINT_0];
		tbh=Value.TableNTC10K[POINT_1];
		r0=1000;
		gap=4000;
	}
	else if(rntc<Value.TableNTC10K[POINT_2]){
		tbl=Value.TableNTC10K[POINT_1];
		tbh=Value.TableNTC10K[POINT_2];
		r0=5000;
		gap=5000;
	}
	else if(rntc<Value.TableNTC10K[POINT_3]){
		tbl=Value.TableNTC10K[POINT_2];
		tbh=Value.TableNTC10K[POINT_3];
		r0=10000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_4]){
		tbl=Value.TableNTC10K[POINT_3];
		tbh=Value.TableNTC10K[POINT_4];
		r0=40000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_5]){
		tbl=Value.TableNTC10K[POINT_4];
		tbh=Value.TableNTC10K[POINT_5];
		r0=70000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_6]){
		tbl=Value.TableNTC10K[POINT_5];
		tbh=Value.TableNTC10K[POINT_6];
		r0=100000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_7]){
		tbl=Value.TableNTC10K[POINT_6];
		tbh=Value.TableNTC10K[POINT_7];
		r0=130000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_8]){
		tbl=Value.TableNTC10K[POINT_7];
		tbh=Value.TableNTC10K[POINT_8];
		r0=160000;
		gap=30000;
	}
	else{
		tbl=Value.TableNTC10K[POINT_8];
		tbh=Value.TableNTC10K[POINT_9];
		r0=190000;
		gap=30000;
	}
	
	Error.Byte=0;
	rntc=(((rntc-tbl)/(tbh-tbl))*gap)+r0;
	if(rntc>270000){
		Error.PVLOWLIMIT=1;
		t0=-40;
	}
	else if(rntc<460){
		Error.PVHIGHLIMIT=1;
		t0=130;
	}
	else{
		t0=c_to_f(NTC_calculate(rntc, 10000, 3950));
	}
	Value.AnalogMeasure=t0*10;
#endif
#if 1
	Value.R_PT100=rntc;

	rntc/=1000;
	Error.Byte=0;
	if(rntc<NTC10KT_B57621C103J62[POINT_0]){
		tbl=NTC10KT_B57621C103J62[POINT_0];
		tbh=NTC10KT_B57621C103J62[POINT_1];
		t0=120;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_1]){
		tbl=NTC10KT_B57621C103J62[POINT_0];
		tbh=NTC10KT_B57621C103J62[POINT_1];
		t0=120;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_2]){
		tbl=NTC10KT_B57621C103J62[POINT_1];
		tbh=NTC10KT_B57621C103J62[POINT_2];
		t0=110;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_3]){
		tbl=NTC10KT_B57621C103J62[POINT_2];
		tbh=NTC10KT_B57621C103J62[POINT_3];
		t0=100;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_4]){
		tbl=NTC10KT_B57621C103J62[POINT_3];
		tbh=NTC10KT_B57621C103J62[POINT_4];
		t0=90;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_5]){
		tbl=NTC10KT_B57621C103J62[POINT_4];
		tbh=NTC10KT_B57621C103J62[POINT_5];
		t0=80;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_6]){
		tbl=NTC10KT_B57621C103J62[POINT_5];
		tbh=NTC10KT_B57621C103J62[POINT_6];
		t0=70;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_7]){
		tbl=NTC10KT_B57621C103J62[POINT_6];
		tbh=NTC10KT_B57621C103J62[POINT_7];
		t0=60;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_8]){
		tbl=NTC10KT_B57621C103J62[POINT_7];
		tbh=NTC10KT_B57621C103J62[POINT_8];
		t0=50;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_9]){
		tbl=NTC10KT_B57621C103J62[POINT_8];
		tbh=NTC10KT_B57621C103J62[POINT_9];
		t0=40;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_10]){
		tbl=NTC10KT_B57621C103J62[POINT_9];
		tbh=NTC10KT_B57621C103J62[POINT_10];
		t0=30;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_11]){
		tbl=NTC10KT_B57621C103J62[POINT_10];
		tbh=NTC10KT_B57621C103J62[POINT_11];
		t0=20;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_12]){
		tbl=NTC10KT_B57621C103J62[POINT_11];
		tbh=NTC10KT_B57621C103J62[POINT_12];
		t0=10;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_13]){
		tbl=NTC10KT_B57621C103J62[POINT_12];
		tbh=NTC10KT_B57621C103J62[POINT_13];
		t0=0;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_14]){
		tbl=NTC10KT_B57621C103J62[POINT_13];
		tbh=NTC10KT_B57621C103J62[POINT_14];
		t0=-10;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_15]){
		tbl=NTC10KT_B57621C103J62[POINT_14];
		tbh=NTC10KT_B57621C103J62[POINT_15];
		t0=-20;
	}
	else if(rntc<NTC10KT_B57621C103J62[POINT_16]){
		tbl=NTC10KT_B57621C103J62[POINT_15];
		tbh=NTC10KT_B57621C103J62[POINT_16];
		t0=-30;
	}
	else {
		tbl=NTC10KT_B57621C103J62[POINT_15];
		tbh=NTC10KT_B57621C103J62[POINT_16];
		t0=-40;
	}
	t0-=((rntc-tbl)*10/(tbh-tbl));
	t0=c_to_f(t0);
		if(Value.ScaleCF==1)
		{
		if(t0>=267)   {	Error.PVHIGHLIMIT=1;	t0=267;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	}
		}
		else
		{
		if(t0>=131)   {	Error.PVHIGHLIMIT=1;	t0=130;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	} 
		}
		if(Flag.DP)
			{
			if(t0>=100)   {	Error.PVHIGHLIMIT=1;	t0=99.8;	}   
        	if(t0<-19.98)   {	Error.PVLOWLIMIT=1;		t0=-19.98;	}
			}

	Value.AnalogMeasure=t0*10;
#endif	
}