#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"
#include "ntc2k_table.h"

f32 NTC_calculate(f32 rntc, f32 r25, f32 B25_100){
	f32 t, t25;

	t25=298.15;
	t=((log(rntc/r25))/B25_100)+(1/t25);
	t=1/t;
	return (t-273);
}

void get_NTC2K(void){
	f32 rntc, tbl, tbh, r0, gap, t0;


	rntc=Value.Fadc;

#if 0
	if(!Flag.SWITCH_ADCGAIN){	
		if(rntc<Value.TableNTC2K[POINT_0]){
			tbl=Value.TableNTC2K[POINT_0];
			tbh=Value.TableNTC2K[POINT_1];
			r0=1000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC2K[POINT_1]){
			tbl=Value.TableNTC2K[POINT_0];
			tbh=Value.TableNTC2K[POINT_1];
			r0=1000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC2K[POINT_2]){
			tbl=Value.TableNTC2K[POINT_1];
			tbh=Value.TableNTC2K[POINT_2];
			r0=2000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC2K[POINT_3]){
			tbl=Value.TableNTC2K[POINT_2];
			tbh=Value.TableNTC2K[POINT_3];
			r0=3000;
			gap=1000;
		}
		else{
			tbl=Value.TableNTC2K[POINT_3];
			tbh=Value.TableNTC2K[POINT_4];
			r0=4000;
			gap=1000;
		}
	}
	else{
		if(rntc<Value.TableNTC2K[POINT_5]){
			tbl=Value.TableNTC2K[POINT_5];
			tbh=Value.TableNTC2K[POINT_6];
			r0=5000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC2K[POINT_6]){
			tbl=Value.TableNTC2K[POINT_5];
			tbh=Value.TableNTC2K[POINT_6];
			r0=5000;
			gap=5000;
		}
		else if(rntc<Value.TableNTC2K[POINT_7]){
			tbl=Value.TableNTC2K[POINT_6];
			tbh=Value.TableNTC2K[POINT_7];
			r0=10000;
			gap=10000;
		}
		else if(rntc<Value.TableNTC2K[POINT_8]){
			tbl=Value.TableNTC2K[POINT_7];
			tbh=Value.TableNTC2K[POINT_8];
			r0=20000;
			gap=10000;
		}
		else if(rntc<Value.TableNTC2K[POINT_9]){
			tbl=Value.TableNTC2K[POINT_8];
			tbh=Value.TableNTC2K[POINT_9];
			r0=30000;
			gap=10000;
		}
		else{
			tbl=Value.TableNTC2K[POINT_9];
			tbh=Value.TableNTC2K[POINT_10];
			r0=40000;
			gap=10000;
		}
	}
	rntc=(((rntc-tbl)/(tbh-tbl))*gap)+r0;
	if(!Flag.SWITCH_ADCGAIN){
		if(rntc>4500){
			Flag.SWITCH_ADCGAIN=1;
			SD16INCTL0=SD16INCH_0+SD16GAIN_1+SD16INTDLY_0; 
		}
	}
	else{
		if(rntc<4200){
			Flag.SWITCH_ADCGAIN=0;
			SD16INCTL0=SD16INCH_0+SD16GAIN_8+SD16INTDLY_0; 
		}
	}
#else	
#if 0
	if(rntc<Value.TableNTC2K[POINT_0]){
		tbl=Value.TableNTC2K[POINT_0];
		tbh=Value.TableNTC2K[POINT_1];
		r0=1000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_1]){
		tbl=Value.TableNTC2K[POINT_0];
		tbh=Value.TableNTC2K[POINT_1];
		r0=1000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_2]){
		tbl=Value.TableNTC2K[POINT_1];
		tbh=Value.TableNTC2K[POINT_2];
		r0=2000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_3]){
		tbl=Value.TableNTC2K[POINT_2];
		tbh=Value.TableNTC2K[POINT_3];
		r0=3000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_4]){
		tbl=Value.TableNTC2K[POINT_3];
		tbh=Value.TableNTC2K[POINT_4];
		r0=4000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_5]){
		tbl=Value.TableNTC2K[POINT_4];
		tbh=Value.TableNTC2K[POINT_5];
		r0=5000;
		gap=5000;
	}
	else if(rntc<Value.TableNTC2K[POINT_6]){
		tbl=Value.TableNTC2K[POINT_5];
		tbh=Value.TableNTC2K[POINT_6];
		r0=10000;
		gap=10000;
	}
	else if(rntc<Value.TableNTC2K[POINT_7]){
		tbl=Value.TableNTC2K[POINT_6];
		tbh=Value.TableNTC2K[POINT_7];
		r0=20000;
		gap=10000;
	}
	else if(rntc<Value.TableNTC2K[POINT_8]){
		tbl=Value.TableNTC2K[POINT_7];
		tbh=Value.TableNTC2K[POINT_8];
		r0=30000;
		gap=10000;
	}
	else{
		tbl=Value.TableNTC2K[POINT_8];
		tbh=Value.TableNTC2K[POINT_9];
		r0=40000;
		gap=10000;
	}
	rntc=(((rntc-tbl)/(tbh-tbl))*gap)+r0;
	t0=c_to_f(NTC_calculate(rntc, 2000, 3442));
	Error.Byte=0;
	Value.AnalogMeasure=t0*10;
#else	
	if(rntc<Value.TableNTC2K[POINT_0]){
		tbl=Value.TableNTC2K[POINT_0];
		tbh=Value.TableNTC2K[POINT_1];
		r0=100;
		gap=900;
	}
	else if(rntc<Value.TableNTC2K[POINT_1]){
		tbl=Value.TableNTC2K[POINT_0];
		tbh=Value.TableNTC2K[POINT_1];
		r0=100;
		gap=900;
	}
	else if(rntc<Value.TableNTC2K[POINT_2]){
		tbl=Value.TableNTC2K[POINT_1];
		tbh=Value.TableNTC2K[POINT_2];
		r0=1000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_3]){
		tbl=Value.TableNTC2K[POINT_2];
		tbh=Value.TableNTC2K[POINT_3];
		r0=2000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_4]){
		tbl=Value.TableNTC2K[POINT_3];
		tbh=Value.TableNTC2K[POINT_4];
		r0=3000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_5]){
		tbl=Value.TableNTC2K[POINT_4];
		tbh=Value.TableNTC2K[POINT_5];
		r0=4000;
		gap=1000;
	}
	else if(rntc<Value.TableNTC2K[POINT_6]){
		tbl=Value.TableNTC2K[POINT_5];
		tbh=Value.TableNTC2K[POINT_6];
		r0=5000;
		gap=5000;
	}
	else if(rntc<Value.TableNTC2K[POINT_7]){
		tbl=Value.TableNTC2K[POINT_6];
		tbh=Value.TableNTC2K[POINT_7];
		r0=10000;
		gap=10000;
	}
	else if(rntc<Value.TableNTC2K[POINT_8]){
		tbl=Value.TableNTC2K[POINT_7];
		tbh=Value.TableNTC2K[POINT_8];
		r0=20000;
		gap=10000;
	}
	else if(rntc<Value.TableNTC2K[POINT_9]){
		tbl=Value.TableNTC2K[POINT_8];
		tbh=Value.TableNTC2K[POINT_9];
		r0=30000;
		gap=10000;
	}
	else{
		tbl=Value.TableNTC2K[POINT_9];
		tbh=Value.TableNTC2K[POINT_10];
		r0=40000;
		gap=10000;
	}
	
	Error.Byte=0;
	rntc=(((rntc-tbl)/(tbh-tbl))*gap)+r0;
	// if(rntc>51000){
	// 	Error.PVLOWLIMIT=1;
	// 	t0=-40;
	// }
	// else if(rntc<95){
	// 	Error.PVHIGHLIMIT=1;
	// 	t0=130;
	// }
	// else{
	// 	t0=c_to_f(NTC_calculate(rntc, 2000, 3442));
	// }
	// Value.AnalogMeasure=t0*10;
#endif
#endif
#if 1
	Value.R_PT100=rntc;


	Error.Byte=0;
	if(rntc<NTC2KTable[POINT_0]){
		tbl=NTC2KTable[POINT_0];
		tbh=NTC2KTable[POINT_1];
		t0=130;
	}
	else if(rntc<NTC2KTable[POINT_1]){
		tbl=NTC2KTable[POINT_0];
		tbh=NTC2KTable[POINT_1];
		t0=130;
	}
	else if(rntc<NTC2KTable[POINT_2]){
		tbl=NTC2KTable[POINT_1];
		tbh=NTC2KTable[POINT_2];
		t0=120;
	}
	else if(rntc<NTC2KTable[POINT_3]){
		tbl=NTC2KTable[POINT_2];
		tbh=NTC2KTable[POINT_3];
		t0=110;
	}
	else if(rntc<NTC2KTable[POINT_4]){
		tbl=NTC2KTable[POINT_3];
		tbh=NTC2KTable[POINT_4];
		t0=100;
	}
	else if(rntc<NTC2KTable[POINT_5]){
		tbl=NTC2KTable[POINT_4];
		tbh=NTC2KTable[POINT_5];
		t0=90;
	}
	else if(rntc<NTC2KTable[POINT_6]){
		tbl=NTC2KTable[POINT_5];
		tbh=NTC2KTable[POINT_6];
		t0=80;
	}
	else if(rntc<NTC2KTable[POINT_7]){
		tbl=NTC2KTable[POINT_6];
		tbh=NTC2KTable[POINT_7];
		t0=70;
	}
	else if(rntc<NTC2KTable[POINT_8]){
		tbl=NTC2KTable[POINT_7];
		tbh=NTC2KTable[POINT_8];
		t0=60;
	}
	else if(rntc<NTC2KTable[POINT_9]){
		tbl=NTC2KTable[POINT_8];
		tbh=NTC2KTable[POINT_9];
		t0=50;
	}
	else if(rntc<NTC2KTable[POINT_10]){
		tbl=NTC2KTable[POINT_9];
		tbh=NTC2KTable[POINT_10];
		t0=40;
	}
	else if(rntc<NTC2KTable[POINT_11]){
		tbl=NTC2KTable[POINT_10];
		tbh=NTC2KTable[POINT_11];
		t0=30;
	}
	else if(rntc<NTC2KTable[POINT_12]){
		tbl=NTC2KTable[POINT_11];
		tbh=NTC2KTable[POINT_12];
		t0=20;
	}
	else if(rntc<NTC2KTable[POINT_13]){
		tbl=NTC2KTable[POINT_12];
		tbh=NTC2KTable[POINT_13];
		t0=10;
	}
	else if(rntc<NTC2KTable[POINT_14]){
		tbl=NTC2KTable[POINT_13];
		tbh=NTC2KTable[POINT_14];
		t0=0;
	}
	else if(rntc<NTC2KTable[POINT_15]){
		tbl=NTC2KTable[POINT_14];
		tbh=NTC2KTable[POINT_15];
		t0=-10;
	}
	else if(rntc<NTC2KTable[POINT_16]){
		tbl=NTC2KTable[POINT_15];
		tbh=NTC2KTable[POINT_16];
		t0=-20;
	}
	else{
		tbl=NTC2KTable[POINT_16];
		tbh=NTC2KTable[POINT_17];
		t0=-30;
	}
	t0-=((rntc-tbl)*10/(tbh-tbl));
	t0=c_to_f(t0);
        if(Value.ScaleCF==1)
		{
		if(t0>=267)   {	Error.PVHIGHLIMIT=1;	t0=267;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	}
		}
		else
		{
		if(t0>=131)   {	Error.PVHIGHLIMIT=1;	t0=130;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	} 
		}
		if(Flag.DP)
			{
			if(t0>=100)   {	Error.PVHIGHLIMIT=1;	t0=99.8;	}   
        	if(t0<-19.98)   {	Error.PVLOWLIMIT=1;		t0=-19.98;	}
			}
	Value.AnalogMeasure=t0*10;
#endif
}

