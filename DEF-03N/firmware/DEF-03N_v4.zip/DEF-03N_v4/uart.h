#ifndef UART_H_
#define UART_H_

void uart_init(void);
void uart_putc(char c);
void uart_write(const char *text);
unsigned char uart_rx_ready(void);
char uart_getc(void);

#endif

