#include 	"Config.h"
#include 	"Typedef.h"


void operation_mode(void);




s16 round_up(s32 temp);

void key_event(void);


void output1_event(void);
void alarm1(void);

//void (*get_input[])(void);
//void (*display_page[])(void);

u8 Output1Status=0; 
u8 Output2Status=0; 

u8 DigitData[5];
u8 Digit=0; 
u8 PWColumn;

volatile s16 FrontKeyStatus=0;
u16 FrontKeyStatusTimeout=0;

s16 Maximum;
s16 Minimum;
s16 *Xdptr;
s16 DataLast;

u8 ADCMUX; 
u8 ADCMuxSample0;

s16	DATATMP175Last;

f32 mV;
f32 mVCJ;
f32 tmp175temp;

Value_sType Value;
Key_sType Key;
Status_sType Status;
Counter_sType BaseTimeCount;
//PID_sType PID1;
//PID_sType PID2;
volatile Flag_uType Flag;
ERROR_uType Error;
//AL_uType AL1Hold;
//AL_uType AL2Hold;
Led_uType Led;

