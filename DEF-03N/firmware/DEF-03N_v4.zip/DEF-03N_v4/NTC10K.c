#include <msp430.h>
#include "math.h"
#include "stdio.h"
#include "config.h"
#include "global.h"
#include "ntc10k_table.h"



void get_NTC10K(void){	
	f32 rntc, tbl, tbh, r0, gap, t0;


	rntc=Value.Fadc;

#if 0
	if(!Flag.SWITCH_ADCGAIN){	
		if(rntc<Value.TableNTC10K[POINT_0]){
			tbl=Value.TableNTC10K[POINT_0];
			tbh=Value.TableNTC10K[POINT_1];
			r0=1000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC10K[POINT_1]){
			tbl=Value.TableNTC10K[POINT_0];
			tbh=Value.TableNTC10K[POINT_1];
			r0=1000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC10K[POINT_2]){
			tbl=Value.TableNTC10K[POINT_1];
			tbh=Value.TableNTC10K[POINT_2];
			r0=2000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC10K[POINT_3]){
			tbl=Value.TableNTC10K[POINT_2];
			tbh=Value.TableNTC10K[POINT_3];
			r0=3000;
			gap=1000;
		}
		else{
			tbl=Value.TableNTC10K[POINT_3];
			tbh=Value.TableNTC10K[POINT_4];
			r0=4000;
			gap=1000;
		}
	}
	else{
		if(rntc<Value.TableNTC10K[POINT_5]){
			tbl=Value.TableNTC10K[POINT_5];
			tbh=Value.TableNTC10K[POINT_6];
			r0=5000;
			gap=1000;
		}
		else if(rntc<Value.TableNTC10K[POINT_6]){
			tbl=Value.TableNTC10K[POINT_5];
			tbh=Value.TableNTC10K[POINT_6];
			r0=5000;
			gap=5000;
		}
		else if(rntc<Value.TableNTC10K[POINT_7]){
			tbl=Value.TableNTC10K[POINT_6];
			tbh=Value.TableNTC10K[POINT_7];
			r0=10000;
			gap=10000;
		}
		else if(rntc<Value.TableNTC10K[POINT_8]){
			tbl=Value.TableNTC10K[POINT_7];
			tbh=Value.TableNTC10K[POINT_8];
			r0=20000;
			gap=10000;
		}
		else if(rntc<Value.TableNTC10K[POINT_9]){
			tbl=Value.TableNTC10K[POINT_8];
			tbh=Value.TableNTC10K[POINT_9];
			r0=30000;
			gap=10000;
		}
		else{
			tbl=Value.TableNTC10K[POINT_9];
			tbh=Value.TableNTC10K[POINT_10];
			r0=40000;
			gap=10000;
		}
	}
	rntc=(((rntc-tbl)/(tbh-tbl))*gap)+r0;
	if(!Flag.SWITCH_ADCGAIN){
		if(rntc>4500){
			Flag.SWITCH_ADCGAIN=1;
			SD16INCTL0=SD16INCH_0+SD16GAIN_1+SD16INTDLY_0; 
		}
	}
	else{
		if(rntc<4200){
			Flag.SWITCH_ADCGAIN=0;
			SD16INCTL0=SD16INCH_0+SD16GAIN_8+SD16INTDLY_0; 
		}
	}
#else	
	if(rntc<Value.TableNTC10K[POINT_0]){
		tbl=Value.TableNTC10K[POINT_0];
		tbh=Value.TableNTC10K[POINT_1];
		r0=1000;
		gap=4000;
	}
	else if(rntc<Value.TableNTC10K[POINT_1]){
		tbl=Value.TableNTC10K[POINT_0];
		tbh=Value.TableNTC10K[POINT_1];
		r0=1000;
		gap=4000;
	}
	else if(rntc<Value.TableNTC10K[POINT_2]){
		tbl=Value.TableNTC10K[POINT_1];
		tbh=Value.TableNTC10K[POINT_2];
		r0=5000;
		gap=5000;
	}
	else if(rntc<Value.TableNTC10K[POINT_3]){
		tbl=Value.TableNTC10K[POINT_2];
		tbh=Value.TableNTC10K[POINT_3];
		r0=10000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_4]){
		tbl=Value.TableNTC10K[POINT_3];
		tbh=Value.TableNTC10K[POINT_4];
		r0=40000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_5]){
		tbl=Value.TableNTC10K[POINT_4];
		tbh=Value.TableNTC10K[POINT_5];
		r0=70000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_6]){
		tbl=Value.TableNTC10K[POINT_5];
		tbh=Value.TableNTC10K[POINT_6];
		r0=100000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_7]){
		tbl=Value.TableNTC10K[POINT_6];
		tbh=Value.TableNTC10K[POINT_7];
		r0=130000;
		gap=30000;
	}
	else if(rntc<Value.TableNTC10K[POINT_8]){
		tbl=Value.TableNTC10K[POINT_7];
		tbh=Value.TableNTC10K[POINT_8];
		r0=160000;
		gap=30000;
	}
	else{
		tbl=Value.TableNTC10K[POINT_8];
		tbh=Value.TableNTC10K[POINT_9];
		r0=190000;
		gap=30000;
	}
	
	Error.Byte=0;
	rntc=(((rntc-tbl)/(tbh-tbl))*gap)+r0;
	// if(rntc>270000){
	// 	Error.PVLOWLIMIT=1;
	// 	t0=-40;
	// }
	// else if(rntc<460){
	// 	Error.PVHIGHLIMIT=1;
	// 	t0=130;
	// }
	// else{
	// 	// t0=c_to_f(NTC_calculate(rntc, 10000, 3497));
	// 	t0=c_to_f(NTC_calculate(rntc, 10000, 3950));
	// }
	// Value.AnalogMeasure=t0*10;
#endif
#if 1
	Value.R_PT100=rntc;

	rntc/=1000;
	Error.Byte=0;
	if(rntc<NTC10KTable[POINT_0]){
		tbl=NTC10KTable[POINT_0];
		tbh=NTC10KTable[POINT_1];
		t0=120;
	}
	else if(rntc<NTC10KTable[POINT_1]){
		tbl=NTC10KTable[POINT_0];
		tbh=NTC10KTable[POINT_1];
		t0=120;
	}
	else if(rntc<NTC10KTable[POINT_2]){
		tbl=NTC10KTable[POINT_1];
		tbh=NTC10KTable[POINT_2];
		t0=110;
	}
	else if(rntc<NTC10KTable[POINT_3]){
		tbl=NTC10KTable[POINT_2];
		tbh=NTC10KTable[POINT_3];
		t0=100;
	}
	else if(rntc<NTC10KTable[POINT_4]){
		tbl=NTC10KTable[POINT_3];
		tbh=NTC10KTable[POINT_4];
		t0=90;
	}
	else if(rntc<NTC10KTable[POINT_5]){
		tbl=NTC10KTable[POINT_4];
		tbh=NTC10KTable[POINT_5];
		t0=80;
	}
	else if(rntc<NTC10KTable[POINT_6]){
		tbl=NTC10KTable[POINT_5];
		tbh=NTC10KTable[POINT_6];
		t0=70;
	}
	else if(rntc<NTC10KTable[POINT_7]){
		tbl=NTC10KTable[POINT_6];
		tbh=NTC10KTable[POINT_7];
		t0=60;
	}
	else if(rntc<NTC10KTable[POINT_8]){
		tbl=NTC10KTable[POINT_7];
		tbh=NTC10KTable[POINT_8];
		t0=50;
	}
	else if(rntc<NTC10KTable[POINT_9]){
		tbl=NTC10KTable[POINT_8];
		tbh=NTC10KTable[POINT_9];
		t0=40;
	}
	else if(rntc<NTC10KTable[POINT_10]){
		tbl=NTC10KTable[POINT_9];
		tbh=NTC10KTable[POINT_10];
		t0=30;
	}
	else if(rntc<NTC10KTable[POINT_11]){
		tbl=NTC10KTable[POINT_10];
		tbh=NTC10KTable[POINT_11];
		t0=20;
	}
	else if(rntc<NTC10KTable[POINT_12]){
		tbl=NTC10KTable[POINT_11];
		tbh=NTC10KTable[POINT_12];
		t0=10;
	}
	else if(rntc<NTC10KTable[POINT_13]){
		tbl=NTC10KTable[POINT_12];
		tbh=NTC10KTable[POINT_13];
		t0=0;
	}
	else if(rntc<NTC10KTable[POINT_14]){
		tbl=NTC10KTable[POINT_13];
		tbh=NTC10KTable[POINT_14];
		t0=-10;
	}
	else if(rntc<NTC10KTable[POINT_15]){
		tbl=NTC10KTable[POINT_14];
		tbh=NTC10KTable[POINT_15];
		t0=-20;
	}
	else if(rntc<NTC10KTable[POINT_16]){
		tbl=NTC10KTable[POINT_15];
		tbh=NTC10KTable[POINT_16];
		t0=-30;
	}
	else {
		tbl=NTC10KTable[POINT_15];
		tbh=NTC10KTable[POINT_16];
		t0=-40;
	}
	t0-=((rntc-tbl)*10/(tbh-tbl));
	t0=c_to_f(t0);
    if(Value.ScaleCF==1)
		{
		if(t0>=267)   {	Error.PVHIGHLIMIT=1;	t0=267;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	}
		}
		else
		{
		if(t0>=131)   {	Error.PVHIGHLIMIT=1;	t0=130;	}   
        if(t0<=-41)   {	Error.PVLOWLIMIT=1;		t0=-40;	} 
		}
	if(Flag.DP)
		{
		if(t0>=100)   {	Error.PVHIGHLIMIT=1;	t0=99.8;	}   
                if(t0<-19.98)   {	Error.PVLOWLIMIT=1;		t0=-19.98;	}
		}
        
	Value.AnalogMeasure=t0*10;
#endif	
}

