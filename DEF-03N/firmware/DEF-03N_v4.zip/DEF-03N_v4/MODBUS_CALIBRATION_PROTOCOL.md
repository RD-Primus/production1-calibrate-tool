# DEF Modbus Calibration Protocol

This protocol uploads calibration ADC tables by sensor type. Values remain in a
temporary RAM session until all three tables have been received and `COMMIT`
saves them with the same `save_calibrate()` path used by front-panel calibration.

## Byte order and CRC

- All 16-bit values are sent high byte first.
- The calibration password is decimal `634` (`0x027A`).
- CRC uses the project's existing `crc16()` implementation and is appended as
  `CRC Hi`, then `CRC Lo`.
- The current firmware slave address is `0x01`.

## Request frame

| Offset | Field | Description |
|---:|---|---|
| 0 | Slave | `0x01` |
| 1 | Function | `0x55` |
| 2 | Command | See command table |
| 3 | Sensor type | Used by `WRITE_TYPE`; send `0` for other commands |
| 4 | Password Hi | `0x02` |
| 5 | Password Lo | `0x7A` |
| 6 | Point count | `0` except for `WRITE_TYPE` |
| 7... | ADC data | Each point is `ADC Hi`, `ADC Lo` |
| Last 2 | CRC | `CRC Hi`, `CRC Lo` |

## Commands

| Command | Name | Request length | Action |
|---:|---|---:|---|
| `0x01` | `BEGIN` | 9 bytes | Starts a clean RAM session and selects the PTC2K ADC input |
| `0x02` | `WRITE_TYPE` | `9 + 2 * PointCount` | Validates and stages one sensor table |
| `0x03` | `COMMIT` | 9 bytes | Requires all tables, copies them to live tables, and saves Flash |
| `0x04` | `ABORT` | 9 bytes | Discards the RAM session and restores the previous input |

## Sensor types

| Type | Table | Points | Request length | Received-mask bit |
|---:|---|---:|---:|---:|
| `0x00` | PTC2K | 7 | 23 bytes | `0x01` |
| `0x01` | NTC2K | 11 | 31 bytes | `0x02` |
| `0x02` | NTC10K | 10 | 29 bytes | `0x04` |

PTC10K is intentionally not supported by this protocol.

ADC points must be non-zero and strictly increasing in the resistance-point
order used by the existing calibration tables.

## Response frame

Every CRC-valid calibration request receives this 8-byte response:

| Offset | Field | Description |
|---:|---|---|
| 0 | Slave | `0x01` |
| 1 | Function | `0x55` |
| 2 | Command | Echo of request command |
| 3 | Sensor type | Echo/current type |
| 4 | Status | See status table |
| 5 | Received mask | Bitmask of staged sensor tables |
| 6 | CRC Hi | Response CRC high byte |
| 7 | CRC Lo | Response CRC low byte |

## Status values

| Status | Meaning |
|---:|---|
| `0x00` | Success |
| `0x01` | Password is not 634 |
| `0x02` | No active calibration session |
| `0x03` | Busy (front-panel calibration or another PC session is active) |
| `0x04` | Unsupported sensor type |
| `0x05` | Wrong frame length or point count |
| `0x06` | ADC table is zero/non-increasing |
| `0x07` | Cannot commit because not all three types were received |
| `0x08` | Unsupported calibration command |

The received mask is complete at `0x07`.

## Normal sequence

1. Send `BEGIN`.
2. Read holding register 26 (`Fadc`) while collecting the seven PTC2K points.
3. Send `WRITE_TYPE` for PTC2K. The firmware then selects NTC2K.
4. Collect and send the eleven NTC2K points. The firmware then selects NTC10K.
5. Collect and send the ten NTC10K points.
6. Send `COMMIT` and require status `0x00` with received mask `0x07`.

A successful `WRITE_TYPE` may be repeated to replace that staged table before
`COMMIT`. The session is automatically aborted after about 60 seconds without a
valid Modbus request addressed to this device. Timeout or `ABORT` leaves the
previous Flash calibration unchanged.

Front-panel calibration is unchanged. If it starts during a PC session, the PC
session is discarded and the front panel takes priority.

## Meter holding registers

Voltmeter and Ohmmeter control is separate from the `0x55` sensor-table
calibration protocol.

| Register | Access | Name | Description |
|---:|---|---|---|
| 24 | R/W | `MeterCmd` | Write a meter command; firmware clears it after execution |
| 25 | R | `MeterStatus` | Current meter status |
| 26 | R | `Fadc` | Filtered raw ADC value |
| 27 | R | `FrontKeyStatus` | Front key: 0=none, 1=UP, 2=DOWN, 3=SET |

`MeterCmd`: 0=none, 1=calibrate voltmeter, 2=calibrate ohmmeter,
3=show voltmeter with saved calibration, 4=show ohmmeter with saved
calibration, 5=exit to the saved temperature input.

`MeterStatus`: 0=temperature/idle, 1=busy, 2=voltmeter, 3=ohmmeter,
4=calibration data missing or invalid.
