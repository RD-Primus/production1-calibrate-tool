#ifndef MODBUS_H_
#define MODBUS_H_

#define MODBUS_FUNC_CALIBRATION       0x55

#define MODBUS_CAL_CMD_BEGIN          0x01
#define MODBUS_CAL_CMD_WRITE_TYPE     0x02
#define MODBUS_CAL_CMD_COMMIT         0x03
#define MODBUS_CAL_CMD_ABORT          0x04

#define MODBUS_CAL_TYPE_PTC2K         0x00
#define MODBUS_CAL_TYPE_NTC2K         0x01
#define MODBUS_CAL_TYPE_NTC10K        0x02

#define MODBUS_CAL_STATUS_OK          0x00
#define MODBUS_CAL_STATUS_PASSWORD    0x01
#define MODBUS_CAL_STATUS_NOT_ACTIVE  0x02
#define MODBUS_CAL_STATUS_BUSY        0x03
#define MODBUS_CAL_STATUS_TYPE        0x04
#define MODBUS_CAL_STATUS_LENGTH      0x05
#define MODBUS_CAL_STATUS_DATA        0x06
#define MODBUS_CAL_STATUS_INCOMPLETE  0x07
#define MODBUS_CAL_STATUS_COMMAND     0x08

void modbus_init(void);
void modbus(void);
void modbus_timeout_check(void);
void modbus_calibration_tick(void);
void modbus_calibration_service(void);

extern Modbus_sType Modbus;
extern volatile u8 Flag_NeedAdcReinit;

#endif
